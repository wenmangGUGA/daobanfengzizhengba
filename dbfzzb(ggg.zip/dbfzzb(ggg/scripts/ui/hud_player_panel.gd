extends Control
class_name HudPlayerPanel

# =============================================================================
# 单个玩家的战斗 HUD 面板（1P / 2P 各一个，完全独立）
# 布局完全由素材原始画布位置决定（256x256 设计空间），换图即换布局：
#   头像      : 素材原始位置
#   1P/2P 标识: 素材原始位置（头像右侧上方）
#   血条底图  : 素材原始位置
#   血条      : 底图内上槽位，按剩余格数取「血条N格.png」
#   SP 条     : 底图内下槽位，按 SP 比例裁剪 sp条满.png（满 SP 呼吸提示大招就绪）
#   闪避 CD   : 头像下侧，冷却期间闪烁
# =============================================================================

var player: PlayerController = null # 绑定的玩家
var player_index: int = 1           # 玩家序号

var _portrait: TextureRect = null   # 头像
var _tag: TextureRect = null        # 1P / 2P 标识
var _frame: TextureRect = null      # 血条 SP 条总底图
var _hp_fill: TextureRect = null    # 血条填充（按格数换图）
var _sp_clip: Control = null        # SP 条裁剪容器
var _sp_fill: TextureRect = null    # SP 条填充
var _dodge_icon: TextureRect = null # 闪避冷却图标
var _hp_textures: Array[Texture2D] = [] # 血条 1~10 格贴图
var _sp_full_width: float = 100.0   # sp条满.png 素材有效宽度
var _sp_display_ratio: float = 0.0  # 当前 SP 显示比例（平滑过渡）
var _target_sp_ratio: float = 0.0   # 目标 SP 比例
var _pulse_time: float = 0.0        # SP 满呼吸闪烁计时
var _blink_time: float = 0.0        # 闪避冷却闪烁计时
var _dodge_remaining: float = 0.0   # 闪避剩余冷却
var _dodge_total: float = 1.0       # 闪避冷却总时长
var content_rect: Rect2 = Rect2()   # 面板内所有素材内容占用的区域（用于双人面板排布）

# 绑定玩家并构建面板（玩家进入场景后调用）
func setup(target_player: PlayerController) -> void:
	player = target_player
	player_index = target_player.player_index
	custom_minimum_size = GameConfig.HUD_CANVAS
	size = GameConfig.HUD_CANVAS
	scale = Vector2(GameConfig.HUD_SCALE, GameConfig.HUD_SCALE)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build()
	_connect_player()

func _build() -> void:
	for hp_value in range(1, GameConfig.PLAYER_MAX_HP + 1):
		_hp_textures.append(ArtLoader.load_texture(AssetPaths.hp_bar_path(hp_value)))
	# 头像：第一期固定剑士
	_portrait = UiArt.make_art_rect(self, AssetPaths.UI_PORTRAIT_SWORDSMAN)
	# 1P / 2P 标识：统一放在 1p标识 素材的原始位置，保证双人排列整齐
	_tag = UiArt.make_art_rect(self, AssetPaths.UI_P1_TAG if player_index == 1 else AssetPaths.UI_P2_TAG)
	var tag_reference := ArtLoader.load_texture(AssetPaths.UI_P1_TAG)
	if _tag != null and tag_reference != null:
		_tag.position = ArtLoader.used_rect(tag_reference).position
	# 血条 / SP 条总底图
	_frame = UiArt.make_art_rect(self, AssetPaths.UI_BAR_BASE)
	# 血条填充：与素材左对齐，纵向使用配置槽位
	var hp_texture := ArtLoader.load_texture(AssetPaths.hp_bar_path(GameConfig.PLAYER_MAX_HP))
	_hp_fill = UiArt.make_art_rect(self, AssetPaths.hp_bar_path(GameConfig.PLAYER_MAX_HP))
	if _hp_fill != null and hp_texture != null:
		_hp_fill.position = Vector2(ArtLoader.used_rect(hp_texture).position.x, GameConfig.HUD_HP_BAR_Y)
	# SP 条：裁剪容器 + 满条贴图（按比例裁剪显示）
	var sp_texture := ArtLoader.load_texture(AssetPaths.UI_SP_FULL)
	if sp_texture != null:
		var sp_used := ArtLoader.used_rect(sp_texture)
		_sp_full_width = sp_used.size.x
		_sp_clip = Control.new()
		_sp_clip.position = Vector2(sp_used.position.x, GameConfig.HUD_SP_BAR_Y)
		_sp_clip.size = Vector2(sp_used.size.x, sp_used.size.y)
		_sp_clip.clip_contents = true
		_sp_clip.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_sp_clip)
		_sp_fill = TextureRect.new()
		_sp_fill.texture = UiArt.make_art_texture(sp_texture)
		_sp_fill.position = Vector2.ZERO
		_sp_fill.size = sp_used.size
		_sp_fill.stretch_mode = TextureRect.STRETCH_KEEP
		_sp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_sp_clip.add_child(_sp_fill)
	# 闪避冷却图标（美术贴图预留位置；冷却期间闪烁）
	_dodge_icon = UiArt.make_art_rect(self, AssetPaths.UI_DODGE_COOLDOWN)
	if _dodge_icon != null:
		_dodge_icon.visible = false
	_update_hp(GameConfig.PLAYER_MAX_HP)
	_refresh_sp_clip()
	_measure_content()

# 统计面板内素材内容占用区域（用于 2P 面板紧靠 1P 右侧排列）
func _measure_content() -> void:
	var result := Rect2()
	var has_content := false
	for child in get_children():
		var control := child as Control
		if control == null or not control.visible:
			continue
		var rect := Rect2(control.position, control.size)
		result = rect if not has_content else result.merge(rect)
		has_content = true
	content_rect = result

# 缩放后的内容尺寸（像素）
func get_scaled_content_size() -> Vector2:
	return content_rect.size * scale.x

# 连接玩家信号：血量 / SP / 闪避冷却 / 死亡
func _connect_player() -> void:
	if player == null:
		return
	player.hp_changed.connect(_on_hp_changed)
	player.sp_changed.connect(_on_sp_changed)
	player.dodge_cooldown_changed.connect(_on_dodge_cooldown_changed)
	player.died.connect(_on_player_died)
	_update_hp(player.hp)
	_on_sp_changed(player.player_index, player.sp, GameConfig.PLAYER_MAX_SP)

func _process(delta: float) -> void:
	# SP 条平滑过渡 + 满 SP 呼吸提示（提示大招就绪）
	_sp_display_ratio = move_toward(_sp_display_ratio, _target_sp_ratio, delta * 2.0)
	_refresh_sp_clip()
	if _sp_fill != null:
		if _target_sp_ratio >= 1.0:
			_pulse_time += delta * GameConfig.HUD_SP_READY_PULSE
			var brightness := 0.7 + 0.3 * sin(_pulse_time)
			_sp_fill.modulate = Color(brightness, brightness, brightness, 1.0)
		else:
			_sp_fill.modulate = Color.WHITE
	# 闪避冷却图标闪烁（冷却中 + 剩余比例越高闪得越慢）
	if _dodge_icon != null and _dodge_icon.visible:
		_blink_time += delta
		var remain_ratio := clampf(_dodge_remaining / maxf(_dodge_total, 0.001), 0.0, 1.0)
		_dodge_icon.modulate.a = 0.3 + 0.7 * absf(sin(_blink_time * GameConfig.DODGE_ICON_BLINK_SPEED * (0.4 + 0.6 * remain_ratio)))

func _refresh_sp_clip() -> void:
	if _sp_clip != null:
		_sp_clip.size.x = _sp_full_width * _sp_display_ratio

func _on_hp_changed(changed_index: int, hp: int, _max_hp: int) -> void:
	if changed_index != player_index:
		return
	_update_hp(hp)

func _update_hp(hp: int) -> void:
	if _hp_fill == null:
		return
	if hp <= 0:
		_hp_fill.visible = false # 血量为 0：不显示血条，也不生成任何占位
		return
	var texture := _hp_textures[clampi(hp, 1, GameConfig.PLAYER_MAX_HP) - 1]
	if texture == null:
		_hp_fill.visible = false
		return
	_hp_fill.visible = true
	_hp_fill.texture = UiArt.make_art_texture(texture)
	_hp_fill.size = ArtLoader.used_rect(texture).size

func _on_sp_changed(changed_index: int, sp: int, max_sp: int) -> void:
	if changed_index != player_index:
		return
	_target_sp_ratio = clampf(float(sp) / maxf(float(max_sp), 1.0), 0.0, 1.0)

func _on_dodge_cooldown_changed(changed_index: int, remaining: float, total: float) -> void:
	if changed_index != player_index or _dodge_icon == null:
		return
	_dodge_remaining = remaining
	_dodge_total = total
	_dodge_icon.visible = remaining > 0.0 and total > 0.0
	_dodge_icon.modulate.a = 1.0
	if not _dodge_icon.visible:
		_blink_time = 0.0

func _on_player_died(changed_index: int) -> void:
	if changed_index != player_index:
		return
	modulate = Color(0.45, 0.45, 0.45, 1.0) # 死亡：面板整体变暗
	if _dodge_icon != null:
		_dodge_icon.visible = false
