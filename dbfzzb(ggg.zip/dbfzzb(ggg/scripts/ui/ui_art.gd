extends RefCounted
class_name UiArt

# =============================================================================
# 素材驱动式 UI 工具
# 核心思路：
#   每张 UI 素材都有作者绘制时的原始画布（例如 256x256 / 998x561）。
#   本工具读取素材“有效像素矩形”，自动去掉透明留白，
#   并把内容摆放到它在原始画布中的相同位置 —— 也就是说：
#   美术怎么画的，界面就怎么显示；换图 / 重导素材后位置自动跟随，无需改代码。
# 缺素材时不创建任何节点，只在控制台留下文字警告。
# =============================================================================

# 生成裁剪后的贴图（去掉透明留白），供 TextureRect / TextureButton 使用
static func make_art_texture(texture: Texture2D) -> AtlasTexture:
	if texture == null:
		return null
	var atlas := AtlasTexture.new()
	atlas.atlas = texture
	atlas.region = ArtLoader.used_rect(texture)
	return atlas

# 按素材原始画布坐标创建一个 TextureRect（位置 = 素材内容在画布中的位置）
static func make_art_rect(parent: Node, path: String) -> TextureRect:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		return null
	var rect := TextureRect.new()
	rect.texture = make_art_texture(texture)
	rect.position = ArtLoader.used_rect(texture).position
	rect.size = ArtLoader.used_rect(texture).size
	rect.stretch_mode = TextureRect.STRETCH_KEEP
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(rect)
	return rect

# 按素材原始画布坐标创建一个 TextureButton（可交互图片，点击范围 = 素材有效像素范围）
static func make_art_button(parent: Node, path: String) -> TextureButton:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		return null
	var button := TextureButton.new()
	var atlas := make_art_texture(texture)
	button.texture_normal = atlas
	button.ignore_texture_size = true # 使用下面设置的显式尺寸
	button.stretch_mode = TextureButton.STRETCH_KEEP
	button.position = ArtLoader.used_rect(texture).position
	button.size = ArtLoader.used_rect(texture).size
	button.focus_mode = Control.FOCUS_NONE
	parent.add_child(button)
	return button

# 把已有 Control 摆到它在素材画布中的原始位置（用于运行时替换贴图后重新对齐）
static func apply_authored_rect(control: Control, texture: Texture2D) -> void:
	if control == null or texture == null:
		return
	var used := ArtLoader.used_rect(texture)
	control.position = used.position
	control.size = used.size

# 创建按比例缩放的素材按钮（去掉透明留白后整体缩放，保持原始宽高比）
static func make_art_button_scaled(parent: Node, path: String, factor: float) -> TextureButton:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		return null
	var used := ArtLoader.used_rect(texture)
	var button := TextureButton.new()
	button.texture_normal = make_art_texture(texture)
	button.ignore_texture_size = true
	button.stretch_mode = TextureButton.STRETCH_SCALE
	button.position = used.position * factor
	button.size = used.size * factor
	button.focus_mode = Control.FOCUS_NONE
	parent.add_child(button)
	return button

# 创建按"目标长边尺寸"缩放的素材按钮（保持宽高比）
# 用途：素材换图后画布/内容尺寸会变，用固定倍率会忽大忽小；按目标像素尺寸缩放可自适应新素材。
static func make_art_button_fitted(parent: Node, path: String, target_long_side: float) -> TextureButton:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		return null
	var used := ArtLoader.used_rect(texture)
	var factor := target_long_side / maxf(maxf(used.size.x, used.size.y), 1.0)
	return make_art_button_scaled(parent, path, factor)

# 把 Control 居中到指定矩形区域（自动计入节点自身缩放）
static func center_in(node: Control, area: Rect2) -> void:
	if node == null:
		return
	var scaled_size := node.size * node.scale
	node.position = area.position + (area.size - scaled_size) * 0.5

# 纯文字标签（界面只使用英文字母与数字：引擎默认字体内不含中文字形）
static func make_label(parent: Node, text: String, position: Vector2, font_size: int = 16, color: Color = Color.WHITE) -> Label:
	var label := Label.new()
	label.text = text
	label.position = position
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(label)
	return label
