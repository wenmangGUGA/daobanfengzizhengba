extends CanvasLayer
class_name UltimateCutscene

# =============================================================================
# 大招全屏动画（剑士大招动画，384x256 帧，放大 3.125 倍正好铺满 1200x800 画面）
#   - 素材缺失时不播放、不生成任何占位，直接结束，角色不会卡在大招状态；
#   - 播放期间角色处于霸体（由玩家控制器负责），动画结束自动关闭霸体。
# =============================================================================

signal cutscene_finished   # 全屏动画播放结束

const SCREEN_CENTER := Vector2(600.0, 400.0) # 画面中心
const FRAME_SIZE := Vector2(384.0, 256.0)    # 大招素材单帧尺寸

var _sprite: AnimatedSprite2D = null # 全屏动画节点
var _duration: float = 1.0           # 动画时长（秒）
var _elapsed: float = 0.0            # 已播放时间（兜底计时）

func _ready() -> void:
	layer = 5 # 位于世界之上、HUD（layer 10）之下
	process_mode = Node.PROCESS_MODE_ALWAYS

# 播放全屏大招动画
func play(duration: float) -> void:
	_duration = maxf(duration, 0.2)
	var frames := ArtLoader.build_sprite_frames([
		{"name": "ultimate", "dir": AssetPaths.SWORDSMAN_ULTIMATE_DIR, "fps": GameConfig.ANIM_FPS_ULTIMATE, "loop": false},
	])
	if not frames.has_animation("ultimate"):
		# 缺素材：立即结束，不显示任何占位画面
		call_deferred("_finish")
		return
	_sprite = AnimatedSprite2D.new()
	_sprite.sprite_frames = frames
	_sprite.centered = true
	_sprite.position = SCREEN_CENTER
	_sprite.scale = Vector2(GameConfig.SCREEN_SIZE.y / FRAME_SIZE.y, GameConfig.SCREEN_SIZE.y / FRAME_SIZE.y)
	_sprite.animation_finished.connect(_on_animation_finished)
	add_child(_sprite)
	_sprite.play("ultimate")
	set_process(true)

func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed >= _duration + 0.2:
		_finish() # 兜底：动画信号异常时也能正常结束

func _on_animation_finished() -> void:
	_finish()

func _finish() -> void:
	set_process(false)
	cutscene_finished.emit()
	queue_free()
