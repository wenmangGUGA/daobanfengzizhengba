extends Node2D
class_name ItemPopup

# =============================================================================
# 道具拾取弹出动画（图标弹出 → 存入背包）
# 图标素材来自预留目录 res://textures/items/；缺素材时只显示名称文字，不画任何占位图形。
# =============================================================================

const RISE_DISTANCE := 72.0    # 上浮距离
const DURATION := 1.1          # 动画时长

var icon_path: String = ""     # 图标路径
var display_name: String = ""  # 道具名（ASCII 文本）
var icon_scale: float = 2.0    # 图标缩放（与掉落物图标缩放保持一致）

func setup(path: String, item_name: String, popup_scale: float = 2.0) -> void:
	icon_path = path
	display_name = item_name
	icon_scale = popup_scale

func _ready() -> void:
	var texture := ArtLoader.load_texture(icon_path)
	if texture != null:
		var sprite := Sprite2D.new()
		sprite.texture = texture
		sprite.centered = true
		sprite.scale = Vector2.ONE * icon_scale * 0.6 # 弹出动画：从小放大到掉落物同尺寸
		add_child(sprite)
		var pop := create_tween()
		pop.tween_property(sprite, "scale", Vector2.ONE * icon_scale, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	if not display_name.is_empty():
		var label := Label.new()
		label.text = display_name
		label.add_theme_font_size_override("font_size", 16)
		label.add_theme_color_override("font_color", Color(0.9, 1.0, 0.9, 1.0))
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.size = Vector2(180.0, 24.0)
		label.position = Vector2(-90.0, -56.0)
		add_child(label)
		var fade := create_tween()
		fade.tween_property(label, "modulate:a", 0.0, DURATION).set_delay(DURATION * 0.35)
	var tween := create_tween()
	tween.tween_property(self, "position", position + Vector2(0.0, -RISE_DISTANCE), DURATION)
	tween.tween_callback(queue_free)
