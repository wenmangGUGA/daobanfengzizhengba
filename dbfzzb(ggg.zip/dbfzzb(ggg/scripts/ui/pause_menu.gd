extends Control
class_name PauseMenu

# =============================================================================
# 暂停菜单（ESC 或点击战斗画面右上角暂停图标打开）
# 构图层级（由上至下）：继续 → 退出 → 设置 → 暂停底图
# 即：暂停底图在最底层，设置、退出、继续依次覆盖其上。
# 界面文案全部使用美术图片（继续 / 退出 / 设置图标），不依赖字体。
# =============================================================================

signal resume_requested                 # 继续游戏
signal settings_requested               # 打开设置
signal exit_requested                   # 退出到标题主界面

const PANEL_SCALE := 2.0                # 暂停底图放大倍数
const BUTTON_SCALE := 2.0               # 继续 / 退出按钮放大倍数
const SETTINGS_ICON_SIZE := 200.0       # 设置按钮目标尺寸（长边像素；换素材后自动适配）

var _panel: TextureRect = null          # 暂停底图
var _continue_button: TextureButton = null # 继续游戏
var _exit_button: TextureButton = null     # 退出
var _settings_button: TextureButton = null # 设置（素材：标题页/标题页设置图标.png）
var _items: Array[TextureButton] = []      # 键盘 / 手柄导航顺序：继续 → 退出 → 设置
var _selected: int = 0                     # 当前选中项
var _blink_time: float = 0.0               # 选中项呼吸计时

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	process_mode = Node.PROCESS_MODE_ALWAYS # 暂停状态下仍可操作
	_build()
	visible = false
	set_process(false)

func _build() -> void:
	var screen := GameConfig.SCREEN_SIZE
	# 1. 暂停底图（最底层）
	_panel = UiArt.make_art_rect(self, AssetPaths.UI_PAUSE_BACKGROUND)
	if _panel != null:
		_panel.scale = Vector2(PANEL_SCALE, PANEL_SCALE)
		UiArt.center_in(_panel, Rect2(Vector2.ZERO, screen))
	var panel_rect := Rect2(Vector2.ZERO, screen)
	if _panel != null:
		panel_rect = Rect2(_panel.position, _panel.size * PANEL_SCALE)
	# 2. 设置图标（在暂停底图之上、退出之下）
	# 设置按钮：用标题页的「SETTINGS」文字图（与标题页设置入口视觉统一，白色文字在深色暂停底图上清晰）
	_settings_button = UiArt.make_art_button_fitted(self, AssetPaths.TITLE_SETTINGS_ICON, SETTINGS_ICON_SIZE)
	if _settings_button != null:
		_settings_button.position = Vector2(
			panel_rect.position.x + (panel_rect.size.x - _settings_button.size.x) * 0.5,
			panel_rect.position.y + panel_rect.size.y * 0.72
		)
		_settings_button.pressed.connect(func() -> void: settings_requested.emit())
		_add_hover_feedback(_settings_button)
	# 3. 退出（在设置之上）
	_exit_button = UiArt.make_art_button_scaled(self, AssetPaths.UI_PAUSE_EXIT, BUTTON_SCALE)
	if _exit_button != null:
		_exit_button.position = Vector2(
			panel_rect.position.x + (panel_rect.size.x - _exit_button.size.x) * 0.5,
			panel_rect.position.y + panel_rect.size.y * 0.46
		)
		_exit_button.pressed.connect(func() -> void: exit_requested.emit())
		_add_hover_feedback(_exit_button)
	# 4. 继续游戏（最上层）
	_continue_button = UiArt.make_art_button_scaled(self, AssetPaths.UI_PAUSE_CONTINUE, BUTTON_SCALE)
	if _continue_button != null:
		_continue_button.position = Vector2(
			panel_rect.position.x + (panel_rect.size.x - _continue_button.size.x) * 0.5,
			panel_rect.position.y + panel_rect.size.y * 0.22
		)
		_continue_button.pressed.connect(func() -> void: resume_requested.emit())
		_add_hover_feedback(_continue_button)
	# 键盘 / 手柄导航顺序：继续 → 退出 → 设置
	_items = [_continue_button, _exit_button, _settings_button]
	for index in range(_items.size()):
		if _items[index] == null:
			continue
		var item_index := index
		(_items[index] as TextureButton).mouse_entered.connect(func() -> void: _select(item_index))

# 鼠标悬停高亮（选中按键图片下层就是“选中触发底图”的设计思路，这里用亮度反馈）
func _add_hover_feedback(button: TextureButton) -> void:
	button.mouse_entered.connect(func() -> void: button.modulate = Color(1.2, 1.2, 1.2, 1.0))
	button.mouse_exited.connect(func() -> void: _select(_selected))

# 切换选中项
func _select(index: int) -> void:
	if _items.is_empty():
		return
	_selected = posmod(index, _items.size())
	for item_index in range(_items.size()):
		var button := _items[item_index]
		if button == null:
			continue
		button.modulate = Color(1.25, 1.25, 1.25, 1.0) if item_index == _selected else Color.WHITE

# 激活当前选中项
func _activate() -> void:
	if _items.is_empty():
		return
	var button := _items[_selected]
	if button != null:
		button.pressed.emit()

func _process(delta: float) -> void:
	# 选中项呼吸闪烁（键盘 / 手柄操作时的可视反馈）
	_blink_time += delta
	var button := _items[_selected] if _selected < _items.size() else null
	if button != null:
		var brightness := 1.0 + 0.25 * (0.5 + 0.5 * sin(_blink_time * 4.0))
		button.modulate = Color(brightness, brightness, brightness, 1.0)

# 键盘 / 手柄导航：上下切换、确认键激活（ESC 由 HUD 统一处理为“继续游戏”）
func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	if event.is_action_pressed("menu_up") or event.is_action_pressed("menu_left"):
		_select(_selected - 1)
		_mark_handled()
	elif event.is_action_pressed("menu_down") or event.is_action_pressed("menu_right"):
		_select(_selected + 1)
		_mark_handled()
	elif event.is_action_pressed("menu_confirm"):
		_mark_handled()
		_activate()

func _mark_handled() -> void:
	var viewport := get_viewport()
	if viewport != null:
		viewport.set_input_as_handled()

func open() -> void:
	visible = true
	set_process(true)
	_select(0)

func close() -> void:
	visible = false
	set_process(false)
