extends Node2D
class_name FloatingText

# =============================================================================
# 世界坐标漂浮文字（拾取金币时弹出「+数字」动画）
# 只使用数字与符号，避免依赖中文字形。
# =============================================================================

const RISE_DISTANCE := 64.0    # 上浮距离（像素）
const DURATION := 0.9          # 动画总时长（秒）

var text: String = "+1"        # 显示内容
var color: Color = Color.WHITE # 文字颜色
var font_size: int = 22        # 字号

var _label: Label = null       # 文本节点

func setup(display_text: String, display_color: Color, size: int = 22) -> void:
	text = display_text
	color = display_color
	font_size = size

func _ready() -> void:
	_label = Label.new()
	_label.text = text
	_label.add_theme_font_size_override("font_size", font_size)
	_label.add_theme_color_override("font_color", color)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.size = Vector2(160.0, 30.0)
	_label.position = Vector2(-80.0, -40.0) # 以世界坐标点为中心
	add_child(_label)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(self, "position", position + Vector2(0.0, -RISE_DISTANCE), DURATION)
	tween.tween_property(_label, "modulate:a", 0.0, DURATION).set_delay(DURATION * 0.35)
	tween.chain().tween_callback(queue_free)
