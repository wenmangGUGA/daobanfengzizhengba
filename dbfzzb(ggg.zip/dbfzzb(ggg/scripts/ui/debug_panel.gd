extends Control
class_name DebugPanel

# =============================================================================
# 调试面板（测试台模式：F1 开关）
# 显示：血量 / SP / 霸体 / 大招帧号 / 位置 / 怪物与宝箱统计。
# 面板内容全部为 ASCII 文本（引擎默认字体不含中文字形）。
# =============================================================================

var _label: Label = null     # 文本内容
var _level: Node = null      # 关卡引用（用于取统计信息）

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	var background := ColorRect.new() # 调试面板遮罩（仅调试用途，不影响正式画面）
	background.color = Color(0.0, 0.0, 0.0, 0.55)
	background.position = Vector2(12.0, 300.0)
	background.size = Vector2(560.0, 250.0)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)
	_label = UiArt.make_label(self, "", Vector2(24.0, 306.0), 14, Color(0.6, 1.0, 0.6, 1.0))
	visible = false

func bind_level(level: Node) -> void:
	_level = level

func toggle() -> void:
	visible = not visible

func _process(_delta: float) -> void:
	if not visible or _label == null:
		return
	var lines: Array[String] = []
	for node in get_tree().get_nodes_in_group("player_controller"):
		lines.append(String((node as Node).call("debug_status_line")))
	if _level != null and is_instance_valid(_level):
		lines.append(String(_level.call("debug_status_line")))
	_label.text = "\n".join(lines)
