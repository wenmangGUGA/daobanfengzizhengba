extends Control
class_name SettingsMenu

# =============================================================================
# 设置页面：音量滑块 / 按键自定义 / 返回
# 说明：引擎默认字体内不含中文字形，因此界面文字全部使用英文字母与数字；
#      能用到中文的地方一律使用美术图片（继续 / 退出 / 设置图标）。
# 按键自定义支持：键盘槽 + 手柄槽分别重绑，立即生效并保存到 user://input_bindings.cfg。
# =============================================================================

signal back_requested   # 返回上一级（暂停菜单）

const PANEL_SIZE := Vector2(940.0, 730.0) # 设置面板尺寸（居中显示）
const ROW_HEIGHT := 34.0                  # 每行按键的高度
const LABEL_WIDTH := 230.0                # 动作名列宽
const SLOT_WIDTH := 180.0                 # 按键槽按钮列宽

var _panel: TextureRect = null            # 面板底图（复用暂停底图素材）
var _volume_slider: HSlider = null        # 音量滑块
var _volume_label: Label = null           # 音量数值
var _list_container: VBoxContainer = null # 按键行容器
var _listening: Dictionary = {}           # 正在等待输入的按键槽 { owner, action, slot, button }
var _slot_buttons: Array = []             # 全部按键槽按钮（用于刷新文字）
var _back_button: TextureButton = null    # 返回按钮（打开设置时自动获得焦点，支持手柄导航）

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	process_mode = Node.PROCESS_MODE_ALWAYS # 暂停状态下也能操作设置
	_build()
	visible = false

func _build() -> void:
	var screen := GameConfig.SCREEN_SIZE
	# 面板底图：复用「暂停底图」素材（缺素材时不影响功能，仅没有背景图）
	_panel = UiArt.make_art_rect(self, AssetPaths.UI_PAUSE_BACKGROUND)
	if _panel != null:
		_panel.stretch_mode = TextureRect.STRETCH_SCALE
		_panel.size = PANEL_SIZE
		_panel.position = (screen - PANEL_SIZE) * 0.5
	var panel_rect := Rect2((screen - PANEL_SIZE) * 0.5, PANEL_SIZE)
	UiArt.make_label(self, "SETTINGS", panel_rect.position + Vector2(28.0, 18.0), 26)
	# ---------------- 音量滑块 ----------------
	var volume_row := panel_rect.position + Vector2(28.0, 66.0)
	UiArt.make_label(self, "VOLUME", volume_row, 16)
	_volume_slider = HSlider.new()
	_volume_slider.min_value = 0.0
	_volume_slider.max_value = 1.0
	_volume_slider.step = 0.01
	_volume_slider.value = AudioService.get_master_volume()
	_volume_slider.position = volume_row + Vector2(110.0, 0.0)
	_volume_slider.size = Vector2(420.0, 20.0)
	_volume_slider.value_changed.connect(_on_volume_changed)
	add_child(_volume_slider)
	_volume_label = UiArt.make_label(self, "%d%%" % int(AudioService.get_master_volume() * 100.0), volume_row + Vector2(548.0, 0.0), 16)
	# ---------------- 按键自定义列表 ----------------
	UiArt.make_label(self, "KEY BINDING", panel_rect.position + Vector2(28.0, 104.0), 18)
	var scroll := ScrollContainer.new()
	scroll.position = panel_rect.position + Vector2(24.0, 134.0)
	scroll.size = Vector2(PANEL_SIZE.x - 48.0, PANEL_SIZE.y - 220.0)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	_list_container = VBoxContainer.new()
	_list_container.custom_minimum_size.x = PANEL_SIZE.x - 60.0
	_list_container.add_theme_constant_override("separation", 4)
	scroll.add_child(_list_container)
	_build_binding_rows()
	# ---------------- 底部按钮 ----------------
	var bottom := panel_rect.position + Vector2(28.0, PANEL_SIZE.y - 66.0)
	var reset_button := Button.new()
	reset_button.text = "RESET DEFAULTS"
	reset_button.position = bottom
	reset_button.size = Vector2(190.0, 40.0)
	reset_button.pressed.connect(_on_reset_pressed)
	add_child(reset_button)
	_back_button = UiArt.make_art_button_scaled(self, AssetPaths.UI_PAUSE_CONTINUE, 1.4)
	if _back_button != null:
		_back_button.position = bottom + Vector2(PANEL_SIZE.x - 48.0 - 140.0, 0.0)
		_back_button.focus_mode = Control.FOCUS_ALL # 允许手柄 / 键盘聚焦后按键返回
		_back_button.pressed.connect(func() -> void: back_requested.emit())

# 生成 1P / 2P / 全局 三组按键行
func _build_binding_rows() -> void:
	for owner_index in [1, 2, 0]:
		var title := "GLOBAL" if owner_index == 0 else "PLAYER %d" % owner_index
		var title_label := UiArt.make_label(_list_container, title, Vector2(6.0, 6.0), 18, Color(1.0, 0.85, 0.35, 1.0))
		title_label.custom_minimum_size = Vector2(0.0, 30.0)
		for action in InputService.get_bindable_actions(owner_index):
			_list_container.add_child(_make_binding_row(owner_index, String(action)))

# 单行：动作名 + 键盘槽 + 手柄槽
func _make_binding_row(owner_index: int, action: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.custom_minimum_size = Vector2(0.0, ROW_HEIGHT)
	row.add_theme_constant_override("separation", 10)
	var name_label := Label.new()
	name_label.text = InputService.get_action_label(action)
	name_label.custom_minimum_size = Vector2(LABEL_WIDTH, 0.0)
	name_label.add_theme_font_size_override("font_size", 14)
	row.add_child(name_label)
	for slot in ["key", "pad"]:
		var button := Button.new()
		button.custom_minimum_size = Vector2(SLOT_WIDTH, 0.0)
		button.text = InputService.describe_binding(owner_index, action, slot)
		button.set_meta("owner_index", owner_index)
		button.set_meta("action", action)
		button.set_meta("slot", slot)
		button.pressed.connect(_on_slot_pressed.bind(button))
		row.add_child(button)
		_slot_buttons.append(button)
	return row

# 点击某个按键槽 → 进入等待输入状态
func _on_slot_pressed(button: Button) -> void:
	_listening = {
		"owner_index": int(button.get_meta("owner_index")),
		"action": String(button.get_meta("action")),
		"slot": String(button.get_meta("slot")),
		"button": button,
	}
	_refresh_slot_buttons()

# 捕获下一个输入事件完成重绑（ESC 取消）
func _input(event: InputEvent) -> void:
	if _listening.is_empty():
		return
	if event is InputEventKey:
		var key_event := event as InputEventKey
		if not key_event.pressed or key_event.echo:
			return
		if key_event.physical_keycode == KEY_ESCAPE:
			_cancel_listening()
			get_viewport().set_input_as_handled()
			return
		_apply_listening(key_event)
	elif event is InputEventJoypadButton and (event as InputEventJoypadButton).pressed:
		_apply_listening(event)
	elif event is InputEventJoypadMotion and absf((event as InputEventJoypadMotion).axis_value) > 0.6:
		_apply_listening(event)

func _apply_listening(event: InputEvent) -> void:
	InputService.rebind(int(_listening["owner_index"]), String(_listening["action"]), String(_listening["slot"]), event)
	_listening = {}
	_refresh_slot_buttons()
	get_viewport().set_input_as_handled()

func _cancel_listening() -> void:
	_listening = {}
	_refresh_slot_buttons()

# 刷新所有按键槽显示文字（正在等待输入的那一个显示 PRESS KEY...）
func _refresh_slot_buttons() -> void:
	for slot_button in _slot_buttons:
		var button := slot_button as Button
		if not _listening.is_empty() and _listening.get("button", null) == button:
			button.text = "PRESS KEY..."
			continue
		button.text = InputService.describe_binding(
			int(button.get_meta("owner_index")), String(button.get_meta("action")), String(button.get_meta("slot")))

func _on_volume_changed(value: float) -> void:
	AudioService.set_master_volume(value)
	if _volume_label != null:
		_volume_label.text = "%d%%" % int(value * 100.0)

func _on_reset_pressed() -> void:
	InputService.reset_all_bindings()
	_refresh_slot_buttons()

func open() -> void:
	visible = true
	_listening = {}
	_refresh_slot_buttons()
	if _volume_slider != null:
		_volume_slider.value = AudioService.get_master_volume()
	if _back_button != null:
		_back_button.grab_focus() # 打开设置即聚焦返回键，手柄 / 键盘可直接导航

func close() -> void:
	visible = false
	_listening = {}
