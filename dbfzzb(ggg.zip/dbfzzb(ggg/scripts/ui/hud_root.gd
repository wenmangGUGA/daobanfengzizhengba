extends CanvasLayer
class_name HudRoot

# =============================================================================
# 战斗 HUD 总控（双人双 UI；单人模式自动隐藏 2P 全部 UI）
# 包含：玩家状态面板（头像 / 血条 / SP 条 / 闪避冷却）、金币总数、
#      右上角暂停图标、暂停菜单、设置页面、背包、结算界面、调试面板。
# UI 可绘制在 3:2 画面外的安全区（直接使用窗口安全边距布局）。
# =============================================================================

signal resume_pressed      # 暂停菜单 → 继续游戏
signal exit_pressed        # 暂停菜单 / 结算 → 退出到标题主界面
signal escape_pressed      # ESC 键（暂停状态下也要响应，因此由 HUD 统一捕获）

const PAUSE_BUTTON_SIZE := 52.0   # 暂停图标目标尺寸（长边像素；按素材实际内容自适应缩放，换图后自动适配）
const PAUSE_BUTTON_MARGIN := 16.0 # 暂停图标距离画面右上角边距
const COIN_LABEL_GAP := 18.0      # 金币显示与玩家面板的间距

var player_panels: Array[HudPlayerPanel] = [] # 1P / 2P 状态面板
var pause_menu: PauseMenu = null              # 暂停菜单
var settings_menu: SettingsMenu = null        # 设置页面
var inventory_panel: InventoryPanel = null    # 背包
var result_overlay: ResultOverlay = null      # 结算界面
var debug_panel: DebugPanel = null            # 调试面板（F1）
var _pause_button: TextureButton = null       # 右上角暂停图标
var _coin_label: Label = null                 # 金币总数
var _level: Node = null                       # 关卡引用

func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()

func _build() -> void:
	# 金币总数（队伍共享）
	_coin_label = UiArt.make_label(self, "COINS 0", GameConfig.HUD_MARGIN, 22, Color(1.0, 0.85, 0.3, 1.0))
	GameSession.coins_changed.connect(_on_coins_changed)
	_on_coins_changed(GameSession.coins)
	# 右上角暂停图标（点击即暂停）
	_pause_button = UiArt.make_art_button_fitted(self, AssetPaths.UI_PAUSE_ICON, PAUSE_BUTTON_SIZE)
	if _pause_button != null:
		_pause_button.position = Vector2(
			GameConfig.SCREEN_SIZE.x - _pause_button.size.x - PAUSE_BUTTON_MARGIN,
			PAUSE_BUTTON_MARGIN
		)
		_pause_button.pressed.connect(func() -> void: open_pause())
	# 暂停菜单
	pause_menu = PauseMenu.new()
	pause_menu.name = "PauseMenu"
	add_child(pause_menu)
	pause_menu.resume_requested.connect(func() -> void: resume_pressed.emit())
	pause_menu.exit_requested.connect(func() -> void: exit_pressed.emit())
	pause_menu.settings_requested.connect(open_settings)
	# 设置页面
	settings_menu = SettingsMenu.new()
	settings_menu.name = "SettingsMenu"
	add_child(settings_menu)
	settings_menu.back_requested.connect(close_settings)
	# 背包
	inventory_panel = InventoryPanel.new()
	inventory_panel.name = "InventoryPanel"
	add_child(inventory_panel)
	# 结算界面
	result_overlay = ResultOverlay.new()
	result_overlay.name = "ResultOverlay"
	add_child(result_overlay)
	result_overlay.finished.connect(func() -> void: exit_pressed.emit())
	# 调试面板
	debug_panel = DebugPanel.new()
	debug_panel.name = "DebugPanel"
	add_child(debug_panel)

# 绑定关卡与玩家（关卡生成玩家后调用）
func bind(level: Node, players: Array) -> void:
	_level = level
	if debug_panel != null:
		debug_panel.bind_level(level)
	for panel in player_panels:
		panel.queue_free()
	player_panels.clear()
	var offset_x := 0.0
	var max_height := 0.0
	for index in range(players.size()):
		var player := players[index] as PlayerController
		if player == null:
			continue
		var panel := HudPlayerPanel.new()
		panel.name = "PlayerPanel%d" % player.player_index
		add_child(panel)
		panel.setup(player)
		panel.position = GameConfig.HUD_MARGIN + Vector2(offset_x, 0.0)
		player_panels.append(panel)
		offset_x += panel.get_scaled_content_size().x + GameConfig.HUD_PANEL_GAP.x
		max_height = maxf(max_height, panel.get_scaled_content_size().y)
	# 金币显示排到玩家面板正下方
	if _coin_label != null:
		_coin_label.position = GameConfig.HUD_MARGIN + Vector2(0.0, max_height + COIN_LABEL_GAP)

# ------------------------------ 暂停 / 设置 / 背包 ------------------------------
func open_pause() -> void:
	if pause_menu != null:
		pause_menu.open()

func close_pause() -> void:
	if pause_menu != null:
		pause_menu.close()

func is_pause_open() -> bool:
	return pause_menu != null and pause_menu.visible

func open_settings() -> void:
	if pause_menu != null:
		pause_menu.close()
	if settings_menu != null:
		settings_menu.open()

func close_settings() -> void:
	if settings_menu != null:
		settings_menu.close()
	if pause_menu != null:
		pause_menu.open() # 返回暂停菜单

func toggle_inventory() -> void:
	if inventory_panel != null:
		inventory_panel.toggle()

func is_inventory_open() -> bool:
	return inventory_panel != null and inventory_panel.visible

func toggle_debug() -> void:
	if debug_panel != null:
		debug_panel.toggle()

# 展示结算界面
func show_result(is_clear: bool) -> void:
	close_pause()
	if settings_menu != null:
		settings_menu.close()
	if inventory_panel != null:
		inventory_panel.close()
	if _pause_button != null:
		_pause_button.visible = false
	if result_overlay != null:
		result_overlay.show_result(is_clear)

func _on_coins_changed(total_coins: int) -> void:
	if _coin_label != null:
		_coin_label.text = "COINS %d" % total_coins

# ESC 捕获：暂停菜单 / 设置页面 / 战斗内都能响应
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_menu"):
		var viewport := get_viewport()
		if viewport != null:
			viewport.set_input_as_handled() # 先标记事件已处理，再执行可能切换场景的回调
		escape_pressed.emit()
