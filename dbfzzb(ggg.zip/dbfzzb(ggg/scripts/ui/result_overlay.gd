extends Control
class_name ResultOverlay

# =============================================================================
# 关卡结算界面
#   任务完成：任务完成底图.png + 任务完成字.png
#   游戏失败：任务完成底图.png + 游戏失败.png
# 结算后自动回到标题主界面（也可按键立即返回）。
# =============================================================================

signal finished   # 结算展示结束（关卡据此回到标题主界面）

const PANEL_SCALE := 2.6          # 底图放大倍数
const HOLD_TIME := 2.8            # 自动返回标题的等待时间（秒）

var _panel: TextureRect = null    # 结算底图
var _title: TextureRect = null    # 结算文字图
var _hold_timer: float = 0.0      # 等待计时
var _active: bool = false         # 是否正在展示

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	set_process(false)

# 展示结算：is_clear = true 任务完成，false 游戏失败
func show_result(is_clear: bool) -> void:
	for child in get_children():
		child.queue_free()
	var screen := GameConfig.SCREEN_SIZE
	_panel = UiArt.make_art_rect(self, AssetPaths.UI_RESULT_CLEAR_BACKGROUND)
	if _panel != null:
		_panel.scale = Vector2(PANEL_SCALE, PANEL_SCALE)
		UiArt.center_in(_panel, Rect2(Vector2.ZERO, screen))
	var area := Rect2(Vector2.ZERO, screen)
	if _panel != null:
		area = Rect2(_panel.position, _panel.size * PANEL_SCALE)
	_title = UiArt.make_art_rect(self, AssetPaths.UI_RESULT_CLEAR_TEXT if is_clear else AssetPaths.UI_RESULT_GAME_OVER)
	if _title != null:
		_title.scale = Vector2(2.2, 2.2)
		# 结算文字居中叠在底图上
		_title.position = area.position + (area.size - _title.size * 2.2) * 0.5
	visible = true
	_active = true
	_hold_timer = 0.0
	set_process(true)
	AudioService.play_sfx("mission_clear" if is_clear else "game_over")

func _process(delta: float) -> void:
	if not _active:
		return
	_hold_timer += delta
	if _hold_timer >= HOLD_TIME:
		_finish()

func _unhandled_input(event: InputEvent) -> void:
	if not _active:
		return
	if event.is_action_pressed("menu_confirm") or event.is_action_pressed("menu_cancel"):
		_finish()

func _finish() -> void:
	if not _active:
		return
	_active = false
	set_process(false)
	visible = false
	finished.emit()
