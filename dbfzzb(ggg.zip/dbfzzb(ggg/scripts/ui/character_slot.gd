@tool # 【编辑器实时预览】开启后，在编辑器里改参数也能立刻看到立绘的真实效果（运行逻辑不受影响）
extends Control
class_name CharacterSlot

# =============================================================================
# 角色格子【可复用独立预制组件】—— 所有角色格子共用同一个 character_slot.tscn
#
# 【边界方案：不使用任何程序裁切】
#   引擎侧不做任何裁剪（没有遮罩节点、没有 clip_contents、没有着色器裁剪）。
#   未选中只显示「角色纯背景底图」，角色立绘完全不显示；只有选中时才把立绘打开并放大冲出边框。
#
# 图层规则（从底层到顶层，与本节点子节点顺序 + z_index 一致）：
#   层级1 底图           : 未选中 = 角色专属底图（<角色名>底图.png，角色由美术排在卡片安全区内）；z_index = 0 / 1
#                          选中   = 角色纯背景底图（<角色名>纯背景底图.png，无角色、无滤镜）
#   层级2 InsideArt       : 【永久禁用】保留节点但永不渲染、不参与任何状态逻辑   z_index = 2
#   层级3 NormalFrame     : 未选中状态普通边框（未选中时显示）                   z_index = 3
#   层级4 SelectedFrame   : 选中白色闪烁边框                                    z_index = 8（可切到角色上方）
#   层级5 OutsideArt      : 角色立绘【仅选中时显示】，放在最顶层渲染，
#                          切换瞬间立刻放大并上移，冲出边框向外突出             z_index = 9（绝对层级，越过相邻卡片）
#   层级6 Tag             : 格子底部 1P / 2P 标识                               z_index = 10
#
# 组件内置统一逻辑（新增角色只需复制本组件、替换图片资源，不需要改任何代码/动画）：
#   · 未选中：只显示「被代码压暗的角色专属底图」+ 普通边框；无角色立绘、无白边闪烁
#   · 选中  ：底图直接切换成角色纯背景底图（无滤镜）+ 打开 OutsideArt 立绘并立刻放大上移冲出边框
#             + 白边闪烁 + 显示 1P/2P
#   · 确认  ：底色 / 角色 / 边框三者同步白色闪烁
#   · 取消选中：直接隐藏 OutsideArt（不再切回 InsideArt）+ 底图切回角色专属底图并压暗（6 条复位见下）
# =============================================================================

signal slot_clicked(slot: CharacterSlot) # 点击了本格子（由选角界面统一处理业务逻辑）

# 说明：下面 @export 的分组顺序 = 检查器 Inspector 里的显示顺序（方便手动调参）
@export_group("Identity") # ---------------- 1. 身份信息 ----------------
@export var slot_index: int = 1                    # 格子序号（1~6 普通角色，7 随机）
@export var character_id: String = ""              # 角色 id（用于进入关卡时下发）
@export var display_name: String = ""              # 角色显示名（仅调试打印用）
@export var is_available: bool = true              # 是否已完成可用（false = 未完成角色，点击弹提示）
@export var is_random_slot: bool = false           # 是否为「随机选择角色」格子

@export_group("Art") # ---------------- 2. 美术资源（换角色只改这里） ----------------
@export var slot_bg_path: String = ""              # 层级1：角色专属底图（<角色名>底图.png，角色已由美术排在卡片安全区内）——未选中显示、被代码压暗
@export var selected_bg_path: String = ""          # 层级1：角色纯背景底图（<角色名>纯背景底图.png，不含角色）——选中时切换显示、无滤镜；留空 = 沿用上面的底图
@export var character_art_path: String = ""        # 角色立绘（<角色名>立绘.png）——【仅选中时】由 OutsideArt 显示
@export var normal_frame_path: String = ""         # 层级3：未选中边框
@export var selected_frame_path: String = ""       # 层级4：选中边框
@export var tag_1p_path: String = ""               # 层级6：1P 标识
@export var tag_2p_path: String = ""               # 层级6：2P 标识

@export_group("Character Layout") # ---------------- 3. 立绘位置/大小（选中时那张立绘，可每格单独调） ----------------
@export var art_height_px: float = 0.0             # 【推荐】直接指定立绘高度（像素）；0 = 关闭，改用下面的 art_fit_ratio
@export var art_fit_ratio: float = 0.88            # 立绘高度 = 格子高度 × 该值（art_height_px = 0 时生效）
@export var art_scale: float = 1.0                 # 再乘一个缩放（1.0 = 不额外缩放），用于精细微调
@export var art_offset: Vector2 = Vector2.ZERO     # 位置偏移（像素，正值向右下）；基准点 = 格子底边中心
@export var art_bottom_inset: float = 2.0          # 立绘脚底距格子底边的距离（脚被切就加大）

@export_group("Background Layout") # ---------------- 4. 底图位置/大小（未选中底图 + 选中纯背景底图，共用一套） ----------------
@export var bg_scale: float = 1.0                  # 底图缩放（1.0 = 正好铺满格子；以格子中心为基准缩放）
@export var bg_offset: Vector2 = Vector2.ZERO      # 底图位置偏移（正值向右下）

@export_group("Tag Layout") # ---------------- 5. 1P/2P 标识布局 ----------------
@export var tag_padding: Vector2 = Vector2(10, 12) # 1P/2P 标识距格子底部/左右的内边距
@export_range(0.0, 1.0, 0.01) var tag_align_x: float = 1.0 # 标识横向位置：0=靠左 0.5=居中 1=靠右（默认右下角）
@export var tag_size: float = 1.0                  # 1P/2P 标识缩放

@export_group("Interaction") # ---------------- 6. 点击判定 ----------------
@export var click_area_trim_right: float = 0.0     # 点击判定右侧裁掉多少像素（避开与右侧格子的重叠区）

@export_group("State Style") # ---------------- 7. 状态表现 ----------------
@export_range(0.05, 1.0, 0.01) var unselected_dim: float = 0.42  # 未选中暗化系数（底色+角色统一压暗）
@export_range(0.5, 3.0, 0.01) var selected_scale: float = 1.08   # 选中时角色放大倍数（瞬间放大）
@export var selected_rise: float = -18.0                         # 选中时角色上移像素（负=向上，冲破卡片）
@export_range(0.5, 20.0, 0.1) var blink_speed: float = 3.0       # 白边/确认闪烁频率
@export var selected_frame_on_top: bool = false                  # true = 白边压在角色上方（默认角色在前）
@export var outside_art_absolute_z: int = 900                    # 外侧角色绝对层级（保证越过相邻卡片）

@export_group("Editor Preview") # ---------------- 仅编辑器预览（不影响正式运行） ----------------
@export var editor_preview_selected: bool = false      # 勾上=编辑器里直接预览"选中"状态（调 selected_scale / rise 用）
@export_range(0, 2) var editor_preview_tag: int = 0    # 编辑器里预览 1P/2P 标识（0=不显示 1=1P 2=2P）

var is_selected: bool = false        # 是否处于选中状态
var is_confirmed: bool = false       # 是否已被最终确认（三者同步白闪）
var selection_tag: int = 0           # 当前标识：0 无 / 1 = 1P / 2 = 2P

var _background: TextureRect = null          # 层级1 未选中底图（角色专属底图，会被压暗）
var _selected_background: TextureRect = null # 层级1 选中底图（角色纯背景底图，无滤镜）
var _inside_art: TextureRect = null          # 层级2 InsideArt（永久禁用，不参与渲染）
var _normal_frame: TextureRect = null        # 层级3
var _selected_frame: TextureRect = null      # 层级4
var _outside_art: TextureRect = null         # 层级5 角色立绘（仅选中时显示）
var _tag: TextureRect = null                 # 层级6
var _inside_draw_size: Vector2 = Vector2.ZERO  # inside 立绘绘制尺寸
var _outside_draw_size: Vector2 = Vector2.ZERO # outside 立绘绘制尺寸
var _blink_time: float = 0.0             # 闪烁计时
var _editor_snapshot: Dictionary = {}

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP # 需要接收点击
	_build_layers()
	_apply_frame_layer()      # 选中边框显示层级（可在检查器切换是否压在角色上方）
	if Engine.is_editor_hint():
		# ---------------- 编辑器：只做实时预览，不跑任何游戏逻辑 ----------------
		_editor_apply_preview()
		_editor_snapshot = _editor_state()
		return
	_apply_unselected_state() # 初始未选中：按"取消选中强制执行"复位
	_apply_tag()

# ------------------------------ 构建图层 ------------------------------
func _build_layers() -> void:
	# 层级1：未选中底图（角色专属底图：角色已由美术排在卡片安全区内）
	_background = _make_art_rect(slot_bg_path, Vector2.ZERO, size, 0)
	# 层级1：选中底图（角色纯背景底图；没单独填就沿用未选中底图）
	_selected_background = _make_art_rect(_selected_bg_source(), Vector2.ZERO, size, 1)
	if _selected_background != null:
		_selected_background.visible = false # 默认隐藏，选中时才切换显示
	# 层级2：InsideArt —— 【永久禁用】保留节点结构，但永不渲染、不参与任何状态逻辑
	_inside_art = _make_art_rect(character_art_path, Vector2.ZERO, Vector2.ZERO, 2)
	if _inside_art != null:
		_inside_art.visible = false # 永久隐藏（角色只在选中时由 OutsideArt 显示）
	# 层级3：未选中普通边框
	_normal_frame = _make_art_rect(normal_frame_path, Vector2.ZERO, Vector2.ZERO, 3, self, true)
	# 层级4：选中白色闪烁边框
	_selected_frame = _make_art_rect(selected_frame_path, Vector2.ZERO, Vector2.ZERO, 8, self, true)
	# 层级5：角色立绘（仅选中时显示；绝对层级，保证冲出卡片向外突出）
	_outside_art = _make_art_rect(character_art_path, Vector2.ZERO, Vector2.ZERO, 9)
	if _outside_art != null:
		_outside_art.z_as_relative = false
		_outside_art.z_index = outside_art_absolute_z
	# 层级6：1P / 2P 标识
	_tag = _make_art_rect("", Vector2.ZERO, Vector2.ZERO, 10)
	_place_backgrounds()   # 底图：按 bg_scale / bg_offset 摆放（两张底图共用）
	_compute_art_layout()  # 立绘：按 art_fit_ratio / art_scale 算尺寸
	_place_art()           # 立绘：按 art_offset / art_bottom_inset 摆位置
	_place_tag()

# 创建素材节点
#   z_order      : 相对层级
#   parent       : 挂载父节点（默认本节点）
#   center_frame : true = 以格子中心居中并保持素材原始尺寸（边框类，比格子大也能完整显示）
func _make_art_rect(path: String, pos: Vector2, target_size: Vector2, z_order: int, parent: Node = null, center_frame: bool = false) -> TextureRect:
	var host: Node = parent if parent != null else self
	if path.is_empty():
		var hidden := TextureRect.new()
		hidden.visible = false # 空路径：不生成任何图像（绝不生成占位色块）
		hidden.z_index = z_order
		host.add_child(hidden)
		return hidden
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		var missing := TextureRect.new()
		missing.visible = false # 缺素材：控制台已告警，这里不显示任何占位
		missing.z_index = z_order
		host.add_child(missing)
		return missing
	var node := TextureRect.new()
	node.texture = UiArt.make_art_texture(texture)
	node.stretch_mode = TextureRect.STRETCH_SCALE
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	node.z_index = z_order
	var used := ArtLoader.used_rect(texture)
	if center_frame:
		node.size = used.size
		node.position = size * 0.5 - used.size * 0.5
	else:
		node.size = target_size if target_size != Vector2.ZERO else used.size
		node.position = pos
	host.add_child(node)
	return node

# 计算立绘绘制尺寸：高度 = 格子高度 × art_fit_ratio
# （InsideArt 已永久禁用，这里仍算它一份只是为了保留节点完整，随时可重新启用）
func _compute_art_layout() -> void:
	_inside_draw_size = _draw_size_for(_inside_art)
	_outside_draw_size = _draw_size_for(_outside_art)

func _draw_size_for(node: TextureRect) -> Vector2:
	if node == null or node.texture == null:
		return Vector2.ZERO
	var art_size := node.texture.get_size()
	# 目标高度：优先用「按像素指定」（art_height_px > 0），否则用「格子高度 × art_fit_ratio」
	var target_height := size.y * maxf(art_fit_ratio, 0.05)
	if art_height_px > 0.0:
		target_height = art_height_px
	var factor := target_height / maxf(art_size.y, 1.0)
	return art_size * factor * maxf(art_scale, 0.01)

# 底图摆放：以格子中心为基准缩放，再叠加偏移（两张底图共用同一套参数，保证切换时不跳位）
func _place_backgrounds() -> void:
	var box := size * maxf(bg_scale, 0.01)
	var pos := (size - box) * 0.5 + bg_offset
	for node in [_background, _selected_background]:
		if node == null:
			continue
		node.size = box
		node.position = pos

# 选中时显示的底图来源：优先用「角色纯背景底图」，没填就沿用未选中的角色专属底图
func _selected_bg_source() -> String:
	return selected_bg_path if not selected_bg_path.is_empty() else slot_bg_path

# 摆放立绘（底边统一贴在"格子底边 − art_bottom_inset"）：
#   inside ：永久禁用节点（仍摆好位置，方便将来重新启用），永远不显示
#   outside：真正的角色立绘，仅选中时显示并放大上移冲出边框
func _place_art() -> void:
	if _inside_art != null and _inside_draw_size != Vector2.ZERO:
		_inside_art.size = _inside_draw_size
		_inside_art.pivot_offset = Vector2(_inside_draw_size.x * 0.5, _inside_draw_size.y)
		_inside_art.position = Vector2(
			size.x * 0.5 - _inside_draw_size.x * 0.5,
			_art_bottom_y() - _inside_draw_size.y
		) + art_offset
		_inside_art.scale = Vector2.ONE # 【强制】保持 1 倍，不残留放大
	if _outside_art != null and _outside_draw_size != Vector2.ZERO:
		_outside_art.size = _outside_draw_size
		_outside_art.pivot_offset = Vector2(_outside_draw_size.x * 0.5, _outside_draw_size.y)
		_outside_art.position = _outside_base_position()

# 立绘的基准位置（底边贴在"格子底边 − art_bottom_inset"）
func _outside_base_position() -> Vector2:
	return Vector2(size.x * 0.5 - _outside_draw_size.x * 0.5, _art_bottom_y() - _outside_draw_size.y) + art_offset

# 立绘脚底所在的格子纵向位置
func _art_bottom_y() -> float:
	return size.y - maxf(art_bottom_inset, 0.0)

# 1P/2P 标识摆放：格子底部（横向位置由 tag_align_x 控制，默认靠右下），
# 并按"可见区域"避开右侧被邻格压住的重叠部分
func _place_tag() -> void:
	if _tag == null:
		return
	var area_right := size.x - maxf(click_area_trim_right, 0.0)
	var min_x := tag_padding.x
	var max_x := area_right - tag_padding.x - _tag.size.x * tag_size
	_tag.pivot_offset = _tag.size * 0.5
	_tag.scale = Vector2(tag_size, tag_size)
	_tag.position = Vector2(
		lerpf(min_x, max_x, clampf(tag_align_x, 0.0, 1.0)),
		size.y - tag_padding.y - _tag.size.y * tag_size
	)

# ------------------------------ 状态切换 ------------------------------
# 选中状态切换（组件内置统一逻辑）
func set_selected(value: bool) -> void:
	if is_selected == value:
		return
	is_selected = value
	if value:
		_apply_selected_state()
	else:
		_apply_unselected_state()

# 选中：底图切换成角色纯背景底图（无滤镜）+ 打开立绘（OutsideArt，最顶层）立即放大冲出边框
#       + 白边闪烁 + 显示 1P/2P
func _apply_selected_state() -> void:
	# 1. 底图直接切换成角色纯背景底图，且无滤镜
	if _background != null:
		_background.visible = false
	if _selected_background != null:
		_selected_background.visible = true
		_selected_background.modulate = Color.WHITE # 无滤镜、完整彩色
	if _inside_art != null:
		_inside_art.visible = false        # InsideArt 永久禁用（不参与渲染）
	if _normal_frame != null:
		_normal_frame.visible = false
	if _selected_frame != null:
		_selected_frame.visible = true
		_selected_frame.modulate = Color.WHITE
	if _outside_art != null:
		# 只有选中状态才把角色立绘打开，并放在最顶层渲染
		_outside_art.visible = _outside_draw_size != Vector2.ZERO
		_outside_art.modulate = Color.WHITE # 完整彩色
		# 选中瞬间立刻放大 + 上移（以底部中心为锚点向上生长，冲出格子边框）
		var overshoot := selected_scale * 1.12
		_outside_art.scale = Vector2(overshoot, overshoot)
		_outside_art.position = _outside_base_position() + Vector2(0.0, selected_rise)
		if not Engine.is_editor_hint():
			var tween := create_tween()
			tween.tween_property(_outside_art, "scale", Vector2(selected_scale, selected_scale), 0.12)

# 取消选中：直接隐藏 OutsideArt（不再切回 InsideArt）+ 底图切回角色专属底图并压暗（6 条复位）
func _apply_unselected_state() -> void:
	is_confirmed = false
	# ① 隐藏 1P/2P 图片并清空图片内容，禁止残留
	selection_tag = 0
	if _tag != null:
		_tag.texture = null
		_tag.visible = false
	# ② 隐藏选中白边
	if _selected_frame != null:
		_selected_frame.visible = false
		_selected_frame.modulate = Color.WHITE
	# ③ outside 外侧精灵（立绘）直接隐藏，不再切回 inside 精灵
	if _outside_art != null:
		_outside_art.visible = false
		_outside_art.scale = Vector2.ONE
		_outside_art.position = _outside_base_position()
		_outside_art.modulate = Color.WHITE
	# ④ inside 精灵 scale 强制重置为 1（代码预留，但永久隐藏、不参与渲染）
	if _inside_art != null:
		_inside_art.visible = false
		_inside_art.scale = Vector2.ONE
	# ⑤ 底图直接切换回角色专属底图，并被代码压暗
	if _selected_background != null:
		_selected_background.visible = false
	if _background != null:
		_background.visible = true
		_background.modulate = Color(unselected_dim, unselected_dim, unselected_dim, 1.0)
	# 只显示普通边框（不显示白边闪烁）
	if _normal_frame != null:
		_normal_frame.visible = true

# 最终确认：底色 / 角色 / 边框三者一起白色同步闪烁
func set_confirmed(value: bool) -> void:
	is_confirmed = value
	if not value:
		_apply_selected_state()

# 设置 1P / 2P 标识（0 = 不显示）
func set_selection_tag(value: int) -> void:
	selection_tag = value
	_apply_tag()

func _apply_tag() -> void:
	if _tag == null:
		return
	var path := ""
	if selection_tag == 1:
		path = tag_1p_path
	elif selection_tag == 2:
		path = tag_2p_path
	var texture := ArtLoader.load_texture(path) if not path.is_empty() else null
	if texture == null:
		_tag.texture = null
		_tag.visible = false # 缺 1P/2P 素材：不显示，也不生成占位
		return
	_tag.texture = UiArt.make_art_texture(texture)
	_tag.size = ArtLoader.used_rect(texture).size
	_tag.visible = true
	_place_tag()

# 选中边框的显示层级可切换（默认角色在前；打开 selected_frame_on_top 则白边压在角色上方）
func _apply_frame_layer() -> void:
	if _selected_frame == null:
		return
	_selected_frame.z_index = 10 if selected_frame_on_top else 8

# ------------------------------ 闪烁与点击 ------------------------------
func _process(_delta: float) -> void:
	if Engine.is_editor_hint():
		_editor_sync() # 编辑器：检测参数变化 → 重建预览；不跑闪烁
		return
	if not is_selected:
		return
	# 用全局时钟驱动，保证所有格子的闪烁完全同步
	_blink_time = float(Time.get_ticks_msec()) * 0.001
	var wave := 0.5 + 0.5 * sin(_blink_time * blink_speed * TAU) # 0~1
	if _selected_frame != null and _selected_frame.visible:
		_selected_frame.modulate.a = 0.45 + 0.55 * wave # 白边闪烁
	if is_confirmed:
		# 确认后：底色 / 角色 / 边框三者同步白闪（提亮到过曝的白色）
		var white_flash := 1.0 + 0.9 * wave
		var flash_color := Color(white_flash, white_flash, white_flash, 1.0)
		if _background != null:
			_background.modulate = flash_color
		if _outside_art != null:
			_outside_art.modulate = flash_color
		if _selected_frame != null:
			_selected_frame.modulate = flash_color
	elif is_selected:
		# 只选中未确认：底色与角色保持原色
		if _background != null:
			_background.modulate = Color.WHITE
		if _outside_art != null:
			_outside_art.modulate = Color.WHITE

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed \
			and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		slot_clicked.emit(self)
		accept_event()

# 点击判定区域：右侧裁掉 click_area_trim_right 像素（这张美术里相邻卡片有意重叠，
# 如果不裁，点左边卡片的右侧会自动点到右边卡片上）
func _has_point(point: Vector2) -> bool:
	if point.x < 0.0 or point.y < 0.0 or point.y > size.y:
		return false
	return point.x <= size.x - maxf(click_area_trim_right, 0.0)

# ------------------------------ 对外查询（供选角界面使用） ------------------------------
func get_character_id() -> String:
	return character_id

func get_display_name() -> String:
	return display_name

func is_random() -> bool:
	return is_random_slot

# ------------------------------ 编辑器实时预览 ------------------------------
# 在编辑器里改任意参数 → 自动重建图层，直接看到立绘真实效果（不用 F5）
func _editor_state() -> Dictionary:
	return {
		"size": size, "bg": slot_bg_path, "sbg": selected_bg_path, "art": character_art_path,
		"nframe": normal_frame_path, "sframe": selected_frame_path,
		"t1": tag_1p_path, "t2": tag_2p_path,
		"fit": art_fit_ratio, "art_px": art_height_px, "art_scale": art_scale,
		"offset": art_offset, "inset": art_bottom_inset,
		"bg_scale": bg_scale, "bg_offset": bg_offset,
		"tag_pad": tag_padding, "tag_align": tag_align_x, "tag_size": tag_size,
		"sel": editor_preview_selected, "ptag": editor_preview_tag,
		"dim": unselected_dim, "sscale": selected_scale, "srise": selected_rise,
	}

func _editor_sync() -> void:
	var state := _editor_state()
	if state == _editor_snapshot:
		return
	_editor_snapshot = state
	_rebuild_layers_now()
	_editor_apply_preview()

# 立即重建图层（编辑器里拖动参数时用；先移除再释放，避免出现一帧的重影）
func _rebuild_layers_now() -> void:
	for child in get_children():
		remove_child(child)
		child.free()
	_build_layers()
	_apply_frame_layer()

func _editor_apply_preview() -> void:
	is_confirmed = false
	if editor_preview_selected:
		is_selected = false # 先复位再走选中流程，保证状态干净
		set_selected(true)
		if _outside_art != null:
			_outside_art.scale = Vector2(selected_scale, selected_scale) # 编辑器里不要过冲动画
	else:
		is_selected = false
		_apply_unselected_state()
	if editor_preview_tag != 0:
		set_selection_tag(editor_preview_tag)
	else:
		set_selection_tag(0)

# ------------------------------ 入场动画 ------------------------------
# 入场动画：先闪白 → 轻微下落 → 回弹回正（不淡入，出现即完全可见）
func play_entrance(appear_offset_y: float = -22.0, flash_time: float = 0.10, drop_time: float = 0.18, settle_time: float = 0.22) -> void:
	var final_position := position
	# 1) 闪白：直接过曝到白色
	modulate = Color(2.6, 2.6, 2.6, 1.0)
	# 2) 轻微下落：从上方一点落下来
	position = final_position + Vector2(0.0, appear_offset_y)
	var tween := create_tween()
	tween.tween_property(self, "modulate", Color.WHITE, maxf(flash_time, 0.01))
	tween.parallel().tween_property(self, "position", final_position + Vector2(0.0, 6.0), maxf(drop_time, 0.01)) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	# 3) 回弹回正
	tween.tween_property(self, "position", final_position, maxf(settle_time, 0.01)) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

# 跳过入场动画：直接落到最终位置并恢复常态
func skip_entrance(final_position: Vector2) -> void:
	position = final_position
	modulate = Color.WHITE
	_apply_unselected_state()

func debug_status_line() -> String:
	return "SLOT%d(%s) id=%s avail=%d sel=%d tag=%d" % [
		slot_index, display_name, character_id, 1 if is_available else 0,
		1 if is_selected else 0, selection_tag
	]
