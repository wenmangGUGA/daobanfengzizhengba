extends Control
class_name PopupDialog

# =============================================================================
# 点击消失的文字提示弹窗
#   面板素材：复用 textures/战斗界面ui/暂停底图.png（没有专门弹窗素材，直接复用现成美术，不用色块）
#   文字：优先中文（FontService 自动找系统中文字体）；找不到中文字体时用英文兜底，避免空白方块
#   交互：鼠标点击画面任意位置 → 弹窗消失，并发出 dismissed 信号
# =============================================================================

signal dismissed   # 弹窗被点击关闭

@export var panel_texture_path: String = ""      # 留空 = 战斗界面ui/暂停底图.png
@export var panel_size: Vector2 = Vector2(560.0, 240.0) # 面板尺寸（可在检查器调）
@export var panel_tint: Color = Color(0.16, 0.16, 0.20, 1.0) # 面板压暗（保证白字清晰可读）
@export var font_size: int = 30                  # 文字字号
@export var text_color: Color = Color(1.0, 0.96, 0.85, 1.0) # 文字颜色
@export var text_outline_size: int = 8           # 文字描边粗细（提高可读性）
@export var text_outline_color: Color = Color(0.05, 0.03, 0.03, 1.0)
@export var use_chinese_text: bool = true        # 是否优先中文（系统无中文字体时自动英文兜底）

var _panel: TextureRect = null
var _label: Label = null
var _backdrop: ColorRect = null

func _ready() -> void:
	# 全屏锚点：尺寸由父节点自动撑满（不要再手动赋值 size，否则会和锚点冲突并报警告）
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP # 吃掉点击：弹窗期间不穿透到后面的格子
	# 【关键】弹窗必须盖在所有格子之上：格子内部用了相对 z_index（1/2/8/9/10），
	# 若弹窗停在默认 z=0，会被格子里的角色图盖住。
	z_index = 2000
	visible = false
	_build()

func _build() -> void:
	# 轻微压暗的全屏点击接收层（保证弹窗期间点击不会点到格子；本身不是占位图形）
	_backdrop = ColorRect.new()
	_backdrop.name = "ClickCatcher"
	_backdrop.color = Color(0, 0, 0, 0.35)
	_backdrop.size = GameConfig.SCREEN_SIZE
	_backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_backdrop)
	# 面板：复用暂停底图美术，等比拉伸到面板尺寸
	var path := panel_texture_path
	if path.is_empty():
		path = AssetPaths.UI_PAUSE_BACKGROUND
	var texture := ArtLoader.load_texture(path)
	if texture != null:
		_panel = TextureRect.new()
		_panel.texture = UiArt.make_art_texture(texture)
		_panel.stretch_mode = TextureRect.STRETCH_SCALE
		_panel.modulate = panel_tint # 压暗面板，保证白字清晰
		_panel.size = panel_size
		_panel.position = (GameConfig.SCREEN_SIZE - panel_size) * 0.5
		_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_panel)
	# 文字
	_label = Label.new()
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.size = panel_size
	_label.position = (GameConfig.SCREEN_SIZE - panel_size) * 0.5
	_label.add_theme_font_size_override("font_size", font_size)
	_label.add_theme_color_override("font_color", text_color)
	_label.add_theme_color_override("font_outline_color", text_outline_color)
	_label.add_theme_constant_override("outline_size", text_outline_size)
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_label)
	FontService.apply_font(_label) # 自动套用系统中文字体（取不到则保持默认字体）

# 显示提示：中文优先，系统无中文字体时自动英文兜底
func show_message(chinese_text: String, ascii_text: String) -> void:
	visible = true
	if _label != null:
		_label.text = FontService.pick_text(chinese_text, ascii_text) if use_chinese_text else ascii_text
	FontService.apply_font(_label)
	AudioService.play_sfx("ui_popup")

func hide_message() -> void:
	visible = false

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed \
			and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		hide_message()
		dismissed.emit()
		accept_event()

# 点击判定：整块全屏区域都可点击关闭
func _has_point(_point: Vector2) -> bool:
	return visible
