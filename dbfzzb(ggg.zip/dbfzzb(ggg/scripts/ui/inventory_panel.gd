extends Control
class_name InventoryPanel

# =============================================================================
# 背包 UI（B 键开关）
# 底图：res://textures/战斗界面ui/背包图.png
# 道具图标：预留目录 res://textures/items/（后期导入；缺素材只打印控制台警告，不画任何色块占位）
# 道具效果系统同样为预留：当前只负责“存进背包并可以查看”。
# =============================================================================

const PANEL_SCALE := 2.4                 # 背包底图放大倍数
const ICON_SIZE := Vector2(64.0, 64.0)   # 道具图标显示尺寸
const ROW_HEIGHT := 72.0                 # 每行高度

var _panel: TextureRect = null           # 背包底图
var _items_container: VBoxContainer = null # 道具列表容器
var _empty_label: Label = null           # 空背包提示（ASCII 文案）
var _coin_label: Label = null            # 金币总数

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	GameSession.inventory_changed.connect(_on_inventory_changed)
	GameSession.coins_changed.connect(_on_coins_changed)
	visible = false

func _build() -> void:
	var screen := GameConfig.SCREEN_SIZE
	_panel = UiArt.make_art_rect(self, AssetPaths.UI_INVENTORY_BACKGROUND)
	if _panel != null:
		_panel.scale = Vector2(PANEL_SCALE, PANEL_SCALE)
		UiArt.center_in(_panel, Rect2(Vector2.ZERO, screen))
	var panel_rect := Rect2((screen - GameConfig.HUD_CANVAS * PANEL_SCALE) * 0.5, GameConfig.HUD_CANVAS * PANEL_SCALE)
	if _panel != null:
		panel_rect = Rect2(_panel.position, _panel.size * PANEL_SCALE)
	UiArt.make_label(self, "INVENTORY", panel_rect.position + Vector2(24.0, 16.0), 24)
	_coin_label = UiArt.make_label(self, "COINS: 0", panel_rect.position + Vector2(24.0, 52.0), 18, Color(1.0, 0.85, 0.3, 1.0))
	_items_container = VBoxContainer.new()
	_items_container.position = panel_rect.position + Vector2(28.0, 90.0)
	_items_container.custom_minimum_size = Vector2(panel_rect.size.x - 56.0, 0.0)
	_items_container.add_theme_constant_override("separation", 8)
	add_child(_items_container)
	_empty_label = UiArt.make_label(self, "EMPTY", panel_rect.position + Vector2(40.0, 150.0), 16, Color(0.75, 0.75, 0.75, 1.0))
	UiArt.make_label(self, "B / PAD BACK  TO CLOSE", panel_rect.position + Vector2(24.0, panel_rect.size.y - 40.0), 14, Color(0.8, 0.8, 0.8, 1.0))

# 背包内容刷新：有图标的显示图标，没有图标的只显示名称（不生成占位图）
func _on_inventory_changed(items: Array) -> void:
	if _items_container == null:
		return
	for child in _items_container.get_children():
		child.queue_free()
	_empty_label.visible = items.is_empty()
	for item in items:
		var row := HBoxContainer.new()
		row.custom_minimum_size = Vector2(0.0, ROW_HEIGHT)
		row.add_theme_constant_override("separation", 12)
		var texture: Texture2D = item.get("icon_texture", null) as Texture2D
		if texture != null:
			var icon := TextureRect.new()
			icon.texture = UiArt.make_art_texture(texture)
			icon.custom_minimum_size = ICON_SIZE
			icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			row.add_child(icon)
		var name_label := Label.new()
		name_label.text = String(item.get("name", item.get("id", "ITEM")))
		name_label.add_theme_font_size_override("font_size", 16)
		row.add_child(name_label)
		_items_container.add_child(row)

func _on_coins_changed(total_coins: int) -> void:
	if _coin_label != null:
		_coin_label.text = "COINS: %d" % total_coins

func open() -> void:
	visible = true
	_on_inventory_changed(GameSession.inventory)
	_on_coins_changed(GameSession.coins)

func close() -> void:
	visible = false

func toggle() -> void:
	if visible:
		close()
	else:
		open()
