extends Node

# =============================================================================
# 开发辅助工具（自动加载单例，可安全删除，不影响正式流程）
# 功能：
#   1. F12：保存当前画面截图到 user://screenshots/；
#   2. 命令行直启关卡（便于自动化验证）：godot --path <工程> -- --level --players=2
#   3. 命令行截图：--capture=<绝对路径> --capture-frame=120（第 N 帧后截图并退出）
#   4. 命令行自动演示：--autopilot（按固定时间轴模拟按键并每秒打印战斗状态）
#   5. 命令行流程截图自检：--shots=<目录>（依次截取菜单 / 战斗 / 暂停 / 结算画面）
# 正式游玩时若不带任何命令行参数，本工具完全静默。
# =============================================================================

const SCREENSHOT_DIR := "user://screenshots/"

# 自动演示时间轴：[秒, 动作名, 是否按下]
const AUTOPILOT_SCRIPT := [
	[0.5, "p1_move_right", true],
	[2.5, "p1_move_right", false],
	[2.6, "p1_attack", true],
	[2.7, "p1_attack", false],
	[3.4, "p1_move_right", true],
	[4.4, "p1_move_right", false],
	[4.5, "p1_dodge", true],
	[4.6, "p1_dodge", false],
	[6.0, "p1_move_down", true],
	[6.6, "p1_move_down", false],
	[7.0, "p2_move_left", true],
	[8.0, "p2_move_left", false],
	[8.2, "p2_attack", true],
	[8.3, "p2_attack", false],
	[10.0, "debug_sp_full_only", true],
	[10.1, "debug_sp_full_only", false],
	[11.0, "p1_ultimate", true],
	[11.1, "p1_ultimate", false],
	[16.0, "p1_move_right", true],
	[27.0, "p1_move_right", false],
]

# 流程截图自检时间轴：[秒, 类型, 参数, 参数2]
# 启动流程：启动提示图 → 标题页整图(点击) → 标题底图渐显 → 图标渐显 → 选角界面
#          （黑边开幕 → 字幕/底部装饰 → 7 格依次显现 → 点格子/弹窗/确认）→ 关卡 → 大招 → 暂停 → 设置
# click 类型的两个参数是画面比例坐标（0~1）
const SHOT_SCRIPT := [
	[0.4, "shot", "01_splash_warning", ""],
	[1.3, "shot", "02_title_card", ""],
	[2.5, "click", "0.5", "0.5"],
	[3.1, "shot", "03_title_bg_fade_in", ""],
	[4.2, "shot", "04_title_icons_ready", ""],
	[4.5, "action", "menu_confirm", true],
	[4.6, "action", "menu_confirm", false],
	[4.66, "shot", "05_select_bars_closing", ""],
	[5.05, "shot", "06_select_subtitle_decor_in", ""],
	[6.0, "shot", "07_select_slots_appearing", ""],
	[7.4, "shot", "08_select_slots_ready", ""],
	[7.6, "click", "0.128", "0.398"],
	[8.2, "shot", "09_locked_character_dialog", ""],
	[8.4, "click", "0.5", "0.5"],
	[8.9, "click", "0.378", "0.398"],
	[9.5, "shot", "10_selected_1p", ""],
	[9.7, "click", "0.757", "0.398"],
	[10.3, "shot", "11_two_selected_1p_2p", ""],
	[10.5, "click", "0.503", "0.398"],
	[11.1, "shot", "12_too_many_dialog", ""],
	[11.3, "click", "0.5", "0.5"],
	[11.9, "shot", "13_before_confirm", ""],
	[12.1, "click", "0.504", "0.645"],
	[12.7, "shot", "14_confirm_white_flash", ""],
	[15.0, "shot", "15_level_scaled_character", ""],
	[15.2, "action", "p1_move_right", true],
	[17.0, "action", "p1_move_right", false],
	[17.1, "action", "p1_attack", true],
	[17.2, "action", "p1_attack", false],
	[17.7, "shot", "16_attack", ""],
	[17.9, "action", "p1_move_right", true],
	[18.1, "action", "p1_dodge", true],
	[18.2, "action", "p1_dodge", false],
	[18.6, "shot", "17_dodge_cooldown", ""],
	[18.8, "action", "p1_move_right", false],
	[19.0, "action", "debug_sp_full_cast", true],
	[19.1, "action", "debug_sp_full_cast", false],
	[19.5, "shot", "18_ultimate", ""],
	[21.0, "shot", "19_after_ultimate", ""],
	[21.2, "action", "pause_menu", true],
	[21.3, "action", "pause_menu", false],
	[22.1, "shot", "20_pause_menu", ""],
	[22.3, "action", "menu_down", true],
	[22.4, "action", "menu_down", false],
	[22.6, "action", "menu_down", true],
	[22.7, "action", "menu_down", false],
	[23.1, "action", "menu_confirm", true],
	[23.2, "action", "menu_confirm", false],
	[24.1, "shot", "21_settings_menu", ""],
	[24.3, "action", "pause_menu", true],
	[24.4, "action", "pause_menu", false],
	[25.1, "action", "menu_confirm", true],
	[25.2, "action", "menu_confirm", false],
	[25.9, "shot", "22_resumed", ""],
]

var _capture_path: String = ""      # 命令行截图输出路径
var _capture_frame: int = 60        # 命令行截图触发帧
var _boot_characters: Array = []    # 直启关卡时的角色 id（--character=）
var _scripted_actions: Array = []   # 指定帧触发的动作（--act=帧:动作，可重复）
var _burst_dir: String = ""         # 连续截图目录（--burst=）
var _burst_from: int = 0            # 连续截图起始帧
var _burst_count: int = 0           # 连续截图张数
var _burst_step: int = 1            # 连续截图间隔帧
var _boot_level: bool = false       # 命令行直启关卡
var _boot_players: int = 1          # 直启关卡时的玩家数量
var _autopilot: bool = false        # 命令行自动演示
var _shots_dir: String = ""         # 流程截图输出目录
var _frame_counter: int = 0         # 帧计数（截图用）
var _autopilot_time: float = 0.0    # 自动演示计时
var _autopilot_index: int = 0       # 自动演示时间轴游标
var _shots_time: float = 0.0        # 流程截图计时
var _shots_index: int = 0           # 流程截图时间轴游标
var _status_timer: float = 0.0      # 状态打印计时

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_parse_command_line()
	if not _shots_dir.is_empty() or _autopilot:
		Engine.max_fps = 60 # 自动化运行时锁定 60 帧，保证时间轴与帧率一致
	if _boot_level or _autopilot:
		_boot_level = true
		call_deferred("_boot_into_level")

func _process(delta: float) -> void:
	_frame_counter += 1
	if not _scripted_actions.is_empty() or not _burst_dir.is_empty():
		_process_scripted()
	if not _capture_path.is_empty() and _frame_counter >= _capture_frame:
		_save_screenshot(_capture_path)
		print("[开发工具] 已截图：", _capture_path)
		get_tree().quit()
		return
	if not _shots_dir.is_empty():
		_process_shots(delta)
	if _autopilot:
		_process_autopilot(delta)
	if _autopilot:
		_status_timer += delta
		if _status_timer >= 1.0:
			_status_timer = 0.0
			print("[开发工具] 战斗状态：", _collect_status())

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if (event as InputEventKey).physical_keycode == KEY_F12:
			var path := SCREENSHOT_DIR + "shot_%d.png" % Time.get_ticks_msec()
			_save_screenshot(path)
			print("[开发工具] 已截图：", ProjectSettings.globalize_path(path))

# ------------------------------ 内部实现 ------------------------------
func _parse_command_line() -> void:
	var args: Array = []
	args.append_array(OS.get_cmdline_args())
	args.append_array(OS.get_cmdline_user_args())
	for arg in args:
		var text := String(arg)
		if text == "--level":
			_boot_level = true
		elif text == "--autopilot":
			_boot_level = true
			_autopilot = true
		elif text.begins_with("--shots="):
			_shots_dir = text.split("=", true, 1)[1]
		elif text.begins_with("--players="):
			_boot_players = clampi(text.split("=")[1].to_int(), 1, GameConfig.MAX_PLAYERS)
		elif text.begins_with("--capture="):
			_capture_path = text.split("=", true, 1)[1]
		elif text.begins_with("--capture-frame="):
			_capture_frame = maxi(text.split("=", true, 1)[1].to_int(), 1)
		elif text.begins_with("--character="):
			# 直启关卡时指定角色（逗号分隔），例如 --character=traveler 或 --character=swordsman,traveler
			_boot_characters = text.split("=", true, 1)[1].split(",", false)
		elif text.begins_with("--act="):
			# 在指定帧发送动作，可重复：--act=90:p1_attack（按下即抬起）
			#   --act=90:p1_move_right:hold  一直按住（测持续移动）
			#   --act=200:p1_move_right:release 松开
			var parts := text.split("=", true, 1)[1].split(":", false)
			if parts.size() >= 2:
				var mode := String(parts[2]) if parts.size() >= 3 else "tap"
				_scripted_actions.append({"frame": parts[0].to_int(), "action": parts[1], "mode": mode})
		elif text.begins_with("--burst="):
			# 连续截图：--burst=目录|起始帧|张数|间隔帧（用 | 分隔，避免 Windows 路径里的冒号冲突）
			var bp := text.split("=", true, 1)[1].split("|", false)
			if bp.size() == 4:
				_burst_dir = bp[0]
				_burst_from = maxi(bp[1].to_int(), 1)
				_burst_count = maxi(bp[2].to_int(), 1)
				_burst_step = maxi(bp[3].to_int(), 1)
				DirAccess.make_dir_recursive_absolute(_burst_dir)
				print("[开发工具] 连续截图：目录=%s 起始帧=%d 张数=%d 间隔=%d"
					% [_burst_dir, _burst_from, _burst_count, _burst_step])
			else:
				print("[开发工具] --burst 参数格式应为：--burst=目录|起始帧|张数|间隔帧")

func _boot_into_level() -> void:
	GameSession.game_mode = _boot_players
	GameSession.reset_run()
	# 直启关卡时可指定角色（不填则按 GameSession 默认：1P 剑士 / 2P 旅者）
	if not _boot_characters.is_empty():
		GameSession.set_selected_characters(_boot_characters)
	print("[开发工具] 直启关卡：玩家数量 = %d 角色 = %s" % [_boot_players, str(GameSession.selected_characters)])
	SceneRouter.start_level()

# 指定帧触发动作 + 连续截图（用于核对具体动作/特效的表现）
func _process_scripted() -> void:
	for item in _scripted_actions:
		if int(item["frame"]) == _frame_counter:
			var mode := String(item.get("mode", "tap"))
			print("[开发工具] 第 %d 帧触发动作：%s（%s）" % [_frame_counter, String(item["action"]), mode])
			if mode == "hold":
				_send_action(String(item["action"]), true)
			elif mode == "release":
				_send_action(String(item["action"]), false)
			else:
				_send_action(String(item["action"]), true)
				# 按下后立刻抬起（单击）
				_send_action(String(item["action"]), false)
	if not _burst_dir.is_empty() and _frame_counter >= _burst_from:
		var offset := _frame_counter - _burst_from
		if offset % _burst_step == 0:
			var index := offset / _burst_step
			if index < _burst_count:
				_save_screenshot(_burst_dir.path_join("burst_%03d.png" % _frame_counter))
				print("[开发工具] 连续截图：", _frame_counter)

func _process_autopilot(delta: float) -> void:
	_autopilot_time += delta
	while _autopilot_index < AUTOPILOT_SCRIPT.size() and _autopilot_time >= float(AUTOPILOT_SCRIPT[_autopilot_index][0]):
		var step: Array = AUTOPILOT_SCRIPT[_autopilot_index]
		_send_action(String(step[1]), bool(step[2]))
		_autopilot_index += 1

# 流程截图自检：按时间轴模拟菜单 / 战斗按键并逐张截图
func _process_shots(delta: float) -> void:
	_shots_time += delta
	while _shots_index < SHOT_SCRIPT.size() and _shots_time >= float(SHOT_SCRIPT[_shots_index][0]):
		var step: Array = SHOT_SCRIPT[_shots_index]
		var kind := String(step[1])
		if kind == "shot":
			_save_screenshot(_shots_dir.path_join(String(step[2]) + ".png"))
			print("[流程截图] ", step[2])
		elif kind == "action":
			_send_action(String(step[2]), bool(step[3]))
		elif kind == "click":
			# 模拟鼠标点击屏幕（参数为画面比例坐标 0~1），用于验证"点击后消失"这类交互
			_send_click(Vector2(float(step[2]), float(step[3])))
		_shots_index += 1

# 模拟一次鼠标左键点击（按下 + 抬起）
func _send_click(ratio: Vector2) -> void:
	var screen_pos := Vector2(GameConfig.SCREEN_SIZE.x * ratio.x, GameConfig.SCREEN_SIZE.y * ratio.y)
	for pressed_state in [true, false]:
		var click := InputEventMouseButton.new()
		click.button_index = MOUSE_BUTTON_LEFT
		click.pressed = pressed_state
		click.position = screen_pos
		click.global_position = screen_pos
		Input.parse_input_event(click)

# 发送动作事件（同时驱动 Input 状态与 _input / _unhandled_input 事件链）
func _send_action(action_name: String, pressed: bool) -> void:
	if not InputMap.has_action(action_name):
		print("[开发工具] 未知动作：", action_name)
		return
	var event := InputEventAction.new()
	event.action = action_name
	event.pressed = pressed
	event.strength = 1.0 if pressed else 0.0
	Input.parse_input_event(event)

func _collect_status() -> String:
	var parts: Array[String] = []
	for node in get_tree().get_nodes_in_group("player_controller"):
		parts.append(String((node as Node).call("debug_status_line")))
	var level := get_tree().get_first_node_in_group("level_controller")
	if level != null:
		parts.append(String((level as Node).call("debug_status_line")))
	return " || ".join(parts)

func _save_screenshot(path: String) -> void:
	var image := get_viewport().get_texture().get_image()
	if path.begins_with("user://"):
		DirAccess.make_dir_recursive_absolute(SCREENSHOT_DIR)
	image.save_png(path)
