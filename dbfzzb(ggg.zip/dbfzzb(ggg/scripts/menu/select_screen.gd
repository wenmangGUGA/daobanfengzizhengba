extends Control
class_name SelectScreen

# =============================================================================
# 选角界面（第一期定稿）—— 一个场景同时完成"模式选择 + 角色选择"
#   入场流程：
#     ① 电影黑边开幕（上/下黑条同时移出屏幕，露出最底层静态底图 选角底图.png）
#     ② 顶部字幕（自上而下）+ 底部装饰图（自下而上）同步入场
#     ③ 7 个格子从左到右依次"立刻显现"（无淡入），每格：闪白 → 轻微下落 → 回弹回正
#        鼠标点击可跳过入场动画，直接显示全部格子并解锁交互
#   交互规则：
#     · 点击格子切换选中；最多同时选中 2 个；点击已选中格子取消
#     · 未完成角色（is_available=false）点击后进入选中态并弹「没做完！对不起！」，点击弹窗后退出选中
#     · 只有"可用角色"才计入选中列表；随机格从已开放角色里随机抽
#     · 点 player select：1 个可用角色 = 单人模式；2 个 = 双人模式；
#       0 个弹「请先选择角色」不跳转；第 3 个格子弹「最多只能选择两名角色」不生效
#     · 确认后：选中格子的底色+角色+边框三者白色同步闪烁，player select 保持闪烁，画面渐隐进入游戏
# 素材画布 1200x800 与窗口 1:1，所有位置使用素材原始像素，缩放系数统一由 fit 计算（默认 1.0）
# =============================================================================

const SLOT_SCENE := preload("res://scenes/entities/character_slot.tscn")
const MAX_SELECTED := 2

@export_group("Cinematic Intro") # ---------------- 电影黑边开幕 ----------------
@export var bar_open_time: float = 0.8        # 上下黑边同时打开（移出屏幕）的时长（需求：0.8s）
@export var black_bar_color: Color = Color(0, 0, 0, 1) # 黑边颜色（电影开幕用，不是素材占位）

@export_group("Intro Animation") # ---------------- 入场动画 ----------------
@export var subtitle_in_time: float = 0.3     # 顶部字幕从上降落到目标位置
@export var bottom_decor_in_time: float = 0.3 # 底部装饰图从下上升到目标位置
@export var sync_with_bar_open: bool = false  # true = 字幕/装饰与黑边开幕同时开始；false = 黑边开完再开始
@export var slot_appear_interval: float = 0.2 # 格子依次出现间隔（每格"立刻显现"，无淡入）
@export var slot_flash_time: float = 0.10     # 每格闪白时长
@export var slot_drop_time: float = 0.18      # 每格轻微下落时长
@export var slot_settle_time: float = 0.22    # 每格回弹回正时长
@export var slot_appear_offset_y: float = -22.0 # 每格起始位置相对最终位置的纵向偏移（负=从上方落下）

@export_group("Confirm") # ---------------- 确认与转场 ----------------
@export var confirm_flash_time: float = 0.9   # 确认后白闪时长（随后开始渐隐）
@export var screen_fade_time: float = 0.6     # 画面渐隐时长

@export_group("Popup Text") # ---------------- 弹窗文案 ----------------
@export var text_incomplete_cn: String = "没做完！对不起！"
@export var text_incomplete_ascii: String = "NOT FINISHED YET! SORRY!"
@export var text_no_selection_cn: String = "请先选择角色"
@export var text_no_selection_ascii: String = "PLEASE SELECT A CHARACTER FIRST"
@export var text_too_many_cn: String = "最多只能选择两名角色"
@export var text_too_many_ascii: String = "AT MOST TWO CHARACTERS"

@onready var _canvas: Control = $ScreenCanvas
@onready var _slots_root: Control = $ScreenCanvas/Slots

var _slots: Array[CharacterSlot] = []          # 7 个格子（按序号）
var _selected_slots: Array[CharacterSlot] = [] # 已选中的【可用】角色格子（按点击顺序 = 1P / 2P）
var _locked_selected_slot: CharacterSlot = null # 因"未完成"而临时选中的格子
var _intro_finished: bool = false              # 入场动画是否已结束
var _intro_skipped: bool = false               # 是否被点击跳过
var _confirm_locked: bool = false              # 确认后锁定输入
var _final_positions: Array[Vector2] = []      # 各格子最终位置（跳过动画时要用）
var _tween_subtitle: Tween = null
var _tween_decor: Tween = null
var _bars_control: Control = null
var _top_bar: ColorRect = null
var _bottom_bar: ColorRect = null
var _subtitle: TextureRect = null
var _decor: TextureRect = null
var _confirm_button: TextureButton = null
var _confirm_blink_tween: Tween = null # PLAYER SELECT 的闪烁循环
var _popup: PopupDialog = null
var _fade: ColorRect = null

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_screen()
	_collect_slots()
	_prepare_intro()
	_play_intro()

# ------------------------------ 场景构建 ------------------------------
func _build_screen() -> void:
	var backdrop := $ScreenCanvas/Backdrop as TextureRect
	var decor := $ScreenCanvas/BottomDecoration as TextureRect
	var subtitle := $ScreenCanvas/TopSubtitle as TextureRect
	_subtitle = subtitle
	_decor = decor
	# 素材全部按原始像素摆放（画布=窗口=1200x800）
	_apply_art(backdrop, AssetPaths.SELECT_BACKDROP)
	_apply_art(_decor, AssetPaths.SELECT_BOTTOM_DECOR)
	_apply_art(_subtitle, AssetPaths.SELECT_TOP_SUBTITLE)
	# player select 闪烁确认按钮（放在画布里；z 抬高到格子之上，避免被格子里的角色图盖住）
	_confirm_button = UiArt.make_art_button(_canvas, AssetPaths.SELECT_CONFIRM_TEXT)
	if _confirm_button != null:
		_confirm_button.z_index = 500
		_confirm_button.visible = false # 需求：选中一个格子之后它才出现（见 _update_confirm_button_visibility）
		_confirm_button.pressed.connect(_on_confirm_pressed)
	# 文字提示弹窗（复用暂停底图作面板；弹窗内部自带高 z，保证盖住所有格子）
	_popup = PopupDialog.new()
	_popup.name = "Popup"
	add_child(_popup)
	_popup.dismissed.connect(_on_popup_dismissed)
	# 渐隐遮罩（确认后画面渐隐进游戏；z 最高，盖住一切）
	_fade = ColorRect.new()
	_fade.name = "FadeOverlay"
	_fade.color = Color(0, 0, 0, 0)
	_fade.size = GameConfig.SCREEN_SIZE
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.z_index = 3000
	add_child(_fade)
	# 电影黑边（z 高于格子、低于弹窗，开幕时能遮住全部内容）
	_bars_control = $CinematicBars
	_bars_control.z_index = 1500
	_top_bar = $CinematicBars/TopBar
	_bottom_bar = $CinematicBars/BottomBar
	_top_bar.color = black_bar_color
	_bottom_bar.color = black_bar_color

# 按素材原始有效像素摆放（不缩放、不拉伸）
func _apply_art(node: TextureRect, path: String) -> void:
	if node == null:
		return
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		node.texture = null # 缺素材：控制台已告警，不显示任何占位图形
		return
	var used := ArtLoader.used_rect(texture)
	node.texture = UiArt.make_art_texture(texture)
	node.position = used.position
	node.size = used.size
	node.stretch_mode = TextureRect.STRETCH_SCALE

func _collect_slots() -> void:
	_slots.clear()
	for child in _slots_root.get_children():
		var slot := child as CharacterSlot
		if slot == null:
			continue
		_slots.append(slot)
		slot.slot_clicked.connect(_on_slot_clicked)
	_slots.sort_custom(func(a: CharacterSlot, b: CharacterSlot) -> bool: return a.slot_index < b.slot_index)

# player select 文字闪烁（需求：选中一个格子后出现，并带着闪烁动画）
func _start_confirm_text_blink() -> void:
	if _confirm_button == null:
		return
	_stop_confirm_text_blink()
	_confirm_blink_tween = _confirm_button.create_tween()
	_confirm_blink_tween.set_loops()
	_confirm_blink_tween.tween_property(_confirm_button, "modulate:a", 0.45, 0.45)
	_confirm_blink_tween.tween_property(_confirm_button, "modulate:a", 1.0, 0.45)

func _stop_confirm_text_blink() -> void:
	if _confirm_blink_tween != null and _confirm_blink_tween.is_valid():
		_confirm_blink_tween.kill()
	_confirm_blink_tween = null

# 需求：PLAYER SELECT 平时不显示；选中一个格子后带着闪烁动画出现；
#       全部取消选中后再次隐藏（确认锁定后保持显示并继续闪烁）
func _update_confirm_button_visibility() -> void:
	if _confirm_button == null:
		return
	var should_show := not _selected_slots.is_empty()
	if should_show == _confirm_button.visible:
		return
	_confirm_button.visible = should_show
	_confirm_button.modulate.a = 1.0
	if should_show:
		_start_confirm_text_blink()
	else:
		_stop_confirm_text_blink()

# ------------------------------ 入场动画 ------------------------------
func _prepare_intro() -> void:
	# 黑边初始完全遮挡画面（上下各半屏）
	_top_bar.position = Vector2.ZERO
	_top_bar.size = Vector2(GameConfig.SCREEN_SIZE.x, GameConfig.SCREEN_SIZE.y * 0.5)
	_bottom_bar.position = Vector2(0.0, GameConfig.SCREEN_SIZE.y * 0.5)
	_bottom_bar.size = Vector2(GameConfig.SCREEN_SIZE.x, GameConfig.SCREEN_SIZE.y * 0.5)
	# 字幕从画面上方外进入；装饰图从画面下方外进入
	if _subtitle != null:
		_subtitle.set_meta("final_position", _subtitle.position)
		_subtitle.position = _subtitle.position - Vector2(0.0, GameConfig.SCREEN_SIZE.y * 0.5)
	if _decor != null:
		_decor.set_meta("final_position", _decor.position)
		_decor.position = _decor.position + Vector2(0.0, GameConfig.SCREEN_SIZE.y * 0.5)
	# 格子记录最终位置，并先全部隐藏（等依次"立刻显现"）
	_final_positions.clear()
	for slot in _slots:
		_final_positions.append(slot.position)
		slot.visible = false
	# 入场动画播放期间禁止交互
	_set_interaction_enabled(false)

func _play_intro() -> void:
	# ① 电影黑边开幕：上下黑条同时移出屏幕
	var bar_tween := create_tween()
	bar_tween.set_parallel(true)
	bar_tween.tween_property(_top_bar, "position", Vector2(0.0, -GameConfig.SCREEN_SIZE.y * 0.5), bar_open_time) \
		.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	bar_tween.tween_property(_bottom_bar, "position", Vector2(0.0, GameConfig.SCREEN_SIZE.y), bar_open_time) \
		.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	# ② 顶部字幕 / 底部装饰：可选择与黑边同时开始，或黑边开完再开始
	if sync_with_bar_open:
		_play_subtitle_and_decor()
		await bar_tween.finished
	else:
		await bar_tween.finished
		_play_subtitle_and_decor()
	if _intro_skipped:
		return
	await get_tree().create_timer(maxf(subtitle_in_time, bottom_decor_in_time)).timeout
	if _intro_skipped:
		return
	# ③ 7 个格子从左到右依次立刻显现（每格闪白 → 轻微下落 → 回弹回正）
	await _play_slots_entrance()
	if _intro_skipped:
		return
	_intro_finished = true
	_set_interaction_enabled(true)
	AudioService.play_sfx("ui_select_ready")

func _play_subtitle_and_decor() -> void:
	if _subtitle != null:
		_tween_subtitle = create_tween()
		_tween_subtitle.tween_property(_subtitle, "position", _subtitle.get_meta("final_position"), subtitle_in_time) \
			.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	if _decor != null:
		_tween_decor = create_tween()
		_tween_decor.tween_property(_decor, "position", _decor.get_meta("final_position"), bottom_decor_in_time) \
			.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

func _play_slots_entrance() -> void:
	for index in range(_slots.size()):
		if _intro_skipped:
			return
		var slot := _slots[index]
		slot.visible = true # 立刻显现（不做任何淡入）
		slot.play_entrance(slot_appear_offset_y, slot_flash_time, slot_drop_time, slot_settle_time)
		AudioService.play_sfx("ui_slot_appear")
		if index < _slots.size() - 1:
			await get_tree().create_timer(maxf(slot_appear_interval, 0.0)).timeout

# 点击跳过入场动画：直接显示所有格子并解锁交互
func _skip_intro() -> void:
	if _intro_finished or _intro_skipped:
		return
	_intro_skipped = true
	if _tween_subtitle != null and _tween_subtitle.is_valid():
		_tween_subtitle.kill()
	if _tween_decor != null and _tween_decor.is_valid():
		_tween_decor.kill()
	# 黑边 / 字幕 / 装饰直接落到最终位置
	_top_bar.position = Vector2(0.0, -GameConfig.SCREEN_SIZE.y * 0.5)
	_bottom_bar.position = Vector2(0.0, GameConfig.SCREEN_SIZE.y)
	if _subtitle != null:
		_subtitle.position = _subtitle.get_meta("final_position")
	if _decor != null:
		_decor.position = _decor.get_meta("final_position")
	for index in range(_slots.size()):
		_slots[index].visible = true
		_slots[index].skip_entrance(_final_positions[index])
	_intro_finished = true
	_set_interaction_enabled(true)

func _set_interaction_enabled(enabled: bool) -> void:
	for slot in _slots:
		slot.mouse_filter = Control.MOUSE_FILTER_STOP if enabled else Control.MOUSE_FILTER_IGNORE
	if _confirm_button != null:
		_confirm_button.disabled = not enabled

# ------------------------------ 格子点击逻辑 ------------------------------
func _on_slot_clicked(slot: CharacterSlot) -> void:
	if not _intro_finished or _confirm_locked:
		_skip_intro() # 入场动画期间点击 = 跳过动画
		return
	# 弹窗未关闭时点击格子无效（弹窗自己会吃掉点击）
	if _popup != null and _popup.visible:
		return

	# 再次点击已选中格子 → 取消选择
	if slot.is_selected:
		_unselect_slot(slot)
		return
	# 未完成角色：进入选中态 + 弹「没做完！对不起！」
	if not slot.is_available:
		if _selected_slots.size() >= MAX_SELECTED:
			_popup.show_message(text_too_many_cn, text_too_many_ascii) # 已满两人：第三个格子不生效
			return
		_locked_selected_slot = slot
		slot.set_selected(true)
		_refresh_selection_tags()
		_popup.show_message(text_incomplete_cn, text_incomplete_ascii)
		return
	# 可用角色：最多 2 个
	if _selected_slots.size() >= MAX_SELECTED:
		_popup.show_message(text_too_many_cn, text_too_many_ascii)
		return
	_selected_slots.append(slot)
	slot.set_selected(true)
	_refresh_selection_tags()
	AudioService.play_sfx("ui_slot_select")

func _unselect_slot(slot: CharacterSlot) -> void:
	set_selected_slot_state(slot, false)
	AudioService.play_sfx("ui_slot_cancel")

func set_selected_slot_state(slot: CharacterSlot, value: bool) -> void:
	if value:
		if not _selected_slots.has(slot):
			_selected_slots.append(slot)
	else:
		_selected_slots.erase(slot)
		if _locked_selected_slot == slot:
			_locked_selected_slot = null
	slot.set_selected(value)
	_refresh_selection_tags()

# 按选中顺序刷新 1P / 2P 标识（第一个 = 1P，第二个 = 2P）
func _refresh_selection_tags() -> void:
	for index in range(_selected_slots.size()):
		_selected_slots[index].set_selection_tag(index + 1)
	if _locked_selected_slot != null and not _selected_slots.has(_locked_selected_slot):
		_locked_selected_slot.set_selection_tag(0)
	_update_confirm_button_visibility() # PLAYER SELECT：有选中才出现（带闪烁），全取消则隐藏

# 弹窗被点击关闭
func _on_popup_dismissed() -> void:
	# 未完成角色的提示关闭后：退出该格子的选中状态，且不计入选中列表
	if _locked_selected_slot != null:
		_locked_selected_slot.set_selected(false)
		_locked_selected_slot.set_selection_tag(0)
		_locked_selected_slot = null

# ------------------------------ 确认（player select） ------------------------------
func _on_confirm_pressed() -> void:
	if not _intro_finished or _confirm_locked:
		return
	if _popup != null and _popup.visible:
		return
	# 未选任何角色：提示且不跳转
	if _selected_slots.is_empty():
		_popup.show_message(text_no_selection_cn, text_no_selection_ascii)
		return
	_confirm_locked = true
	# 1) 选出最终角色 id（随机格在这里解析）
	var chosen_ids: Array[String] = []
	for slot in _selected_slots:
		chosen_ids.append(slot.get_character_id() if not slot.is_random() else _pick_random_character_id())
	# 2) 三者同步白闪
	for slot in _selected_slots:
		slot.set_confirmed(true)
	# 3) 画面渐隐后进入游戏
	GameSession.set_selected_characters(chosen_ids)
	print("[选角] 确认角色：", chosen_ids, " → %s模式" % ("双人" if chosen_ids.size() >= 2 else "单人"))
	await _fade_out()
	SceneRouter.start_level()

# 随机格抽取池：只包含已开放可用的角色
func _pick_random_character_id() -> String:
	var pool: Array[String] = []
	for slot in _slots:
		if slot.is_available and not slot.is_random() and not slot.get_character_id().is_empty():
			pool.append(slot.get_character_id())
	if pool.is_empty():
		return GameConfig.CHARACTER_SWORDSMAN
	return pool[randi() % pool.size()]

func _fade_out() -> void:
	if _fade == null:
		return
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	# 渐隐 tween 独立播放；等待时长取"白闪时长/渐隐时长"的较大值。
	# 【重要】不要 await 这个 tween：它可能比等待时长更早播完，
	# 而 await 一个已经 emit 过 finished 的 tween 会永久挂起，导致场景永远不切换。
	var tween := create_tween()
	tween.tween_property(_fade, "color:a", 1.0, maxf(screen_fade_time, 0.01))
	var wait_time := maxf(confirm_flash_time, screen_fade_time)
	await get_tree().create_timer(wait_time).timeout

# ------------------------------ 输入 ------------------------------
func _unhandled_input(event: InputEvent) -> void:
	# 点击任意位置跳过入场动画
	if not _intro_finished:
		if (event is InputEventMouseButton and (event as InputEventMouseButton).pressed) \
				or event.is_action_pressed("menu_confirm") or event.is_action_pressed("menu_cancel"):
			_skip_intro()
			_mark_handled()
			return
	# 入场结束后：回车 = 确认；ESC = 返回标题页
	if _confirm_locked:
		return
	if event.is_action_pressed("menu_confirm"):
		_on_confirm_pressed()
		_mark_handled()
	elif event.is_action_pressed("menu_cancel"):
		_mark_handled()
		if _popup != null and _popup.visible:
			_popup.hide_message()
			_on_popup_dismissed()
		else:
			SceneRouter.goto_title()

func _mark_handled() -> void:
	var viewport := get_viewport()
	if viewport != null:
		viewport.set_input_as_handled()

# ------------------------------ 调试 ------------------------------
func debug_status_line() -> String:
	var parts: Array[String] = []
	for slot in _slots:
		parts.append(slot.debug_status_line())
	return "SELECT intro=%d selected=%d | %s" % [1 if _intro_finished else 0, _selected_slots.size(), " ; ".join(parts)]
