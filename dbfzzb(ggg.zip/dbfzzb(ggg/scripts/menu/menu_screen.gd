extends Control
class_name MenuScreen

# =============================================================================
# 菜单界面基类（标题页 / 模式选择 / 角色选择通用）
# 画面规则：整幅美术设计画布等比缩放后居中；画布比例与窗口比例一致时即为「全屏无黑边」。
#   - 标题页 / 启动图：设计画布 384x256（3:2，与 1200x800 完全同比例）→ 全屏铺满；
#   - 模式 / 角色选择：设计画布 998x561（16:9）→ 上下留黑边，适配 16:9 电影比例。
# 布局规则：素材按“作者绘制的归一化位置”摆到设计画布上 —— 换图 / 重导素材后位置自动跟随。
# 交互规则：上下（或左右）切换、确认键进入、鼠标悬停与点击同样有效。
# =============================================================================

const HIGHLIGHT_BLINK_SPEED := 3.0                        # 选中高亮呼吸闪烁速度
const HIGHLIGHT_PADDING := 14.0                           # 方框类高亮套住选中项时四周留出的边距（像素）
const SELECTED_MODULATE := Color(1.25, 1.25, 1.25, 1.0)   # 没有高亮素材时的选中提亮
const SELECTED_SCALE := 1.12                              # 没有高亮素材时的选中放大倍数

var canvas: Control = null                                # 菜单设计画布
var design_canvas: Vector2 = GameConfig.MENU_DESIGN_CANVAS # 本屏使用的设计画布尺寸
var highlight: TextureRect = null                         # 选中高亮（位于按钮下层，可选）
var _highlight_fit_to_item: bool = false                  # 高亮是否按选中项大小等比套住（方框类素材）
var items: Array = []                                     # 菜单项 [{ button, callback }]
var selected_index: int = 0                               # 当前选中项

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	design_canvas = _design_canvas_size() # 先确定设计画布，再构建画面
	_build_frame()
	_build_menu()
	_select(0)
	_on_menu_ready()

# 子类可重写：本屏使用的美术设计画布尺寸
func _design_canvas_size() -> Vector2:
	return GameConfig.MENU_DESIGN_CANVAS

# 子类可重写：菜单构建完成后的回调（入场动画等）
func _on_menu_ready() -> void:
	pass

# 构建「底板 + 设计画布」：画布等比缩放并居中
func _build_frame() -> void:
	var backdrop := ColorRect.new() # 画布之外的留白/黑边（属于画面规范，不是缺失素材的占位图形）
	backdrop.color = GameConfig.MENU_LETTERBOX_COLOR
	backdrop.size = GameConfig.SCREEN_SIZE
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	backdrop.name = "Backdrop"
	add_child(backdrop)
	canvas = Control.new()
	canvas.name = "MenuCanvas"
	canvas.size = design_canvas
	canvas.mouse_filter = Control.MOUSE_FILTER_PASS
	var fit := minf(
		GameConfig.SCREEN_SIZE.x / design_canvas.x,
		GameConfig.SCREEN_SIZE.y / design_canvas.y
	)
	canvas.scale = Vector2(fit, fit)
	canvas.position = (GameConfig.SCREEN_SIZE - design_canvas * fit) * 0.5
	add_child(canvas)

# 子类实现：往 canvas 里添加背景与按钮
func _build_menu() -> void:
	pass

# 创建选中高亮（必须在按钮之前创建，保证位于按钮下层）
# highlight_path : 高亮素材路径（留空 = 不生成高亮，_select() 自动降级为"放大 + 提亮"反馈）
# fit_to_item    : true = 按选中项尺寸拉伸成方框"套住"按钮（方框类素材）；
#                  false = 保持素材原始尺寸并居中到选中项（横条类素材）
func create_highlight(highlight_path: String, fit_to_item: bool = false) -> void:
	if highlight_path.is_empty():
		return # 没有高亮素材：不生成任何占位图形，选中反馈走放大+提亮
	highlight = UiArt.make_art_rect(canvas, highlight_path)
	if highlight == null:
		return
	_highlight_fit_to_item = fit_to_item
	highlight.visible = false
	var blink := highlight.create_tween()
	blink.set_loops()
	blink.tween_property(highlight, "modulate:a", 0.45, 1.0 / HIGHLIGHT_BLINK_SPEED)
	blink.tween_property(highlight, "modulate:a", 1.0, 1.0 / HIGHLIGHT_BLINK_SPEED)

# 按素材归一化位置放置一张图（自动适配素材自身画布与设计画布的比例差）
func add_art(path: String) -> TextureRect:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		return null
	var layout := _compute_art_layout(texture)
	var node := TextureRect.new()
	node.texture = UiArt.make_art_texture(texture)
	node.position = layout["position"]
	node.size = layout["size"]
	node.stretch_mode = TextureRect.STRETCH_SCALE
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(node)
	return node

# 按素材归一化位置创建一个可交互图片按钮
func add_art_button(path: String) -> TextureButton:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		return null
	var layout := _compute_art_layout(texture)
	var button := TextureButton.new()
	button.texture_normal = UiArt.make_art_texture(texture)
	button.ignore_texture_size = true
	button.stretch_mode = TextureButton.STRETCH_SCALE
	button.position = layout["position"]
	button.size = layout["size"]
	button.focus_mode = Control.FOCUS_NONE
	canvas.add_child(button)
	return button

# 计算素材在设计画布中的位置与尺寸：
#   1. 素材画布宽高比与设计画布接近（如 384x256 / 998x561）→ 整幅等比放大到设计画布；
#   2. 画布比例差异较大（如 256x256 的按键素材）→ 保持素材原始像素尺寸，只按归一化位置摆放。
func _compute_art_layout(texture: Texture2D) -> Dictionary:
	var art_size := texture.get_size()
	var normalized := ArtLoader.normalized_used_rect(texture)
	var layout := {
		"position": normalized.position * design_canvas,
		"size": ArtLoader.used_rect(texture).size,
	}
	if art_size.y > 0.0:
		var art_ratio := art_size.x / art_size.y
		var design_ratio := design_canvas.x / design_canvas.y
		if absf(art_ratio - design_ratio) < 0.08 * design_ratio:
			layout["size"] = normalized.size * design_canvas
	return layout

# 注册菜单项：按钮 + 确认回调
func register_item(button: TextureButton, callback: Callable) -> void:
	if button == null:
		return
	var index := items.size()
	items.append({"button": button, "callback": callback})
	button.pivot_offset = button.size * 0.5 # 选中放大时以按钮中心为基准
	button.pressed.connect(func() -> void:
		_select(index)
		_confirm()
	)
	button.mouse_entered.connect(func() -> void: _select(index))

# 切换选中项
func _select(index: int) -> void:
	if items.is_empty():
		return
	selected_index = posmod(index, items.size())
	# 有高亮素材：高亮移到当前选项下层
	if highlight != null:
		var item: Dictionary = items[selected_index]
		var button: TextureButton = item["button"]
		highlight.visible = true
		if _highlight_fit_to_item:
			# 方框类素材：按选中项尺寸拉伸成方框套住按钮（不保持素材宽高比 —— 方框类高亮专用，
			# 这样才能同时套住"宽扁按钮"和"竖长立绘"，四周留出 HIGHLIGHT_PADDING 边距）
			var target_size := button.size + Vector2(HIGHLIGHT_PADDING, HIGHLIGHT_PADDING) * 2.0
			highlight.scale = Vector2(
				target_size.x / maxf(highlight.size.x, 1.0),
				target_size.y / maxf(highlight.size.y, 1.0)
			)
			highlight.position = button.position + button.size * 0.5 - target_size * 0.5
		else:
			highlight.position = button.position + (button.size - highlight.size) * 0.5
		return
	# 没有该素材：用「放大 + 提亮」做选中反馈（不生造任何占位图形）
	for item_index in range(items.size()):
		var target: TextureButton = items[item_index]["button"]
		if target == null:
			continue
		var is_selected := item_index == selected_index
		target.modulate = SELECTED_MODULATE if is_selected else Color.WHITE
		target.scale = Vector2(SELECTED_SCALE, SELECTED_SCALE) if is_selected else Vector2.ONE

func _confirm() -> void:
	if items.is_empty():
		return
	var item: Dictionary = items[selected_index]
	var button: TextureButton = item["button"]
	if button != null and button.disabled:
		return # 入场动画未播放完：按钮还不可用，键盘确认键同样无效
	var callback: Callable = item["callback"]
	callback.call()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("menu_up") or event.is_action_pressed("menu_left"):
		_mark_handled()
		_select(selected_index - 1)
	elif event.is_action_pressed("menu_down") or event.is_action_pressed("menu_right"):
		_mark_handled()
		_select(selected_index + 1)
	elif event.is_action_pressed("menu_confirm"):
		_mark_handled() # 先标记事件已处理，再执行可能切换场景的回调（切换场景会立刻释放本节点）
		_confirm()
	elif event.is_action_pressed("menu_cancel"):
		_mark_handled()
		_on_cancel()

# 标记事件已处理（必须在可能的场景切换之前调用）
func _mark_handled() -> void:
	var viewport := get_viewport()
	if viewport != null:
		viewport.set_input_as_handled()

# 子类可重写：取消键行为
func _on_cancel() -> void:
	pass
