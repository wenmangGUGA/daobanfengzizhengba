extends Control
class_name BootSplash

# =============================================================================
# 启动流程（游戏启动后的第一屏，两段全屏画面，全部 384x256 / 3:2 → 全屏无黑边）
#   第一段：游戏启动前提示.png        —— 停留 1 秒后【直接消失】（默认不淡出）
#   第二段：标题页.png（带游戏名的整图）—— 点击屏幕 / 按任意键后【直接消失】
#   随后切换到标题页场景：标题页底图.png 渐显 →「开始游戏」「设置」两个图标一起 0.5s 渐显
# 所有时间与开关都是 @export，可在检查器自由调节。
# =============================================================================

@export_group("Stage 1 - Splash Warning") # ---------------- 第一段：启动提示 ----------------
@export var splash_hold_time: float = 1.0        # 启动提示图停留时间（秒）
@export var splash_fade_out_time: float = 0.0    # 消失方式：0 = 直接消失（不淡出）；>0 = 淡出该时长
@export var splash_texture_path: String = ""     # 留空 = textures/标题页/游戏启动前提示.png

@export_group("Stage 2 - Title Card") # ---------------- 第二段：标题页整图 ----------------
@export var title_card_enabled: bool = true      # 是否播放第二段
@export var title_card_texture_path: String = "" # 留空 = textures/标题页/标题页.png
@export var title_card_wait_for_input: bool = true # true = 等点击屏幕 / 按键后消失
@export var title_card_auto_time: float = 0.0    # 自动前进时长（秒）；>0 时即使不点击也会自动消失
@export var title_card_ignore_input_time: float = 0.25 # 进画面前这段时间内的输入忽略（防止误触跳过）
@export var title_card_fade_out_time: float = 0.0 # 消失方式：0 = 直接消失（不淡出）；>0 = 淡出该时长

@export_group("Art") # ---------------- 画面 ----------------
@export var backdrop_color: Color = Color(0, 0, 0, 1) # 底色（画面之间的空档用，非缺失素材占位）

@export_group("Next Scene") # ---------------- 下一场景 ----------------
@export var next_scene_path: String = ""         # 留空 = SceneRouter.goto_title()（默认标题页）

var _canvas: Control = null                      # 设计画布（384x256）
var _image: TextureRect = null                   # 当前展示的整屏图（两段共用同一节点，换图即切换）
var _accepting_input: bool = false               # 当前是否接受"点击跳过"
var _skip_requested: bool = false                # 是否已收到点击 / 按键
var _advanced: bool = false                      # 是否已经切场景（防重复触发）

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP # 吃掉点击，避免点到后面的界面
	_build()
	_run_sequence()

# ------------------------------ 画面构建 ------------------------------
func _build() -> void:
	# 底色：两段画面切换的空档露出它，避免闪出引擎默认灰底
	var backdrop := ColorRect.new()
	backdrop.name = "Backdrop"
	backdrop.color = backdrop_color
	backdrop.size = GameConfig.SCREEN_SIZE
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(backdrop)
	# 设计画布：384x256 等比放大后居中 —— 3:2 窗口下正好铺满全屏（无黑边、无裁切）
	var design: Vector2 = GameConfig.TITLE_DESIGN_CANVAS
	_canvas = Control.new()
	_canvas.name = "BootCanvas"
	_canvas.size = design
	_canvas.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fit := minf(GameConfig.SCREEN_SIZE.x / design.x, GameConfig.SCREEN_SIZE.y / design.y)
	_canvas.scale = Vector2(fit, fit)
	_canvas.position = (GameConfig.SCREEN_SIZE - design * fit) * 0.5
	add_child(_canvas)
	_image = TextureRect.new()
	_image.name = "BootImage"
	_image.position = Vector2.ZERO
	_image.size = design
	_image.stretch_mode = TextureRect.STRETCH_SCALE
	_image.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_image.visible = false
	_canvas.add_child(_image)

# 切换当前展示的图片（缺素材时只隐藏图像，不生成任何占位图形）
func _set_stage_image(path: String) -> bool:
	var texture := ArtLoader.load_texture(path)
	if texture == null:
		_image.visible = false
		return false
	_image.texture = texture
	_image.position = Vector2.ZERO
	_image.size = GameConfig.TITLE_DESIGN_CANVAS
	_image.modulate = Color.WHITE
	_image.visible = true
	return true

# ------------------------------ 播放流程 ------------------------------
func _run_sequence() -> void:
	# 【第一段】启动提示图：停留 1 秒 → 直接消失
	if _set_stage_image(AssetPaths.TITLE_SPLASH if splash_texture_path.is_empty() else splash_texture_path):
		await get_tree().create_timer(maxf(splash_hold_time, 0.0)).timeout
		if not is_inside_tree():
			return
		await _dismiss_current(splash_fade_out_time)
	# 【第二段】标题页整图：点击屏幕 / 按任意键 → 直接消失
	if title_card_enabled:
		var card_path := AssetPaths.TITLE_CARD if title_card_texture_path.is_empty() else title_card_texture_path
		if _set_stage_image(card_path):
			await _wait_title_card_input()
			if not is_inside_tree():
				return
			await _dismiss_current(title_card_fade_out_time)
	# 进入标题页场景（底图渐显 → 两个图标一起渐显）
	_go_next()

# 当前画面消失：fade_time <= 0 直接消失（需求：1 秒后直接消失 / 点击后直接消失）
func _dismiss_current(fade_time: float) -> void:
	if _image == null:
		return
	if fade_time <= 0.0:
		_image.visible = false # 直接消失，不做淡出
		return
	var tween := create_tween()
	tween.tween_property(_image, "modulate:a", 0.0, fade_time)
	await tween.finished
	if _image != null:
		_image.visible = false

# 第二段等待：点击屏幕 / 任意按键；也可设置自动前进时长
func _wait_title_card_input() -> void:
	_skip_requested = false
	# 进画面前 0.25 秒内的输入忽略，避免上一步的按键/点击穿透导致误跳过
	await get_tree().create_timer(maxf(title_card_ignore_input_time, 0.0)).timeout
	if not is_inside_tree():
		return
	_accepting_input = true
	if title_card_auto_time > 0.0 and not title_card_wait_for_input:
		await get_tree().create_timer(title_card_auto_time).timeout
		_accepting_input = false
		return
	if title_card_auto_time > 0.0:
		# 两者都开：谁先到就按谁
		var remain := title_card_auto_time
		while remain > 0.0 and not _skip_requested and is_inside_tree():
			await get_tree().process_frame
			remain -= get_process_delta_time()
	else:
		while not _skip_requested and is_inside_tree():
			await get_tree().process_frame
	_accepting_input = false

func _go_next() -> void:
	if _advanced:
		return
	_advanced = true
	if not next_scene_path.is_empty():
		get_tree().change_scene_to_file(next_scene_path)
		return
	SceneRouter.goto_title() # 默认流程：进入标题页

# ------------------------------ 输入：点击屏幕 / 任意按键 ------------------------------
func _gui_input(event: InputEvent) -> void:
	# 鼠标点击屏幕（本节点 mouse_filter = STOP，所以点击会先到这里）
	if not _accepting_input:
		return
	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		_skip_requested = true

func _unhandled_input(event: InputEvent) -> void:
	if not _accepting_input:
		return
	var is_confirm := event.is_action_pressed("menu_confirm") or event.is_action_pressed("menu_cancel")
	var is_any_key := event is InputEventKey and (event as InputEventKey).pressed and not (event as InputEventKey).echo
	var is_pad := event is InputEventJoypadButton and (event as InputEventJoypadButton).pressed
	if is_confirm or is_any_key or is_pad:
		_skip_requested = true
