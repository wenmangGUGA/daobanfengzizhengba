extends MenuScreen
class_name TitleScreen

# =============================================================================
# 标题页（启动流程第三段，全屏展示）
#   素材：res://textures/标题页/
#   播放顺序：
#     ① 底图（标题页底图.png）渐显，默认 0.8s（可在检查器调节）
#     ② 底图渐显完成后，「开始游戏」「设置」两个图标【一起】渐显，默认 0.5s
#   说明：带游戏名文字的整图（标题页.png）已经在启动流程第二段展示过（点击后消失），
#        这里默认只用无文字底图 + 两个图标按钮。
# =============================================================================

@export_group("Intro Animation") # ---------------- 入场动画时间（秒） ----------------
@export var background_fade_in_time: float = 0.8   # 标题底图渐显时长
@export var button_fade_in_time: float = 0.5       # 两个图标按钮一起渐显的时长（底图渐显完成后才开始）
@export var button_fade_stagger: float = 0.0       # 按钮之间的淡入间隔（0 = 两个图标同时渐显）

@export_group("Art") # ---------------- 美术开关 ----------------
@export var use_legacy_title_art: bool = false     # 是否再把带游戏名的整图叠在底图之上（默认关闭）
@export var legacy_title_alpha: float = 1.0        # 叠加整图的不透明度

var _background: TextureRect = null                # 标题页底图
var _legacy_art: TextureRect = null                # 旧标题页整图（可选）
var _start_button: TextureButton = null            # 「开始游戏」
var _settings_button: TextureButton = null         # 「设置」
var _settings_menu: SettingsMenu = null            # 设置页面（复用战斗内设置界面）

# 标题页素材画布是 384x256（3:2），与 1200x800 窗口完全同比例 → 整幅放大 3.125 倍即全屏无黑边
func _design_canvas_size() -> Vector2:
	return GameConfig.TITLE_DESIGN_CANVAS

func _build_menu() -> void:
	# 1. 标题页底图（最底层，稍后做渐显）
	_background = add_art(AssetPaths.TITLE_BACKGROUND)
	# 2. 旧标题页整图（默认不启用；启用后叠在底图之上，用于显示游戏名文字）
	if use_legacy_title_art:
		_legacy_art = add_art(AssetPaths.TITLE_LEGACY_ART)
		if _legacy_art != null:
			_legacy_art.modulate.a = legacy_title_alpha
	# 3. 两个图标按钮：开始游戏 → 进入模式选择；设置 → 打开设置页面
	_start_button = add_art_button(AssetPaths.TITLE_START_ICON)
	register_item(_start_button, func() -> void: SceneRouter.goto_select_screen())
	_settings_button = add_art_button(AssetPaths.TITLE_SETTINGS_ICON)
	register_item(_settings_button, func() -> void: _open_settings())
	# 4. 设置页面（默认隐藏）
	_settings_menu = SettingsMenu.new()
	_settings_menu.name = "SettingsMenu"
	add_child(_settings_menu)
	_settings_menu.back_requested.connect(_close_settings)

# 菜单构建完成 → 播放入场动画
func _on_menu_ready() -> void:
	_play_intro()

# 入场动画：① 底图渐显 → ② 渐显结束后按钮才淡入浮现
func _play_intro() -> void:
	# 按钮初始透明且不可点击，等底图渐显完成后再淡入（避免"看不见却能点"）
	_set_buttons_interactable(false)
	for button in _all_buttons():
		button.modulate.a = 0.0
	# ① 底图渐显
	if _background != null:
		_background.modulate.a = 0.0
		var background_tween := create_tween()
		background_tween.tween_property(_background, "modulate:a", 1.0, maxf(background_fade_in_time, 0.0))
		await background_tween.finished
	# ② 底图渐显完成之后，再淡入浮现两个图标按钮
	var delay := 0.0
	for button in _all_buttons():
		var tween := create_tween()
		if delay > 0.0:
			tween.tween_interval(delay)
		tween.tween_property(button, "modulate:a", 1.0, maxf(button_fade_in_time, 0.0))
		delay += button_fade_stagger
	_set_buttons_interactable(true)
	# 入场完成后刷新一次选中反馈（此时按钮才真正可见）
	_select(selected_index)

func _all_buttons() -> Array[TextureButton]:
	var result: Array[TextureButton] = []
	if _start_button != null:
		result.append(_start_button)
	if _settings_button != null:
		result.append(_settings_button)
	return result

# 按钮可交互开关（淡入过程中禁止点击）
func _set_buttons_interactable(enabled_flag: bool) -> void:
	for button in _all_buttons():
		button.disabled = not enabled_flag
		button.mouse_filter = Control.MOUSE_FILTER_STOP if enabled_flag else Control.MOUSE_FILTER_IGNORE

func _open_settings() -> void:
	if _settings_menu != null:
		_settings_menu.open()

func _close_settings() -> void:
	if _settings_menu != null:
		_settings_menu.close()

func _on_cancel() -> void:
	if _settings_menu != null and _settings_menu.visible:
		_close_settings()
