extends RefCounted
class_name AssetPaths

# =============================================================================
# 素材路径总表（硬性规则：全部美术资源只读取 F:\godotXIANGMU\chongsheng\textures）
# 对应工程内路径：res://textures/...
# 缺素材时只做控制台文字警告，绝不渲染任何色块 / 几何占位物体。
# =============================================================================

# ------------------------------ 关卡背景 ------------------------------
const SCENE_BACKGROUND := "res://textures/场景.png" # 游戏内背景图（高度铺满画面，仅横向跟随相机）

# ------------------------------ 启动画面 / 标题页 ------------------------------
const TITLE_DIR := "res://textures/标题页/"
const TITLE_SPLASH := TITLE_DIR + "游戏启动前提示.png"          # 启动第一屏：启动提示图（停留 1 秒后直接消失）
const TITLE_CARD := TITLE_DIR + "标题页.png"                    # 启动第二屏：标题页整图（点击屏幕后消失）
const TITLE_BACKGROUND := TITLE_DIR + "标题页底图.png"          # 标题页底图（无文字，渐显）
const TITLE_START_ICON := TITLE_DIR + "标题页开始游戏图标.png"   # 「开始游戏」图标按钮
const TITLE_SETTINGS_ICON := TITLE_DIR + "标题页设置图标.png"    # 「设置」图标按钮
const TITLE_LEGACY_ART := TITLE_CARD                            # 旧名称兼容（= TITLE_CARD，带游戏名文字的整图）

# ------------------------------ 选角界面（第一期定稿：7 个格子 = 6 角色 + 1 随机） ------------------------------
# 素材画布统一为 1200x800（与窗口 1:1），因此位置/尺寸可直接使用素材原始像素
const SELECT_SCREEN_DIR := "res://textures/选角界面/"
const SELECT_BACKDROP := SELECT_SCREEN_DIR + "选角底图.png"                 # 最底层静态底图
const SELECT_TOP_SUBTITLE := SELECT_SCREEN_DIR + "顶部降落字幕.png"          # 顶部降落字幕（入场动画）
const SELECT_BOTTOM_DECOR := SELECT_SCREEN_DIR + "底部上升装饰图.png"        # 底部上升装饰图（入场动画）
const SELECT_CONFIRM_TEXT := SELECT_SCREEN_DIR + "选角完成后player select闪烁文字.png" # 最终确认按钮（闪烁）
const SELECT_FRAME_NORMAL := SELECT_SCREEN_DIR + "未选中状态普通边框.png"     # 未选中：普通边框
const SELECT_FRAME_SELECTED := SELECT_SCREEN_DIR + "选中状态边框.png"        # 选中：白色闪烁边框
const SELECT_TAG_1P := SELECT_SCREEN_DIR + "1p.png"                          # 1P 标识
const SELECT_TAG_2P := SELECT_SCREEN_DIR + "2p.png"                          # 2P 标识
const SELECT_RANDOM_BG := SELECT_SCREEN_DIR + "随机选角色底图.png"           # 随机选择格子的专属底色

# 每个角色三张图：
#   角色专属底图（角色名+底图.png，角色已由美术排在卡片安全区内）—— 未选中显示、被代码压暗
#   角色纯背景底图（角色名+纯背景底图.png，不含角色）              —— 选中时切换显示、无滤镜
#   角色立绘（角色名+立绘.png）                                   —— 仅选中时由 OutsideArt 显示并放大冲出边框
const SELECT_CHARACTER_ART := {
	"plush": {
		"name": "毛绒生物",
		"bg": SELECT_SCREEN_DIR + "毛绒生物底图.png",
		"selected_bg": SELECT_SCREEN_DIR + "毛绒生物纯背景底图.png",
		"art": SELECT_SCREEN_DIR + "毛绒生物立绘.png",
	},
	"egypt_dog": {
		"name": "埃及狗",
		"bg": SELECT_SCREEN_DIR + "埃及狗底图.png",
		"selected_bg": SELECT_SCREEN_DIR + "埃及狗纯背景底图.png",
		"art": SELECT_SCREEN_DIR + "埃及狗立绘.png",
	},
	"swordsman": {
		"name": "剑士",
		"bg": SELECT_SCREEN_DIR + "剑士底图.png",
		"selected_bg": SELECT_SCREEN_DIR + "剑士纯背景底图.png",
		"art": SELECT_SCREEN_DIR + "剑士立绘.png",
	},
	"vientiane": {
		"name": "万象",
		"bg": SELECT_SCREEN_DIR + "万象底图.png",
		"selected_bg": SELECT_SCREEN_DIR + "万象纯背景底图.png",
		"art": SELECT_SCREEN_DIR + "万象立绘.png",
	},
	"senluoluo": {
		"name": "森罗罗",
		"bg": SELECT_SCREEN_DIR + "森罗罗底图.png",
		"selected_bg": SELECT_SCREEN_DIR + "森罗罗纯背景底图.png",
		"art": SELECT_SCREEN_DIR + "森罗罗立绘.png",
	},
	"traveler": {
		"name": "旅者",
		"bg": SELECT_SCREEN_DIR + "旅者底图.png",
		"selected_bg": SELECT_SCREEN_DIR + "旅者纯背景底图.png",
		"art": SELECT_SCREEN_DIR + "旅者立绘.png",
	},
}

# ------------------------------ 战斗界面 UI ------------------------------
const BATTLE_UI_DIR := "res://textures/战斗界面ui/"
const UI_P1_TAG := BATTLE_UI_DIR + "1p标识.png"                   # 1P 标识
const UI_P2_TAG := BATTLE_UI_DIR + "2p标识.png"                   # 2P 标识
const UI_PORTRAIT_SWORDSMAN := BATTLE_UI_DIR + "剑士头像.png"      # 剑士头像
const UI_PORTRAIT_TRAVELER := BATTLE_UI_DIR + "旅者头像.png"       # 旅者头像（预留）
const UI_BAR_BASE := BATTLE_UI_DIR + "血条sp条总底图.png"          # 血条 / SP 条总底图
const UI_HP_BAR_FORMAT := BATTLE_UI_DIR + "血条%d格.png"           # 血条按格数切图（1~10 格）
const UI_SP_FULL := BATTLE_UI_DIR + "sp条满.png"                  # 满 SP 条填充
const UI_DODGE_COOLDOWN := BATTLE_UI_DIR + "闪避cd提示图.png"      # 闪避冷却提示图标（美术贴图预留位置）
const UI_PAUSE_ICON := BATTLE_UI_DIR + "暂停图标.png"             # 战斗内右上角暂停图标
const UI_PAUSE_BACKGROUND := BATTLE_UI_DIR + "暂停底图.png"        # 暂停菜单底图
const UI_PAUSE_CONTINUE := BATTLE_UI_DIR + "继续.png"             # 暂停菜单：继续游戏
const UI_PAUSE_EXIT := BATTLE_UI_DIR + "退出.png"                 # 暂停菜单：退出
const UI_INVENTORY_BACKGROUND := BATTLE_UI_DIR + "背包图.png"      # 背包 UI 底图
const UI_CHEST_COPPER := BATTLE_UI_DIR + "普通宝箱.png"           # 铜宝箱
const UI_CHEST_GOLD := BATTLE_UI_DIR + "金宝箱.png"               # 金宝箱
const UI_RESULT_CLEAR_BACKGROUND := BATTLE_UI_DIR + "任务完成底图.png" # 任务完成底图
const UI_RESULT_CLEAR_TEXT := BATTLE_UI_DIR + "任务完成字.png"      # 任务完成文字
const UI_RESULT_GAME_OVER := BATTLE_UI_DIR + "游戏失败.png"        # 游戏失败图

# ------------------------------ 剑士动画序列帧 ------------------------------
const SWORDSMAN_IDLE_DIR := "res://textures/剑士待机/"             # 待机序列帧
const SWORDSMAN_WALK_DIR := "res://textures/剑士移动/"             # 行走序列帧
const SWORDSMAN_ATTACK_DIR := "res://textures/剑士攻击/"           # 普攻序列帧
const SWORDSMAN_DODGE_IDLE_DIR := "res://textures/剑士闪避不动方向键/" # 闪避（未点方向键）
const SWORDSMAN_DODGE_MOVE_DIR := "res://textures/剑士拖动方向键的闪避/" # 闪避（点了方向键）
const SWORDSMAN_DEATH_DIR := "res://textures/剑士倒地/"            # 死亡倒地序列帧
const SWORDSMAN_ULTIMATE_DIR := "res://textures/剑士大招动画/"      # 大招动画（全屏展示）

# ------------------------------ 旅者（精灵表 + Aseprite json 标签） ------------------------------
const TRAVELER_DIR := "res://textures/旅者/"                                       # 旅者战斗素材目录
const TRAVELER_IDLE_SHEET := TRAVELER_DIR + "旅者待机.png"                          # 待机：4 帧（48×63，无 json）
const TRAVELER_MOVE_SHEET := TRAVELER_DIR + "旅者移动.png"                          # 移动：7 帧（73×63）
const TRAVELER_MOVE_JSON := TRAVELER_DIR + "旅者移动.json"                          # 标签：移动中循环(2-5)、结束后摇(6)
const TRAVELER_ATTACK_SHEET := TRAVELER_DIR + "旅者平a.png"                         # 平A 抬手：3 帧（73×63，无 json）
const TRAVELER_CHARGE_SHEET := TRAVELER_DIR + "旅者蓄力攻击.png"                     # 蓄力（角色本体）：8 帧（121×104）
const TRAVELER_CHARGE_JSON := TRAVELER_DIR + "旅者蓄力攻击 .json"                    # 标签：蓄力循环(0-2)、准备发射(3-4)、抛出去(5-7)
const TRAVELER_DISC_SHEET := TRAVELER_DIR + "旅者平a特效.png"                        # 平A 飞盘：6 帧（73×63）
const TRAVELER_DISC_JSON := TRAVELER_DIR + "旅者平a特效.json"                        # 标签：飞出去循环(1-3)、击中(4-5)
const TRAVELER_CHARGE_DISC_SHEET := TRAVELER_DIR + "旅者蓄力攻击特效.png"             # 蓄力飞盘：15 帧（121×104）
const TRAVELER_CHARGE_DISC_JSON := TRAVELER_DIR + "旅者蓄力攻击特效.json"             # 标签：蓄力(0-2)、准备发射(3-4)、飞盘飞出去的过程(6-8)、击中敌人(9-14)
const TRAVELER_HIT_FX := TRAVELER_DIR + "击中特效.png"                              # 平A 命中特效（闪白，48×48，单帧）

# ------------------------------ 怪物 / 金币 ------------------------------
const ENEMY_IDLE_DIR := "res://textures/怪物待机/"                 # 小怪待机序列帧
const ENEMY_WALK_DIR := "res://textures/怪物移动/"                 # 小怪行走序列帧
const COIN_DIR := "res://textures/金币动画/"                       # 金币动画序列帧

# ------------------------------ 预留接口路径（第一期无需美术） ------------------------------
const HEAVY_ATTACK_DIR := "res://textures/player/swordsman/heavy_attack/" # 蓄力重攻击动画预留
const ITEM_ICON_DIR := "res://textures/items/"                            # 道具图标预留
const AUDIO_DIR := "res://audio/"                                         # BGM / 音效预留
const ENEMY_RESERVED_DIR := "res://textures/enemy/"                       # 怪物素材预留目录
const DROPS_RESERVED_DIR := "res://textures/drops/"                       # 掉落物素材预留目录

# 血条按当前格数取图：1~10 格
static func hp_bar_path(hp: int) -> String:
	var clamped_hp: int = clampi(hp, 1, GameConfig.PLAYER_MAX_HP)
	return UI_HP_BAR_FORMAT % clamped_hp
