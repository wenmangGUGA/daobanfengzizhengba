extends Node

# =============================================================================
# 场景流程管理（自动加载单例）
# 完整流程：标题主界面 → 单人/双人模式选择 → 角色选择（第一期仅剑士）
#          → 进入关卡 → 任务完成 / 游戏失败 → 回到标题主界面
# =============================================================================

const BOOT_SPLASH_SCENE := "res://scenes/boot_splash.tscn"        # 启动画面（游戏启动第一屏）
const MAIN_MENU_SCENE := "res://scenes/main_menu.tscn"           # 标题页（底图渐显 → 按钮淡入）
const SELECT_SCREEN_SCENE := "res://scenes/select_screen.tscn"    # 选角界面（模式+角色一次选完）
const LEVEL_SCENE := "res://scenes/level_01.tscn"                 # 第一期关卡

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

# 进入启动画面（通常只在启动时走一次）
func goto_boot_splash() -> void:
	_change_scene(BOOT_SPLASH_SCENE)

# 进入标题页（启动画面淡出后的下一站）
func goto_title() -> void:
	_change_scene(MAIN_MENU_SCENE)

# 进入标题主界面（与 goto_title 等价，保留旧调用名以兼容关卡结算流程）
func goto_main_menu() -> void:
	_change_scene(MAIN_MENU_SCENE)

# 进入选角界面（会清空上一次的选角结果）
func goto_select_screen() -> void:
	GameSession.clear_selected_characters()
	_change_scene(SELECT_SCREEN_SCENE)

# 开始关卡（重置一局数据）
func start_level() -> void:
	GameSession.reset_run()
	_change_scene(LEVEL_SCENE)

# 重新开始当前关卡
func restart_level() -> void:
	GameSession.reset_run()
	_change_scene(LEVEL_SCENE)

# 退出游戏
func quit_game() -> void:
	get_tree().quit()

# 统一场景切换：恢复暂停状态后切场景
func _change_scene(path: String) -> void:
	if get_tree().paused:
		get_tree().paused = false
	var error := get_tree().change_scene_to_file(path)
	if error != OK:
		push_error("[场景流程] 切换场景失败：%s（错误码 %d）" % [path, error])
