extends RefCounted
class_name FontService

# =============================================================================
# 字体服务：解决"引擎默认字体不含中文字形"的问题
# 背景：Godot 默认主题字体（Open Sans）没有中文，直接用 Label 显示中文会变成空白方块。
# 方案：优先用系统字体（SystemFont 按字体名解析 + 允许系统兜底），
#      并**实际检测字形**是否可用；取不到中文字体时自动退回英文提示文本，
#      保证界面上永远不出现空白方块，也不会因为缺字体而报错。
# 说明：这是可选增强 —— 后续往工程里放一个中文字体文件即可全局替换（见 pick_text / apply_font）。
# =============================================================================

const CJK_FONT_NAMES := [
	"Microsoft YaHei",      # Windows 微软雅黑
	"微软雅黑",
	"SimHei",               # 黑体
	"黑体",
	"Noto Sans CJK SC",     # Linux / 通用开源中文字体
	"Source Han Sans SC",
	"PingFang SC",          # macOS
	"sans-serif",
]

static var _cjk_font: Font = null    # 解析到的中文字体（null = 系统没有可用中文字体）
static var _resolved: bool = false   # 是否已经检测过（只检测一次）

# 取中文字体（取不到返回 null，调用方需自行兜底）
static func get_cjk_font() -> Font:
	if _resolved:
		return _cjk_font
	_resolved = true
	var font := SystemFont.new()
	font.font_names = PackedStringArray(CJK_FONT_NAMES)
	font.allow_system_fallback = true
	# 检测常用汉字"没""请""最"，确认字形真的存在
	if font.has_char(0x6CA1) and font.has_char(0x8BF7):
		_cjk_font = font
		print("[字体服务] 已启用系统中文字体，中文提示可正常显示。")
	else:
		_cjk_font = null
		print("[字体服务] 未找到可用的系统中文字体，弹窗提示将使用英文兜底文本。")
	return _cjk_font

# 文本兜底：能显示中文就用中文，否则用英文（避免出现空白方块）
static func pick_text(chinese_text: String, ascii_text: String) -> String:
	return chinese_text if get_cjk_font() != null else ascii_text

# 把中文字体应用到指定 Label / 文本节点上
static func apply_font(label: Label) -> void:
	if label == null:
		return
	var font := get_cjk_font()
	if font != null:
		label.add_theme_font_override("font", font)
