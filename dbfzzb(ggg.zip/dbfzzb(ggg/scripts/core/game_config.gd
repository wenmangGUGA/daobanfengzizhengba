extends RefCounted
class_name GameConfig

# =============================================================================
# 全局数值配置（第一期：仅剑士）
# 所有可调参数集中在此文件，带中文注释，改数值不改逻辑。
# =============================================================================

# ------------------------------ 窗口 / 画面 ------------------------------
const WINDOW_SIZE := Vector2i(1200, 800)          # 固定窗口分辨率（原生 3:2 高清比例）
const SCREEN_SIZE := Vector2(1200.0, 800.0)       # 对局画面逻辑尺寸（像素，不拉伸不变形）
const MENU_DESIGN_CANVAS := Vector2(998.0, 561.0) # 菜单美术设计画布（16:9），整幅缩放后上下留黑边
const MENU_LETTERBOX_COLOR := Color(0, 0, 0, 1)   # 菜单上下黑边颜色（适配 16:9 电影比例）

# ------------------------------ 启动画面 / 标题页（全屏 3:2） ------------------------------
# 【为什么是 384x256】标题页素材画布就是 384x256（3:2），与 1200x800 窗口比例完全一致，
# 因此整幅等比放大 3.125 倍后正好铺满全屏 —— 真正意义上的「全屏展示」，无黑边、无裁切。
const TITLE_DESIGN_CANVAS := Vector2(384.0, 256.0)
const SPLASH_HOLD_TIME := 1.0            # 启动图停留显示时间（秒）
const SPLASH_FADE_OUT_TIME := 0.5        # 启动图淡出时间（秒）
const TITLE_BACKGROUND_FADE_IN := 0.8    # 标题页底图渐显时间（秒）
const TITLE_BUTTON_FADE_IN := 0.4        # 标题页按钮淡入时间（秒）
const TITLE_BUTTON_FADE_STAGGER := 0.0   # 多个按钮之间的淡入间隔（秒，0 = 同时淡入）

# ------------------------------ 相机 / 地图 ------------------------------
# 【注意】相机可调参数已全部改为 Camera2D 上的 @export（见 camera_controller.gd），
# 下面三项仅作为默认值参考保留，实际以检查器里导出的参数为准。
const CAMERA_ANCHOR_X_RATIO := 0.37   # 常态下玩家固定在画面左侧 37% 位置（对应导出 focus_ratio_x）
const CAMERA_SMOOTH_SPEED := 6.0      # 相机平滑跟随速度（对应导出 smooth_speed）
const CAMERA_FIXED_Y := 400.0         # 相机纵向完全固定（对应导出 fixed_y），不跟随玩家上下移动
const MAP_GOAL_X := 4100.0            # 通关触发点固定 X 坐标
const BACKGROUND_FILL_HEIGHT := 800.0 # 场景背景图高度铺满对局画面（宽高比不变，横向按比例延伸）

# ------------------------------ 玩家数值（固定写死可改） ------------------------------
const PLAYER_MAX_HP := 10             # 最大 HP：10 格血量
const PLAYER_HP_PER_HIT := 1          # 受击一次扣 1 格
const PLAYER_MAX_SP := 100            # SP 最大值
const PLAYER_SP_GAIN_NORMAL := 10     # 命中普通怪 +10 SP
const PLAYER_SP_GAIN_ELITE := 20      # 命中精英怪 +20 SP
const PLAYER_ULTIMATE_SP_COST := 100  # 大招必须 SP 满 100 才能释放，释放清空全部 SP
const PLAYER_DODGE_SP_COST := 5       # 闪避消耗 5 SP
const PLAYER_DODGE_INVINCIBLE := 2.0  # 闪避无敌时间（秒）
const PLAYER_DODGE_COOLDOWN := 2.0    # 闪避冷却时间（秒），冷却期间不可再次释放
const PLAYER_ATTACK_DAMAGE := 5       # 普攻伤害
const PLAYER_MOVE_SPEED := 260.0      # 玩家基础移动速度（像素/秒）—— 实际移速 = 基础移速 × 速度倍率
# 下面三项同样已改为玩家节点上的 @export（见 player_controller.gd 的 Scale / Move Speed 分组），
# 常量仅作为默认值参考；在场景检查器里改更方便，不用动代码。
const PLAYER_MOVE_SPEED_MULTIPLIER := 2.0 # 移动速度倍率默认值（需求：整体提升到 2 倍；微调只改这个倍率）
const PLAYER_CHARACTER_SCALE := 1.5   # 角色统一缩放系数默认值（精灵与碰撞体同步放大；1.0 = 原始大小）
const PLAYER_DODGE_SPEED_RATIO := 1.35 # 闪避冲刺速度 = 当前移速 × 该比例
const PLAYER_SPAWN_Y := 680.0         # 行走基准参考 Y（仅初始出生 Y，不锁死）
const PLAYER_SAFE_Y_MIN := 550.0      # 玩家安全 Y 区间上界（超出被隐形墙阻挡）
const PLAYER_SAFE_Y_MAX := 750.0      # 玩家安全 Y 区间下界（超出被隐形墙阻挡）

# 受击硬直 / 击退 / 无敌闪烁
const PLAYER_HURT_STUN := 0.4         # 被怪物击中：0.4 秒硬直（禁止移动/攻击/闪避）
const PLAYER_HURT_KNOCKBACK := 150.0  # 受击小幅击退速度（像素/秒）
const PLAYER_HURT_INVINCIBLE := 1.0   # 受伤后短暂无敌时间（秒），防连续扣血
const PLAYER_HURT_BLINK_INTERVAL := 0.08 # 无敌期闪烁间隔（秒）

# 死亡
const PLAYER_DEATH_ANIM_HOLD := 1.2   # 倒地动画结束后保持尸体的时间（秒）

# ------------------------------ 动画参数（帧率 / 循环 / 判定帧） ------------------------------
const ANIM_FPS_IDLE := 6.0            # 待机帧率
const ANIM_FPS_WALK := 10.0           # 行走帧率
const ANIM_FPS_ATTACK := 10.0         # 普攻帧率
const ANIM_FPS_DODGE := 12.0          # 闪避帧率
const ANIM_FPS_DEATH := 8.0           # 倒地帧率
const ANIM_FPS_ULTIMATE := 12.0       # 大招帧率
const ANIM_FPS_ENEMY_IDLE := 4.0      # 怪物待机帧率
const ANIM_FPS_ENEMY_WALK := 8.0      # 怪物行走帧率
const ANIM_FPS_COIN := 10.0           # 金币动画帧率

# 攻击判定帧：只在普攻动画的这些帧序号内开启攻击碰撞箱（严格对齐动画关键帧）
const ATTACK_ACTIVE_FRAMES := [1]
# 大招秒杀帧：大招动画播放到该帧序号时对怪物执行秒杀判定
const ULTIMATE_KILL_FRAME := 9

# 各动画的“脚底锚点”：帧内像素坐标，表示该帧中角色脚底中心点，保证所有动画站在同一地面线上（可微调）
const PLAYER_ANIM_ANCHORS := {
	"idle": Vector2(108.0, 234.0),
	"walk": Vector2(108.0, 218.0),
	"attack": Vector2(112.0, 220.0),
	"dodge_stand": Vector2(108.0, 227.0),
	"dodge_move": Vector2(108.0, 236.0),
	"death": Vector2(110.0, 244.0),
	"heavy_attack": Vector2(108.0, 220.0), # 预留：蓄力重攻击
}
const ENEMY_ANIM_ANCHOR := Vector2(128.0, 217.0) # 怪物帧内脚底锚点（左右居中）
const COIN_ANIM_ANCHOR := Vector2(145.0, 109.0)  # 金币帧内容中心（帧内像素坐标）

# ------------------------------ 旅者（精灵表）专用参数 ------------------------------
# 各动画的"脚底锚点"（帧内像素坐标）：按素材逐帧量测 —— 内容底边 y=62、脚底/影子中心 x≈25.5
const TRAVELER_ANIM_ANCHORS := {
	"idle": Vector2(25.5, 62.0),
	"walk": Vector2(25.5, 62.0),
	"walk_start": Vector2(25.5, 62.0),
	"walk_end": Vector2(25.5, 62.0),
	"attack": Vector2(25.5, 62.0),
	# 蓄力本体：121×104 单帧，逐帧量测 内容底 y=89、脚底中心 x=29.5
	# （锚点必须按实测值，否则切到蓄力动画时角色会整体位移——这是"漂移"的根因）
	"charge": Vector2(29.5, 89.0),
	"charge_ready": Vector2(29.5, 89.0),
	"charge_throw": Vector2(29.5, 89.0),
}
# 精灵缩放覆盖：不同素材分辨率不同（剑士单帧 256×256、旅者单帧 48×63）。
# 想让两人在屏幕上看起来差不多大，旅者需要更大的缩放；碰撞体仍按 character_scale 缩放以保持判定一致。
const PLAYER_SPRITE_SCALE_OVERRIDES := {
	"traveler": 5.0,
}
# 旅者各精灵表的帧数（无 json 的图按"图宽 / 帧数"横切）
const TRAVELER_IDLE_FRAMES := 4
const TRAVELER_ATTACK_FRAMES := 3
# 旅者各动画帧率（素材单帧 100ms → 10fps）
const TRAVELER_ANIM_FPS := 10.0
# Aseprite 标签名（美术改标签名时只改这里）
const TRAVELER_TAG_WALK_LOOP := "移动中循环"
const TRAVELER_TAG_WALK_END := "结束后摇"
const TRAVELER_TAG_CHARGE_LOOP := "蓄力循环"
const TRAVELER_TAG_CHARGE_READY := "准备发射"
const TRAVELER_TAG_CHARGE_THROW := "抛出去"
const TRAVELER_TAG_DISC_FLY := "飞出去循环"
const TRAVELER_TAG_DISC_HIT := "击中"
const TRAVELER_TAG_CDISC_CHARGE := "蓄力"
const TRAVELER_TAG_CDISC_READY := "准备发射"
const TRAVELER_TAG_CDISC_FLY := "飞盘飞出去的过程"
const TRAVELER_TAG_CDISC_HIT := "击中敌人"

# ------------------------------ 旅者飞盘（投射物） ------------------------------
const PLAYER_CHARGE_ATTACK_DAMAGE := 50      # 蓄力攻击伤害（格）
const TRAVELER_DISC_THROW_FRAME := 1         # 平A 第几帧出手（0 起算）
const TRAVELER_DISC_SPEED := 900.0           # 平A 飞盘飞行速度（像素/秒）
const TRAVELER_DISC_MAX_DISTANCE := 780.0    # 平A 飞盘最大飞行距离（超过即消失）
const TRAVELER_DISC_SCALE := 5.0             # 飞盘缩放（与旅者本体同一像素比例）
const TRAVELER_DISC_CHARGE_SPEED := 1150.0   # 蓄力飞盘飞行速度
const TRAVELER_DISC_CHARGE_MAX_DISTANCE := 980.0 # 蓄力飞盘最大飞行距离
const TRAVELER_DISC_CHARGE_GROW := 2.6       # 蓄力飞盘飞行途中放大到的倍数
const TRAVELER_CHARGE_DISC_PIERCE := 3       # 蓄力飞盘最大穿透敌人数量（记 ID 不重复打同一个；平A 恒为 1 = 不穿透）
const TRAVELER_DISC_HITBOX_RADIUS := 30.0    # 飞盘命中判定半径下限（像素）：比贴图内容略大，避免"贴着敌人飞过去"
const TRAVELER_DISC_AIM_HEIGHT := -75.0      # 自动瞄准的瞄准点高度（相对敌人原点，敌人受击框在 (0,-75)）
const TRAVELER_DISC_CHARGE_GROW_TIME := 0.45 # 放大到目标倍数所用时间（秒）
# 出手点（相对角色原点=脚底；x 朝右为正）：让飞盘视觉上从手里抛出
const TRAVELER_DISC_SPAWN_OFFSET := Vector2(95.0, -165.0)         # 平A 出手点
const TRAVELER_CHARGE_DISC_SPAWN_OFFSET := Vector2(90.0, -230.0)  # 蓄力抛出点（抬手更高）
# 蓄力改为"长按蓄力、松手发射"：
const TRAVELER_CHARGE_MIN_TIME := 0.2        # 最短蓄力时间（也是平A键"点按/长按"的分界：短于它 = 平A）
const TRAVELER_CHARGE_MAX_TIME := 1.2        # 最长蓄力时间（到顶后停在「准备发射」，继续等待松手）
const TRAVELER_CHARGE_READY_TIME := 0.2      # 准备发射时长（2 帧 × 100ms）
const TRAVELER_CHARGE_THROW_TIME := 0.3      # 抛出去时长（3 帧 × 100ms）

# ------------------------------ 飞盘自动瞄准（平A / 蓄力各一套） ------------------------------
# 三个参数：索敌半径（像素，以飞盘自身为中心）、瞄准生效时间（发射后多久开始索敌）、转向角速度（弧度/秒）
# 找不到敌人 → 直线飞；目标死亡 → 丢失锁敌（保持当前方向直线飞，不重新索敌、不急转弯）
const TRAVELER_DISC_HOMING_RADIUS := 420.0        # 平A：索敌半径
const TRAVELER_DISC_HOMING_DELAY := 0.08          # 平A：瞄准生效时间（秒）
const TRAVELER_DISC_HOMING_TURN_SPEED := 4.0      # 平A：转向角速度（弧度/秒；越小越不能急转弯）
const TRAVELER_CDISC_HOMING_RADIUS := 520.0       # 蓄力：索敌半径
const TRAVELER_CDISC_HOMING_DELAY := 0.06         # 蓄力：瞄准生效时间
const TRAVELER_CDISC_HOMING_TURN_SPEED := 3.0     # 蓄力：转向角速度（略慢，转弯更"重"）

# ------------------------------ 单人 / 双人 ------------------------------
enum GameMode { SINGLE = 1, DOUBLE = 2 } # 游戏模式：单人 / 双人
enum RunResult { NONE, CLEAR, FAILED }   # 关卡结算：进行中 / 任务完成 / 游戏失败
const CHARACTER_SWORDSMAN := "swordsman" # 第一期唯一可选角色：剑士（1P / 2P 共用模板）

const MAX_PLAYERS := 2                # 最多两名玩家
const PLAYER_SPAWN_OFFSET_X := 120.0  # 两名玩家的出生点横向间隔（防止出生重叠）
const PVP_DAMAGE_ENABLED := false     # 彻底关闭友伤：玩家之间永远无法造成伤害

# ------------------------------ 怪物数值 ------------------------------
const ENEMY_NORMAL_MAX_HP := 20       # 普通怪 HP
const ENEMY_ELITE_MAX_HP := 40        # 精英怪 HP
const ENEMY_DAMAGE_TO_PLAYER := 1     # 怪物一次攻击扣玩家 1 格血量
const ENEMY_PATROL_SPEED := 40.0      # 未看见玩家：原地随机慢走巡逻速度
const ENEMY_CHASE_SPEED := 70.0       # 玩家进入范围：缓慢爬行追踪速度
const ENEMY_DETECT_RANGE := 380.0     # 怪物发现玩家的横向距离
const ENEMY_DETECT_HEIGHT := 120.0    # 怪物发现玩家的纵向容差
const ENEMY_ATTACK_RANGE := 96.0      # 怪物攻击范围（独立碰撞箱判定，后期可手动拖拽调整）
const ENEMY_ATTACK_COOLDOWN := 1.6    # 怪物攻击冷却（秒）
const ENEMY_PATROL_INTERVAL_MIN := 1.0 # 巡逻换向最短间隔（秒）
const ENEMY_PATROL_INTERVAL_MAX := 2.5 # 巡逻换向最长间隔（秒）
const ENEMY_HIT_STOP := 0.35          # 被攻击瞬间：停顿时间（秒）
const ENEMY_HIT_FLASH_COLOR := Color(1.0, 0.25, 0.25, 1.0) # 被攻击瞬间变红
const ENEMY_DEATH_FADE_TIME := 0.8    # 死亡：白色渐隐消失耗时（秒）
const ENEMY_MIN_SPACING := 180.0      # 怪物之间最小间距（手动摆放规范，运行时仅校验并文字警告）
const ENEMY_Y_MIN := 560.0            # 怪物活动 Y 上界
const ENEMY_Y_MAX := 740.0            # 怪物活动 Y 下界
const ENEMY_HURT_KNOCKBACK := 40.0    # 怪物受击轻微位移

# 精英怪预留：单独 SP / 单独宝箱 / 单独血量（第一期仅使用参数，不做独立 AI 分支）
const ELITE_SP_GAIN := 20             # 命中精英怪获得的 SP（同 PLAYER_SP_GAIN_ELITE）
const ELITE_DROP_CHEST := "gold"      # 精英怪掉落金宝箱
const NORMAL_DROP_CHEST := "copper"   # 普通怪掉落铜宝箱

# ------------------------------ 掉落 / 拾取 ------------------------------
const CHEST_TOUCH_RADIUS := 90.0      # 宝箱触碰玩家自动开启的判定半径（像素）
const CHEST_ICON_SCALE := 1.6         # 宝箱图标缩放默认值（掉落物图标放大）
const COIN_ICON_SCALE := 2.0          # 金币图标缩放默认值（金币原始素材很小，需要放大才看得清）
const ITEM_ICON_SCALE := 2.0          # 道具图标缩放默认值
const CHEST_OPEN_FADE_TIME := 0.5     # 宝箱开启后自动渐隐消失耗时（秒）
const DROP_COIN_CHANCE := 0.7         # 宝箱随机产出：金币概率（其余概率产出道具）
const COIN_VALUE_MIN := 1             # 单次金币最小数量
const COIN_VALUE_MAX := 9             # 单次金币最大数量
const MAGNET_RADIUS := 140.0          # 金币/道具磁吸半径（后期自行调参）
const MAGNET_SPEED := 420.0           # 磁吸飞向玩家的速度（像素/秒）
const DROP_PICKUP_DISTANCE := 36.0    # 进入该距离即判定为拾取成功
const COIN_PICKUP_ANIM_TIME := 0.35   # 金币被吸取后的消失动画时间（秒）

# ------------------------------ UI 布局 ------------------------------
const HUD_MARGIN := Vector2(24.0, 18.0)    # HUD 距离画面边缘的安全边距
const HUD_SCALE := 1.6                     # HUD 整体缩放（UI 素材按 256 画布绘制，放大到可读尺寸）
const HUD_CANVAS := Vector2(256.0, 256.0)  # HUD 美术设计画布（每个 UI 素材都是 256x256 画布）
const HUD_HP_BAR_Y := 52.0                 # 血条在总底图内的纵向位置（素材画布坐标，可微调）
const HUD_SP_BAR_Y := 61.0                 # SP 条在总底图内的纵向位置（素材画布坐标，可微调）
const HUD_SP_READY_PULSE := 4.0            # SP 满时 SP 条呼吸闪烁速度（提示大招就绪）
const HUD_PANEL_SIZE := Vector2(330.0, 96.0) # 单个玩家 HUD 面板尺寸
const HUD_PANEL_GAP := Vector2(18.0, 12.0) # 双人 HUD 面板之间的间距（2P 靠在 1P 右侧排列）
const HUD_COIN_POS := Vector2(24.0, 150.0) # 金币总数显示位置
const DODGE_ICON_SIZE := 54.0              # 闪避冷却图标尺寸（美术贴图预留位置）
const DODGE_ICON_BLINK_SPEED := 6.0        # 闪避冷却期间图标闪烁速度

# ------------------------------ 音频（预留接口） ------------------------------
const AUDIO_ENABLED := false          # 音频素材（res://audio/）导入后改为 true，BGM / 音效即自动播放
const AUDIO_MASTER_VOLUME_DEFAULT := 0.8 # 默认主音量（设置界面滑块初始值）

# ------------------------------ 调试 / 测试台 ------------------------------
const DEBUG_PANEL_TOGGLE_ACTION := "debug_panel_toggle"     # F1：开关调试面板
const DEBUG_SP_FULL_ACTION := "debug_sp_full_cast"          # F2：满 SP 并立即释放大招
const DEBUG_SP_ONLY_ACTION := "debug_sp_full_only"          # F3：仅满 SP（不释放大招）
