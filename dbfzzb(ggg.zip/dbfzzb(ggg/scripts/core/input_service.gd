extends Node

# =============================================================================
# 输入服务（自动加载单例）
# 职责：
#   1. 统一注册全部游戏动作（1P / 2P / 全局菜单 / 测试台），默认键位写在常量里；
#   2. 支持全按键自定义（键盘槽 + 手柄槽分别重绑），保存到 user://input_bindings.cfg；
#   3. 支持手柄、键盘热插拔与热切换（按连接顺序自动分配 1P / 2P 手柄）；
#   4. 摇杆死区防漂移（所有动作统一 0.2 死区）。
# =============================================================================

const BINDINGS_PATH := "user://input_bindings.cfg"  # 自定义按键保存路径
const BINDINGS_SECTION := "bindings"                # 存档段落名
const DEADZONE := 0.2                               # 摇杆死区：防止手柄摇杆漂移导致角色自己走

# 每个玩家可绑定动作（顺序即设置界面显示顺序）
const PLAYER_ACTIONS: Array[String] = [
	"move_left", "move_right", "move_up", "move_down",
	"attack", "dodge", "ultimate", "charge", "inventory",
]

# 全局动作（不属于某个玩家）
const GLOBAL_ACTIONS: Array[String] = [
	"pause_menu",          # ESC：暂停 / 返回
	"menu_left", "menu_right", "menu_up", "menu_down", # 菜单导航
	"menu_confirm", "menu_cancel",                     # 菜单确认 / 取消
	"debug_panel_toggle",  # F1：开关调试面板
	"debug_sp_full_cast",  # F2：满 SP 并立即释放大招
	"debug_sp_full_only",  # F3：仅满 SP，不释放大招
]

# 设置界面显示名（界面文字仅使用英文字母与数字：默认字体内不含中文字形，避免出现空白方块）
const ACTION_LABELS := {
	"move_left": "MOVE LEFT", "move_right": "MOVE RIGHT", "move_up": "MOVE UP", "move_down": "MOVE DOWN",
	"attack": "ATTACK", "dodge": "DODGE", "ultimate": "ULTIMATE", "charge": "CHARGE", "inventory": "INVENTORY",
	"pause_menu": "PAUSE", "menu_left": "MENU LEFT", "menu_right": "MENU RIGHT",
	"menu_up": "MENU UP", "menu_down": "MENU DOWN", "menu_confirm": "CONFIRM", "menu_cancel": "CANCEL",
	"debug_panel_toggle": "DEBUG PANEL", "debug_sp_full_cast": "DEBUG SP FULL + ULT",
	"debug_sp_full_only": "DEBUG SP FULL ONLY",
}

# 手柄按键 / 摇杆轴的显示名（界面文字仅用英文字母与数字）
const JOY_BUTTON_LABELS := {
	JOY_BUTTON_A: "PAD A", JOY_BUTTON_B: "PAD B", JOY_BUTTON_X: "PAD X", JOY_BUTTON_Y: "PAD Y",
	JOY_BUTTON_BACK: "PAD BACK", JOY_BUTTON_START: "PAD START", JOY_BUTTON_GUIDE: "PAD GUIDE",
	JOY_BUTTON_LEFT_STICK: "PAD L3", JOY_BUTTON_RIGHT_STICK: "PAD R3",
	JOY_BUTTON_LEFT_SHOULDER: "PAD LB", JOY_BUTTON_RIGHT_SHOULDER: "PAD RB",
	JOY_BUTTON_DPAD_UP: "PAD UP", JOY_BUTTON_DPAD_DOWN: "PAD DOWN",
	JOY_BUTTON_DPAD_LEFT: "PAD LEFT", JOY_BUTTON_DPAD_RIGHT: "PAD RIGHT",
}
const JOY_AXIS_LABELS := {
	JOY_AXIS_LEFT_X: "AXIS LX", JOY_AXIS_LEFT_Y: "AXIS LY",
	JOY_AXIS_RIGHT_X: "AXIS RX", JOY_AXIS_RIGHT_Y: "AXIS RY",
	JOY_AXIS_TRIGGER_LEFT: "AXIS LT", JOY_AXIS_TRIGGER_RIGHT: "AXIS RT",
}

# 键盘默认键位（0 = 全局；1 = 1P；2 = 2P）
const DEFAULT_KEYBOARD := {
	0: {
		"pause_menu": [KEY_ESCAPE],
		"menu_left": [KEY_A, KEY_LEFT],
		"menu_right": [KEY_D, KEY_RIGHT],
		"menu_up": [KEY_W, KEY_UP],
		"menu_down": [KEY_S, KEY_DOWN],
		"menu_confirm": [KEY_ENTER, KEY_SPACE, KEY_J],
		"menu_cancel": [KEY_ESCAPE, KEY_K],
		"debug_panel_toggle": [KEY_F1],
		"debug_sp_full_cast": [KEY_F2],
		"debug_sp_full_only": [KEY_F3],
	},
	1: {
		"move_left": [KEY_A], "move_right": [KEY_D], "move_up": [KEY_W], "move_down": [KEY_S],
		"attack": [KEY_J], "dodge": [KEY_L], "ultimate": [KEY_K], "charge": [KEY_U], "inventory": [KEY_B],
	},
	2: {
		"move_left": [KEY_LEFT], "move_right": [KEY_RIGHT], "move_up": [KEY_UP], "move_down": [KEY_DOWN],
		"attack": [KEY_KP_1], "dodge": [KEY_KP_2], "ultimate": [KEY_KP_3],
		"charge": [KEY_KP_0], "inventory": [KEY_KP_5],
	},
}

# 手柄默认键位（与设备号无关，运行时写入该玩家当前分配的手柄 device）
const DEFAULT_JOYPAD := {
	0: {
		"menu_left": [{"kind": "axis", "axis": JOY_AXIS_LEFT_X, "value": -1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_LEFT}],
		"menu_right": [{"kind": "axis", "axis": JOY_AXIS_LEFT_X, "value": 1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_RIGHT}],
		"menu_up": [{"kind": "axis", "axis": JOY_AXIS_LEFT_Y, "value": -1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_UP}],
		"menu_down": [{"kind": "axis", "axis": JOY_AXIS_LEFT_Y, "value": 1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_DOWN}],
		"menu_confirm": [{"kind": "button", "button": JOY_BUTTON_A}],
		"menu_cancel": [{"kind": "button", "button": JOY_BUTTON_B}],
		"pause_menu": [{"kind": "button", "button": JOY_BUTTON_START}],
	},
	1: {
		"move_left": [{"kind": "axis", "axis": JOY_AXIS_LEFT_X, "value": -1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_LEFT}],
		"move_right": [{"kind": "axis", "axis": JOY_AXIS_LEFT_X, "value": 1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_RIGHT}],
		"move_up": [{"kind": "axis", "axis": JOY_AXIS_LEFT_Y, "value": -1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_UP}],
		"move_down": [{"kind": "axis", "axis": JOY_AXIS_LEFT_Y, "value": 1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_DOWN}],
		"attack": [{"kind": "button", "button": JOY_BUTTON_X}],
		"dodge": [{"kind": "button", "button": JOY_BUTTON_A}],
		"ultimate": [{"kind": "button", "button": JOY_BUTTON_Y}],
		"charge": [{"kind": "button", "button": JOY_BUTTON_RIGHT_SHOULDER}],
		"inventory": [{"kind": "button", "button": JOY_BUTTON_BACK}],
	},
	2: {
		"move_left": [{"kind": "axis", "axis": JOY_AXIS_LEFT_X, "value": -1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_LEFT}],
		"move_right": [{"kind": "axis", "axis": JOY_AXIS_LEFT_X, "value": 1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_RIGHT}],
		"move_up": [{"kind": "axis", "axis": JOY_AXIS_LEFT_Y, "value": -1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_UP}],
		"move_down": [{"kind": "axis", "axis": JOY_AXIS_LEFT_Y, "value": 1.0}, {"kind": "button", "button": JOY_BUTTON_DPAD_DOWN}],
		"attack": [{"kind": "button", "button": JOY_BUTTON_X}],
		"dodge": [{"kind": "button", "button": JOY_BUTTON_A}],
		"ultimate": [{"kind": "button", "button": JOY_BUTTON_Y}],
		"charge": [{"kind": "button", "button": JOY_BUTTON_RIGHT_SHOULDER}],
		"inventory": [{"kind": "button", "button": JOY_BUTTON_BACK}],
	},
}

signal bindings_changed              # 键位发生变化
signal joypad_devices_changed        # 手柄热插拔导致设备分配变化

var _overrides: Dictionary = {}      # 自定义键位： "owner:action:slot" -> InputEvent
var _joypad_devices: Dictionary = {} # 玩家序号 -> 手柄设备号（1P 用第一只，2P 用第二只）

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load_bindings()
	_assign_joypad_devices()
	_rebuild_all_actions()
	Input.joy_connection_changed.connect(_on_joy_connection_changed)

# ------------------------------ 对外查询接口 ------------------------------
# 可绑定动作列表（供设置界面生成按键行）
func get_bindable_actions(owner_index: int) -> Array:
	if owner_index <= 0:
		return GLOBAL_ACTIONS.duplicate()
	return PLAYER_ACTIONS.duplicate()

# 动作显示名（界面文字仅使用英文，避免默认字体缺中文字形出现空白方块）
func get_action_label(action: String) -> String:
	return String(ACTION_LABELS.get(action, action.to_upper()))

# 动作名：owner 0 = 全局动作；1 / 2 = 1P / 2P
func action_name(owner_index: int, action: String) -> String:
	if owner_index <= 0:
		return action
	return "p%d_%s" % [owner_index, action]

# 该玩家的移动向量（含摇杆死区与归一化，双人完全独立）
func get_move_vector(owner_index: int) -> Vector2:
	var left := Input.get_action_strength(action_name(owner_index, "move_left"))
	var right := Input.get_action_strength(action_name(owner_index, "move_right"))
	var up := Input.get_action_strength(action_name(owner_index, "move_up"))
	var down := Input.get_action_strength(action_name(owner_index, "move_down"))
	var vector := Vector2(right - left, down - up)
	return vector.limit_length(1.0)

func is_pressed(owner_index: int, action: String) -> bool:
	return Input.is_action_pressed(action_name(owner_index, action))

func is_just_pressed(owner_index: int, action: String) -> bool:
	return Input.is_action_just_pressed(action_name(owner_index, action))

func is_just_released(owner_index: int, action: String) -> bool:
	return Input.is_action_just_released(action_name(owner_index, action))

# 任意玩家按下某动作（用于背包等共享 UI：1P 的 B 键或 2P 的对应键都能开关）
func any_player_just_pressed(action: String) -> bool:
	for player_index in range(1, GameConfig.MAX_PLAYERS + 1):
		if is_just_pressed(player_index, action):
			return true
	return false

func get_joypad_device(player_index: int) -> int:
	return int(_joypad_devices.get(player_index, -1))

# ------------------------------ 键位重绑 ------------------------------
# 查询某动作某个槽位的当前绑定事件（slot: "key" 键盘 / "pad" 手柄）
func get_binding_events(owner_index: int, action: String, slot: String) -> Array:
	var override_key := _override_key(owner_index, action, slot)
	if _overrides.has(override_key):
		return [_overrides[override_key]]
	var table: Dictionary = DEFAULT_KEYBOARD if slot == "key" else DEFAULT_JOYPAD
	var owner_table: Dictionary = table.get(owner_index, {})
	var entries: Array = owner_table.get(action, [])
	var events: Array = []
	for entry in entries:
		var event := _build_event(owner_index, slot, entry)
		if event != null:
			events.append(event)
	return events

# 重绑：把一个输入事件写入指定槽位并立即生效
func rebind(owner_index: int, action: String, slot: String, event: InputEvent) -> void:
	if event == null:
		return
	var stored := _clone_event_for_storage(owner_index, slot, event)
	_overrides[_override_key(owner_index, action, slot)] = stored
	_rebuild_action(owner_index, action)
	_save_bindings()
	bindings_changed.emit()

# 恢复默认键位
func reset_all_bindings() -> void:
	_overrides.clear()
	_save_bindings()
	_rebuild_all_actions()
	bindings_changed.emit()

# 键位显示文本（ASCII，避免默认字体缺中文字形）
func describe_binding(owner_index: int, action: String, slot: String) -> String:
	var events := get_binding_events(owner_index, action, slot)
	if events.is_empty():
		return "-"
	var parts: Array[String] = []
	for event in events:
		parts.append(describe_event(event, slot))
	return ", ".join(parts)

func describe_event(event: InputEvent, slot: String) -> String:
	if event is InputEventKey:
		return OS.get_keycode_string((event as InputEventKey).physical_keycode)
	if event is InputEventJoypadButton:
		var button_index := (event as InputEventJoypadButton).button_index
		return String(JOY_BUTTON_LABELS.get(button_index, "PAD %d" % button_index))
	if event is InputEventJoypadMotion:
		var motion := event as InputEventJoypadMotion
		var direction := "+" if motion.axis_value > 0.0 else "-"
		return String(JOY_AXIS_LABELS.get(motion.axis, "AXIS %d" % motion.axis)) + direction
	return slot.to_upper()

# ------------------------------ 内部：动作注册 ------------------------------
func _override_key(owner_index: int, action: String, slot: String) -> String:
	return "%d:%s:%s" % [owner_index, action, slot]

func _build_event(owner_index: int, slot: String, entry: Variant) -> InputEvent:
	if slot == "key":
		var key_event := InputEventKey.new()
		key_event.physical_keycode = int(entry)
		return key_event
	var dict: Dictionary = entry
	var device := -1 if owner_index <= 0 else get_joypad_device(owner_index)
	match String(dict.get("kind", "")):
		"button":
			var button_event := InputEventJoypadButton.new()
			button_event.device = device
			button_event.button_index = int(dict.get("button", 0))
			return button_event
		"axis":
			var motion_event := InputEventJoypadMotion.new()
			motion_event.device = device
			motion_event.axis = int(dict.get("axis", 0))
			motion_event.axis_value = float(dict.get("value", 1.0))
			return motion_event
	return null

# 把用户输入的事件转成可保存的形式（键盘统一用物理键码，手柄保留按键/轴）
func _clone_event_for_storage(owner_index: int, slot: String, event: InputEvent) -> InputEvent:
	if event is InputEventKey:
		var key_event := InputEventKey.new()
		key_event.physical_keycode = (event as InputEventKey).physical_keycode
		return key_event
	if event is InputEventJoypadButton:
		var button_event := InputEventJoypadButton.new()
		button_event.button_index = (event as InputEventJoypadButton).button_index
		button_event.device = -1 if owner_index <= 0 else get_joypad_device(owner_index)
		return button_event
	if event is InputEventJoypadMotion:
		var source := event as InputEventJoypadMotion
		var motion_event := InputEventJoypadMotion.new()
		motion_event.axis = source.axis
		motion_event.axis_value = 1.0 if source.axis_value > 0.0 else -1.0
		motion_event.device = -1 if owner_index <= 0 else get_joypad_device(owner_index)
		return motion_event
	return null

func _rebuild_all_actions() -> void:
	for action in GLOBAL_ACTIONS:
		_rebuild_action(0, action)
	for player_index in range(1, GameConfig.MAX_PLAYERS + 1):
		for action in PLAYER_ACTIONS:
			_rebuild_action(player_index, action)

func _rebuild_action(owner_index: int, action: String) -> void:
	var name := action_name(owner_index, action)
	if not InputMap.has_action(name):
		InputMap.add_action(name)
	InputMap.action_erase_events(name)
	InputMap.action_set_deadzone(name, DEADZONE)
	for slot in ["key", "pad"]:
		for event in get_binding_events(owner_index, action, slot):
			InputMap.action_add_event(name, event)

# ------------------------------ 内部：手柄热插拔 ------------------------------
func _on_joy_connection_changed(device: int, connected: bool) -> void:
	var state := "已连接" if connected else "已断开"
	print("[输入服务] 手柄热插拔：设备 %d %s" % [device, state])
	_assign_joypad_devices()
	_rebuild_all_actions()
	joypad_devices_changed.emit()

# 按当前连接顺序分配手柄：第一只给 1P，第二只给 2P
func _assign_joypad_devices() -> void:
	_joypad_devices.clear()
	var pads := Input.get_connected_joypads()
	for index in range(pads.size()):
		var player_index := index + 1
		if player_index <= GameConfig.MAX_PLAYERS:
			_joypad_devices[player_index] = pads[index]
	if not pads.is_empty():
		print("[输入服务] 手柄分配：", _joypad_devices)

# ------------------------------ 内部：存档 ------------------------------
func _load_bindings() -> void:
	var config := ConfigFile.new()
	if config.load(BINDINGS_PATH) != OK:
		return
	# 判空保护：存档里没有 bindings 段（例如所有键位都是默认值）时直接返回，避免报错
	if not config.has_section(BINDINGS_SECTION):
		return
	for key in config.get_section_keys(BINDINGS_SECTION):
		var event := config.get_value(BINDINGS_SECTION, key, null) as InputEvent
		if event != null:
			_overrides[key] = event

func _save_bindings() -> void:
	var config := ConfigFile.new()
	config.load(BINDINGS_PATH)
	config.erase_section(BINDINGS_SECTION) # 先清空旧内容，恢复默认后不会残留
	if not _overrides.is_empty():
		for key in _overrides.keys():
			config.set_value(BINDINGS_SECTION, key, _overrides[key])
	config.save(BINDINGS_PATH)
