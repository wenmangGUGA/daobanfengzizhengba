extends Node

# =============================================================================
# 音频服务（自动加载单例）——预留接口
# 音频素材目录：res://audio/（BGM 放 res://audio/bgm/，音效放 res://audio/sfx/）
# 说明：素材未导入时 GameConfig.AUDIO_ENABLED = false，服务整体静默；
#      导入素材后把该常量改为 true，游戏内的 play_sfx / play_bgm 调用即自动生效。
# =============================================================================

const SETTINGS_PATH := "user://settings.cfg"          # 设置存档（音量等）
const BGM_DIR := AssetPaths.AUDIO_DIR + "bgm/"        # BGM 目录（预留）
const SFX_DIR := AssetPaths.AUDIO_DIR + "sfx/"        # 音效目录（预留）
const AUDIO_EXTENSIONS := [".ogg", ".wav", ".mp3"]    # 支持的音频格式（按顺序尝试）

var master_volume: float = GameConfig.AUDIO_MASTER_VOLUME_DEFAULT # 主音量 0~1
var _bgm_player: AudioStreamPlayer                                # BGM 播放器
var _sfx_players: Array[AudioStreamPlayer] = []                   # 音效播放器池（支持同时多个音效）
var _sfx_pool_index: int = 0                                      # 音效池轮询下标

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_bgm_player = AudioStreamPlayer.new()
	_bgm_player.name = "BgmPlayer"
	add_child(_bgm_player)
	for index in range(6):
		var player := AudioStreamPlayer.new()
		player.name = "SfxPlayer%d" % index
		add_child(player)
		_sfx_players.append(player)
	_load_settings()
	_apply_volume()

# ------------------------------ 对外接口（预留） ------------------------------
# 播放 BGM（循环）；缺失素材时只打印文字警告
func play_bgm(track_name: String) -> void:
	if not GameConfig.AUDIO_ENABLED:
		return
	var stream := _find_stream(BGM_DIR, track_name)
	if stream == null:
		return
	_bgm_player.stream = stream
	_bgm_player.play()

func stop_bgm() -> void:
	if _bgm_player != null:
		_bgm_player.stop()

# 播放音效（一次性）；缺失素材时只打印文字警告
func play_sfx(sfx_name: String) -> void:
	if not GameConfig.AUDIO_ENABLED:
		return
	var stream := _find_stream(SFX_DIR, sfx_name)
	if stream == null:
		return
	var player := _sfx_players[_sfx_pool_index]
	_sfx_pool_index = (_sfx_pool_index + 1) % _sfx_players.size()
	player.stream = stream
	player.play()

# 设置主音量（0~1，设置界面滑块调用）
func set_master_volume(value: float) -> void:
	master_volume = clampf(value, 0.0, 1.0)
	_apply_volume()
	_save_settings()

func get_master_volume() -> float:
	return master_volume

# ------------------------------ 内部实现 ------------------------------
func _apply_volume() -> void:
	var db := linear_to_db(maxf(master_volume, 0.0001))
	for player in _sfx_players:
		player.volume_db = db
	if _bgm_player != null:
		_bgm_player.volume_db = db

# 在预留目录中查找音频文件：依次尝试 .ogg / .wav / .mp3，找不到就文字警告
func _find_stream(dir_path: String, base_name: String) -> AudioStream:
	for extension in AUDIO_EXTENSIONS:
		var path: String = dir_path + base_name + extension
		if ResourceLoader.exists(path):
			return ResourceLoader.load(path) as AudioStream
	ArtLoader.warn_missing(dir_path + base_name + AUDIO_EXTENSIONS[0])
	return null

func _load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SETTINGS_PATH) != OK:
		return
	master_volume = clampf(float(config.get_value("audio", "master_volume", master_volume)), 0.0, 1.0)

func _save_settings() -> void:
	var config := ConfigFile.new()
	config.load(SETTINGS_PATH)
	config.set_value("audio", "master_volume", master_volume)
	config.save(SETTINGS_PATH)
