extends RefCounted
class_name ArtLoader

# =============================================================================
# 素材加载器
# 硬性规则：
#   1. 只读取 res://textures/...（即 F:\godotXIANGMU\chongsheng\textures）内的美术资源；
#   2. 素材缺失时只在控制台打印一行中文警告，返回 null，绝不生成色块 / 几何占位物体；
#   3. 同一路径的警告只打印一次，避免刷屏。
# =============================================================================

static var _texture_cache: Dictionary = {}   # 贴图缓存：path -> Texture2D（可为 null）
static var _used_rect_cache: Dictionary = {} # 有效像素矩形缓存：path -> Rect2
static var _warned_paths: Dictionary = {}    # 已警告过的路径，避免重复刷屏

# 加载单张贴图；缺失时打印“缺少xxx素材”并返回 null
static func load_texture(path: String) -> Texture2D:
	if path.is_empty():
		return null
	if _texture_cache.has(path):
		return _texture_cache[path] as Texture2D
	var texture: Texture2D = null
	if ResourceLoader.exists(path):
		texture = ResourceLoader.load(path) as Texture2D
	if texture == null:
		warn_missing(path)
	_texture_cache[path] = texture
	return texture

# 控制台缺少素材文字警告（去重）
static func warn_missing(path: String) -> void:
	if _warned_paths.has(path):
		return
	_warned_paths[path] = true
	print("缺少素材：", path)

# 目录扫描：按文件名数字顺序返回该目录下所有 png 的 res:// 路径（无则返回空数组 + 警告）
static func list_frames(dir_path: String) -> PackedStringArray:
	var result := PackedStringArray()
	if dir_path.is_empty():
		return result
	var dir := DirAccess.open(dir_path)
	if dir == null:
		warn_missing(dir_path)
		return result
	var names: Array[String] = []
	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.get_extension().to_lower() == "png":
			names.append(file_name)
		file_name = dir.get_next()
	dir.list_dir_end()
	names.sort_custom(_compare_frame_name)
	for name in names:
		result.append(dir_path.path_join(name))
	if result.is_empty():
		warn_missing(dir_path)
	return result

# 帧文件名排序：优先按纯数字升序（1.png / 2.png ... / 10.png），否则按自然字符串
static func _compare_frame_name(a: String, b: String) -> bool:
	var a_stem := a.get_basename()
	var b_stem := b.get_basename()
	if a_stem.is_valid_int() and b_stem.is_valid_int():
		return a_stem.to_int() < b_stem.to_int()
	return a_stem.naturalnocasecmp_to(b_stem) < 0

# 加载一整个目录的序列帧（缺失的帧会被跳过，不生成占位）
static func load_frame_textures(dir_path: String) -> Array[Texture2D]:
	var textures: Array[Texture2D] = []
	for path in list_frames(dir_path):
		var texture := load_texture(path)
		if texture != null:
			textures.append(texture)
	return textures

# 构建 SpriteFrames：specs = [{ "name": String, "dir": String, "fps": float, "loop": bool }]
static func build_sprite_frames(specs: Array, default_fps: float = 8.0) -> SpriteFrames:
	var sprite_frames := SpriteFrames.new()
	sprite_frames.remove_animation("default")
	for spec in specs:
		add_dir_animation(sprite_frames, String(spec.get("name", "")), String(spec.get("dir", "")),
			float(spec.get("fps", default_fps)), bool(spec.get("loop", true)))
	return sprite_frames

# 把一整个目录的序列帧加入指定 SpriteFrames（返回是否成功加入）
static func add_dir_animation(sprite_frames: SpriteFrames, anim_name: String, dir_path: String,
		fps: float = 8.0, loop: bool = true) -> bool:
	if sprite_frames == null or anim_name.is_empty():
		return false
	var frames := load_frame_textures(dir_path)
	if frames.is_empty():
		return false # 无素材：不创建动画，播放方会自动跳过，画面不出现任何占位
	sprite_frames.add_animation(anim_name)
	sprite_frames.set_animation_speed(anim_name, fps)
	sprite_frames.set_animation_loop(anim_name, loop)
	for texture in frames:
		sprite_frames.add_frame(anim_name, texture)
	return true

# ------------------------------ 精灵表（横向排列的整张图） ------------------------------
# 单帧尺寸：优先用外部给的 frame_size；没给就按"图宽 / 帧数"横切（单行精灵表）
static func sheet_frame_size(sheet: Texture2D, frame_count: int, frame_size: Vector2 = Vector2.ZERO) -> Vector2:
	if sheet == null or frame_count <= 0:
		return Vector2.ZERO
	if frame_size.x > 0.0 and frame_size.y > 0.0:
		return frame_size
	var size := sheet.get_size()
	var w := floorf(size.x / float(frame_count))
	if w <= 0.0 or size.y <= 0.0:
		return Vector2.ZERO
	return Vector2(w, size.y)

# 把一张横向精灵表按帧切好加入指定 SpriteFrames（每一帧是一个 AtlasTexture，不复制像素）
static func add_sheet_animation(sprite_frames: SpriteFrames, anim_name: String, sheet_path: String,
		frame_count: int, fps: float = 8.0, loop: bool = true,
		frame_size: Vector2 = Vector2.ZERO, row: int = 0) -> bool:
	if sprite_frames == null or anim_name.is_empty() or frame_count <= 0:
		return false
	var sheet := load_texture(sheet_path)
	if sheet == null:
		return false
	var cell := sheet_frame_size(sheet, frame_count, frame_size)
	if cell == Vector2.ZERO:
		return false
	sprite_frames.add_animation(anim_name)
	sprite_frames.set_animation_speed(anim_name, fps)
	sprite_frames.set_animation_loop(anim_name, loop)
	for index in range(frame_count):
		var atlas := AtlasTexture.new()
		atlas.atlas = sheet
		atlas.region = Rect2(Vector2(cell.x * float(index), cell.y * float(row)), cell)
		sprite_frames.add_frame(anim_name, atlas)
	return true

# 构建 SpriteFrames（精灵表版）：specs = [{ "name", "sheet", "count", "fps", "loop", "frame_size", "row" }]
static func build_sprite_frames_from_sheets(specs: Array, default_fps: float = 8.0) -> SpriteFrames:
	var sprite_frames := SpriteFrames.new()
	sprite_frames.remove_animation("default")
	for spec in specs:
		add_sheet_animation(sprite_frames, String(spec.get("name", "")), String(spec.get("sheet", "")),
			int(spec.get("count", 0)), float(spec.get("fps", default_fps)), bool(spec.get("loop", true)),
			spec.get("frame_size", Vector2.ZERO), int(spec.get("row", 0)))
	return sprite_frames

# ------------------------------ Aseprite 导出（png + json） ------------------------------
# Aseprite 的 json 结构：frames（每帧 rect + duration）+ meta.frameTags（标签：from/to 帧序号）
# 返回 { "size": Vector2, "frames": [ { "rect": Rect2, "duration": float } ], "tags": { 名称: {"from": int, "to": int} } }
static func load_aseprite(json_path: String) -> Dictionary:
	var result := {"size": Vector2.ZERO, "frames": [], "tags": {}}
	if json_path.is_empty() or not FileAccess.file_exists(json_path):
		warn_missing(json_path)
		return result
	var text := FileAccess.get_file_as_string(json_path)
	var parsed: Variant = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_warning("Aseprite json 解析失败：%s" % json_path)
		return result
	var data: Dictionary = parsed
	# 帧（按 json 内的顺序即为动画顺序；Aseprite 导出顺序 = 时间顺序）
	# 注意：这里必须用 Variant，Aseprite 的 frames 既可能是字典（哈希）也可能是数组
	var frames_raw: Variant = data.get("frames", {})
	var frame_list: Array = []
	if frames_raw is Dictionary:
		for key in (frames_raw as Dictionary).keys():
			var entry: Dictionary = (frames_raw as Dictionary)[key]
			var fr: Dictionary = entry.get("frame", {})
			frame_list.append({
				"rect": Rect2(float(fr.get("x", 0)), float(fr.get("y", 0)), float(fr.get("w", 0)), float(fr.get("h", 0))),
				"duration": float(entry.get("duration", 100)) / 1000.0, # Aseprite 的 duration 单位是毫秒
			})
	elif frames_raw is Array:
		for entry in (frames_raw as Array):
			var fr2: Dictionary = entry.get("frame", {})
			frame_list.append({
				"rect": Rect2(float(fr2.get("x", 0)), float(fr2.get("y", 0)), float(fr2.get("w", 0)), float(fr2.get("h", 0))),
				"duration": float(entry.get("duration", 100)) / 1000.0,
			})
	result["frames"] = frame_list
	# meta 信息（尺寸 + 标签）
	var meta: Dictionary = data.get("meta", {})
	var size: Dictionary = meta.get("size", {})
	result["size"] = Vector2(float(size.get("w", 0)), float(size.get("h", 0)))
	var tags: Dictionary = {}
	for tag in meta.get("frameTags", []):
		tags[String(tag.get("name", ""))] = {"from": int(tag.get("from", 0)), "to": int(tag.get("to", 0))}
	result["tags"] = tags
	return result

# 按 Aseprite 标签（或显式帧区间）加入一条动画
# 返回 { "ok": bool, "anchor": Vector2, "frame_size": Vector2, "frame_count": int }
#   anchor = 该标签各帧"内容中心"的平均值（帧内像素坐标），用于把特效稳定地摆到目标位置
static func add_aseprite_animation(sprite_frames: SpriteFrames, anim_name: String, png_path: String,
		json_path: String, tag_name: String = "", fps: float = 10.0, loop: bool = true,
		frame_range: Vector2i = Vector2i(-1, -1)) -> Dictionary:
	var failed := {"ok": false, "anchor": Vector2.ZERO, "frame_size": Vector2.ZERO, "frame_count": 0}
	if sprite_frames == null or anim_name.is_empty():
		return failed
	var sheet := load_texture(png_path)
	if sheet == null:
		return failed
	var info := load_aseprite(json_path)
	var frames: Array = info["frames"]
	if frames.is_empty():
		return failed
	# 帧区间：优先显式给定，否则查标签
	var from_index := frame_range.x
	var to_index := frame_range.y
	if from_index < 0 or to_index < 0:
		var tags: Dictionary = info["tags"]
		if not tags.has(tag_name):
			push_warning("Aseprite 里没有标签「%s」：%s" % [tag_name, json_path])
			return failed
		var tag: Dictionary = tags[tag_name]
		from_index = int(tag["from"])
		to_index = int(tag["to"])
	from_index = clampi(from_index, 0, frames.size() - 1)
	to_index = clampi(to_index, from_index, frames.size() - 1)
	sprite_frames.add_animation(anim_name)
	sprite_frames.set_animation_speed(anim_name, maxf(fps, 0.001))
	sprite_frames.set_animation_loop(anim_name, loop)
	var anchor_sum := Vector2.ZERO
	var frame_size := Vector2.ZERO
	var count := 0
	for index in range(from_index, to_index + 1):
		var entry: Dictionary = frames[index]
		var rect: Rect2 = entry["rect"]
		var atlas := AtlasTexture.new()
		atlas.atlas = sheet
		atlas.region = rect
		sprite_frames.add_frame(anim_name, atlas)
		frame_size = rect.size
		anchor_sum += used_rect(atlas).get_center() # 该帧内容中心（帧内像素坐标）
		count += 1
	return {
		"ok": true,
		"anchor": anchor_sum / maxf(float(count), 1.0),
		"frame_size": frame_size,
		"frame_count": count,
	}

# 无 json 的横向精灵表：按"图宽 / 总帧数"横切，取第 from~to 帧（含）做一条动画
# 返回字段同 add_aseprite_animation
static func add_sheet_range_animation(sprite_frames: SpriteFrames, anim_name: String, sheet_path: String,
		total_frames: int, from_index: int, to_index: int, fps: float = 10.0, loop: bool = true) -> Dictionary:
	var failed := {"ok": false, "anchor": Vector2.ZERO, "frame_size": Vector2.ZERO, "frame_count": 0}
	if sprite_frames == null or anim_name.is_empty() or total_frames <= 0:
		return failed
	var sheet := load_texture(sheet_path)
	if sheet == null:
		return failed
	var cell := Vector2(floorf(sheet.get_width() / float(total_frames)), sheet.get_height())
	if cell.x <= 0.0:
		return failed
	var first := clampi(from_index, 0, total_frames - 1)
	var last := clampi(to_index, first, total_frames - 1)
	sprite_frames.add_animation(anim_name)
	sprite_frames.set_animation_speed(anim_name, maxf(fps, 0.001))
	sprite_frames.set_animation_loop(anim_name, loop)
	var anchor_sum := Vector2.ZERO
	var count := 0
	for index in range(first, last + 1):
		var atlas := AtlasTexture.new()
		atlas.atlas = sheet
		atlas.region = Rect2(cell.x * float(index), 0.0, cell.x, cell.y)
		sprite_frames.add_frame(anim_name, atlas)
		anchor_sum += used_rect(atlas).get_center()
		count += 1
	return {
		"ok": true,
		"anchor": anchor_sum / maxf(float(count), 1.0),
		"frame_size": cell,
		"frame_count": count,
	}

# 贴图有效像素矩形（去掉全透明留白），用于素材驱动式 UI 布局
static func used_rect(texture: Texture2D) -> Rect2:
	if texture == null:
		return Rect2()
	var key := texture.resource_path
	if key.is_empty():
		key = str(texture.get_instance_id())
	if _used_rect_cache.has(key):
		return _used_rect_cache[key]
	var rect := Rect2(Vector2.ZERO, texture.get_size())
	var image := texture.get_image()
	if image != null:
		var used := image.get_used_rect()
		if used.size.x > 0.0 and used.size.y > 0.0:
			rect = Rect2(used)
	_used_rect_cache[key] = rect
	return rect

# 贴图有效内容中心点（帧内像素坐标），用于把素材内容精确对齐到节点位置
static func content_center(texture: Texture2D) -> Vector2:
	if texture == null:
		return Vector2.ZERO
	return used_rect(texture).get_center()

# 贴图有效内容的归一化矩形（相对原始画布 0~1），用于把素材按“作者绘制位置”摆放到设计画布
static func normalized_used_rect(texture: Texture2D) -> Rect2:
	if texture == null:
		return Rect2()
	var size := texture.get_size()
	if size.x <= 0.0 or size.y <= 0.0:
		return Rect2()
	var used := used_rect(texture)
	return Rect2(used.position / size, used.size / size)
