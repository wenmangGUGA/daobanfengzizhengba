extends Node

# =============================================================================
# 全局对局数据（自动加载单例）
# 负责：模式选择结果、角色选择结果、金币总数、背包数据、关卡结算结果。
# 双人规则：HP / SP / 状态由各自玩家节点独立持有，此单例只保存“队伍级”共享数据。
# =============================================================================

signal coins_changed(total_coins: int)      # 金币总数变化（UI 实时刷新）
signal inventory_changed(items: Array)      # 背包内容变化（UI 刷新）
signal result_changed(result: int)          # 关卡结算结果变化

# 模式与结算枚举统一在 GameConfig 中定义（GameConfig.GameMode / GameConfig.RunResult）

var game_mode: int = GameConfig.GameMode.SINGLE              # 当前模式
var selected_character: String = GameConfig.CHARACTER_SWORDSMAN # 兼容保留：第一个玩家的角色
var selected_characters: Array[String] = []                  # 选角界面确认的角色（按玩家顺序：0=1P，1=2P）
var coins: int = 0                                          # 金币总数（队伍共享，实时累加）
var inventory: Array = []                                   # 背包（队伍共享，存字典数据）
var run_result: int = GameConfig.RunResult.NONE              # 关卡结算结果

func _ready() -> void:
	reset_run()

# 单例自身常驻处理（暂停时也继续运行，保证 UI 数据一致）
func _enter_tree() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

# 玩家数量：1 = 单人，2 = 双人
func player_count() -> int:
	return clampi(int(game_mode), 1, GameConfig.MAX_PLAYERS)

# 选角界面确认后调用：写入每个玩家的角色，并按人数决定单人 / 双人模式
func set_selected_characters(character_ids: Array) -> void:
	selected_characters.clear()
	for id in character_ids:
		selected_characters.append(String(id))
	if selected_characters.is_empty():
		selected_characters.append(GameConfig.CHARACTER_SWORDSMAN)
	selected_character = selected_characters[0]
	game_mode = GameConfig.GameMode.DOUBLE if selected_characters.size() >= 2 else GameConfig.GameMode.SINGLE

# 取第 player_index（1 起）名玩家选择的角色 id；缺省回落到剑士模板
func get_character_for_player(player_index: int) -> String:
	var index := player_index - 1
	if index >= 0 and index < selected_characters.size():
		return selected_characters[index]
	return GameConfig.CHARACTER_SWORDSMAN

# 清空选角结果（每次进入选角界面时调用）
func clear_selected_characters() -> void:
	selected_characters.clear()
	game_mode = GameConfig.GameMode.SINGLE

# 重置一局数据
func reset_run() -> void:
	coins = 0
	inventory = []
	run_result = GameConfig.RunResult.NONE
	coins_changed.emit(coins)
	inventory_changed.emit(inventory)
	result_changed.emit(run_result)

# 增加金币（拾取金币时调用，飘字与总数实时累加）
func add_coins(amount: int) -> void:
	if amount <= 0:
		return
	coins += amount
	coins_changed.emit(coins)

# 拾取道具：存入背包（图标资源先取预留目录，缺素材只警告，不生成占位）
func add_item(item_id: String, display_name: String, icon_path: String = "") -> void:
	var item := {
		"id": item_id,
		"name": display_name,
		"icon": icon_path,
		"icon_texture": ArtLoader.load_texture(icon_path) if not icon_path.is_empty() else null,
	}
	inventory.append(item)
	inventory_changed.emit(inventory)

# 设置关卡结算结果
func set_run_result(result: int) -> void:
	if run_result == result:
		return
	run_result = result
	result_changed.emit(run_result)
