extends Node2D
class_name LevelController

# =============================================================================
# 关卡总控（第一期关卡 level_01）
# 职责：
#   1. 背景图高度铺满对局画面，地图宽度 = 背景图宽度（按比例换算）；
#   2. 生成出生点、玩家（1 或 2 人）、世界边界隐形墙、通关触发点（固定 X=4100）；
#   3. 怪物死亡掉宝箱、宝箱产出金币/道具、大招全屏演出与秒杀判定；
#   4. 暂停 / 设置 / 背包 / 结算 / 调试面板等界面流；
#   5. 任务完成（到达通关点）与游戏失败（两名玩家全部死亡）。
# =============================================================================

const PLAYER_SCENE := preload("res://scenes/entities/player.tscn")
const CHEST_SCENE := preload("res://scenes/entities/chest.tscn")
const COIN_SCENE := preload("res://scenes/entities/drop_coin.tscn")
const ITEM_SCENE := preload("res://scenes/entities/drop_item.tscn")
const FLOATING_TEXT_SCRIPT := preload("res://scripts/ui/floating_text.gd")
const ITEM_POPUP_SCRIPT := preload("res://scripts/ui/item_popup.gd")
const ULTIMATE_CUTSCENE_SCRIPT := preload("res://scripts/ui/ultimate_cutscene.gd")

const WORLD_BOUND_THICKNESS := 200.0 # 世界边界隐形墙厚度
const GAME_OVER_DELAY := 1.4         # 两名玩家全部死亡后延迟展示失败界面的时间（秒）

@onready var background: Sprite2D = $Background
@onready var entities: Node2D = $Entities
@onready var player_container: Node2D = $Entities/Players
@onready var enemy_container: Node2D = $Entities/Enemies
@onready var drop_container: Node2D = $Entities/Drops
@onready var camera: CameraController = $Camera2D
@onready var spawn_p1: Marker2D = $SpawnPoints/PlayerSpawn1
@onready var spawn_p2: Marker2D = $SpawnPoints/PlayerSpawn2
@onready var goal_marker: Marker2D = $GoalPoint

var map_width: float = 1200.0        # 地图宽度（由背景图决定）
var players: Array[PlayerController] = [] # 玩家列表
var hud: HudRoot = null              # 战斗 HUD
var _game_over_timer: float = -1.0   # 失败结算延迟计时（<0 表示未触发）
var _level_finished: bool = false    # 关卡是否已结算

func _ready() -> void:
	add_to_group("level_controller")
	_setup_background()
	_setup_world_bounds()
	_setup_goal()
	_spawn_players()
	_setup_camera()
	_setup_hud()
	_connect_enemies()
	_check_enemy_spacing()
	for player in players:
		player.died.connect(_on_player_died)
	AudioService.play_bgm("level_01")

func _process(delta: float) -> void:
	if _game_over_timer >= 0.0:
		_game_over_timer += delta
		if _game_over_timer >= GAME_OVER_DELAY:
			_game_over_timer = -1.0
			_finish_level(false)

# ------------------------------ 背景 / 地图 ------------------------------
# 背景图高度铺满对局画面，纵向完全固定；地图宽度跟随背景图尺寸
func _setup_background() -> void:
	var texture := ArtLoader.load_texture(AssetPaths.SCENE_BACKGROUND)
	if texture == null:
		map_width = GameConfig.MAP_GOAL_X + GameConfig.SCREEN_SIZE.x
		return
	background.texture = texture
	background.centered = false
	var scale_factor := GameConfig.BACKGROUND_FILL_HEIGHT / float(texture.get_height())
	background.scale = Vector2(scale_factor, scale_factor)
	background.position = Vector2.ZERO
	map_width = float(texture.get_width()) * scale_factor

# 世界边界隐形墙：限制玩家安全 Y 区间（550~750）与地图左右边界，防止角色跑出世界
func _setup_world_bounds() -> void:
	var bounds := StaticBody2D.new()
	bounds.name = "WorldBounds"
	bounds.collision_layer = 1 << 4 # 层 5：world_bounds
	bounds.collision_mask = 0
	add_child(bounds)
	var top_y := GameConfig.PLAYER_SAFE_Y_MIN - WORLD_BOUND_THICKNESS * 0.5
	var bottom_y := GameConfig.PLAYER_SAFE_Y_MAX + WORLD_BOUND_THICKNESS * 0.5
	_add_bound_shape(bounds, Vector2(map_width * 0.5, top_y), Vector2(map_width + WORLD_BOUND_THICKNESS * 2.0, WORLD_BOUND_THICKNESS))
	_add_bound_shape(bounds, Vector2(map_width * 0.5, bottom_y), Vector2(map_width + WORLD_BOUND_THICKNESS * 2.0, WORLD_BOUND_THICKNESS))
	_add_bound_shape(bounds, Vector2(-WORLD_BOUND_THICKNESS * 0.5, (top_y + bottom_y) * 0.5), Vector2(WORLD_BOUND_THICKNESS, bottom_y - top_y))
	_add_bound_shape(bounds, Vector2(map_width + WORLD_BOUND_THICKNESS * 0.5, (top_y + bottom_y) * 0.5), Vector2(WORLD_BOUND_THICKNESS, bottom_y - top_y))

func _add_bound_shape(body: StaticBody2D, center: Vector2, size: Vector2) -> void:
	var shape := RectangleShape2D.new()
	shape.size = size
	var collision := CollisionShape2D.new()
	collision.shape = shape
	collision.position = center
	body.add_child(collision)

# 通关触发点：固定 X = 4100（由场景中的 GoalPoint 拖拽摆放，数值已锁定）
func _setup_goal() -> void:
	goal_marker.position.x = GameConfig.MAP_GOAL_X
	var area := Area2D.new()
	area.name = "GoalTrigger"
	area.collision_layer = 1 << 8 # 层 9：goal_trigger
	area.collision_mask = 1 << 0  # 检测层 1：player_body
	var shape := RectangleShape2D.new()
	shape.size = Vector2(80.0, GameConfig.SCREEN_SIZE.y)
	var collision := CollisionShape2D.new()
	collision.shape = shape
	area.add_child(collision)
	area.position = Vector2(GameConfig.MAP_GOAL_X, GameConfig.SCREEN_SIZE.y * 0.5)
	area.body_entered.connect(_on_goal_body_entered)
	add_child(area)

# ------------------------------ 玩家 ------------------------------
func _spawn_players() -> void:
	var count := GameSession.player_count()
	for index in range(count):
		var player := PLAYER_SCENE.instantiate() as PlayerController
		player.player_index = index + 1
		player.character_id = GameSession.get_character_for_player(index + 1) # 选角界面下发的角色
		player_container.add_child(player)
		var spawn := spawn_p1 if index == 0 else spawn_p2
		player.global_position = spawn.global_position
		players.append(player)

func _setup_camera() -> void:
	camera.set_map_width(map_width)
	camera.set_targets(players)

# ------------------------------ HUD ------------------------------
func _setup_hud() -> void:
	hud = HudRoot.new()
	hud.name = "Hud"
	add_child(hud)
	hud.bind(self, players)
	hud.resume_pressed.connect(_resume_game)
	hud.exit_pressed.connect(_exit_to_title)
	hud.escape_pressed.connect(on_escape_pressed)

# ------------------------------ 怪物 / 掉落 ------------------------------
func _connect_enemies() -> void:
	for node in enemy_container.get_children():
		var enemy := node as EnemyBase
		if enemy == null:
			continue
		enemy.died.connect(_on_enemy_died)

# 怪物间距校验：手动摆放时若小于规范间距，仅打印控制台文字警告
func _check_enemy_spacing() -> void:
	var enemies: Array[Node2D] = []
	for node in enemy_container.get_children():
		var enemy := node as EnemyBase
		if enemy != null:
			enemies.append(enemy)
	for i in range(enemies.size()):
		for j in range(i + 1, enemies.size()):
			var distance := enemies[i].global_position.distance_to(enemies[j].global_position)
			if distance < GameConfig.ENEMY_MIN_SPACING:
				print("[关卡校验] 怪物间距不足：%s 与 %s 相距 %.1f 像素（规范最小 %.0f 像素），请手动调整摆放位置。" % [
					enemies[i].name, enemies[j].name, distance, GameConfig.ENEMY_MIN_SPACING
				])

# 怪物死亡：只掉宝箱（普通怪铜宝箱 / 精英怪金宝箱）
# 用 call_deferred 生成：怪物可能死在物理信号回调里（例如飞盘命中），
# 那时往场景树里加带碰撞的节点会触发 "Can't change this state while flushing queries"。
func _on_enemy_died(enemy: Node) -> void:
	var enemy_node := enemy as EnemyBase
	if enemy_node == null:
		return
	_spawn_chest_deferred(enemy_node.get_drop_chest_type(), enemy_node.global_position)

func _spawn_chest_deferred(chest_type: String, spawn_position: Vector2) -> void:
	if not is_inside_tree():
		return
	call_deferred("_spawn_chest_now", chest_type, spawn_position)

func _spawn_chest_now(chest_type: String, spawn_position: Vector2) -> void:
	var chest := CHEST_SCENE.instantiate() as ChestPickup
	if chest == null or drop_container == null:
		return
	chest.chest_type = chest_type
	chest.global_position = spawn_position
	drop_container.add_child(chest)
	chest.opened.connect(_on_chest_opened)

# 宝箱被触碰：随机产出金币 / 道具（自动拾取，自动渐隐由宝箱自身负责）
func _on_chest_opened(chest: Node, player: Node) -> void:
	var chest_node := chest as ChestPickup
	if chest_node == null:
		return
	if randf() <= GameConfig.DROP_COIN_CHANCE:
		var coin := COIN_SCENE.instantiate() as DropCoin
		coin.value = randi_range(GameConfig.COIN_VALUE_MIN, GameConfig.COIN_VALUE_MAX)
		coin.global_position = chest_node.global_position
		coin.target_player = player as Node2D
		drop_container.add_child(coin)
	else:
		var item := ITEM_SCENE.instantiate() as DropItem
		item.item_id = "herb" if randf() < 0.5 else "relic"
		item.item_name = "HERB" if item.item_id == "herb" else "RELIC"
		item.icon_path = AssetPaths.ITEM_ICON_DIR + item.item_id + ".png"
		item.global_position = chest_node.global_position
		item.target_player = player as Node2D
		drop_container.add_child(item)

# ------------------------------ 大招：全屏演出 + 秒杀 ------------------------------
# 全屏播放剑士大招动画
func play_ultimate_cutscene(player: PlayerController, duration: float) -> void:
	var cutscene: Node = ULTIMATE_CUTSCENE_SCRIPT.new()
	add_child(cutscene)
	cutscene.call("play", duration)

# 大招秒杀：斩杀当前画面内的全部怪物
func execute_ultimate_kill(player: PlayerController) -> void:
	var visible_range := camera.get_visible_x_range()
	for node in get_tree().get_nodes_in_group("enemy"):
		var enemy := node as EnemyBase
		if enemy == null or not is_instance_valid(enemy):
			continue
		var x := enemy.global_position.x
		if x >= visible_range.x and x <= visible_range.y:
			enemy.kill_by_ultimate()

# ------------------------------ 飘字 / 道具弹窗 ------------------------------
func spawn_floating_text(world_position: Vector2, text: String, color: Color) -> void:
	var floating: Node2D = FLOATING_TEXT_SCRIPT.new()
	floating.call("setup", text, color)
	floating.global_position = world_position
	drop_container.add_child(floating)

func spawn_item_popup(world_position: Vector2, icon_path: String, item_name: String, icon_scale: float = 2.0) -> void:
	var popup: Node2D = ITEM_POPUP_SCRIPT.new()
	popup.call("setup", icon_path, item_name, icon_scale)
	popup.global_position = world_position
	drop_container.add_child(popup)

# ------------------------------ 输入：暂停 / 背包 / 测试台 ------------------------------
# 说明：ESC 暂停统一由 HUD 处理（HUD 在暂停状态下仍然响应输入），此处只处理游戏内按键
func _unhandled_input(event: InputEvent) -> void:
	if _level_finished:
		return
	if event.is_action_pressed("debug_panel_toggle"):
		if hud != null:
			hud.toggle_debug()
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("debug_sp_full_cast"):
		_debug_fill_sp(true)
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("debug_sp_full_only"):
		_debug_fill_sp(false)
		get_viewport().set_input_as_handled()
		return
	# 背包开关：1P 的 B 键或 2P 的对应键都能开关
	if InputService.any_player_just_pressed("inventory") and not _is_paused():
		if hud != null:
			hud.toggle_inventory()

# ESC：优先关闭设置页 → 再恢复游戏 → 否则打开暂停菜单
func on_escape_pressed() -> void:
	if _level_finished or hud == null:
		return
	if hud.settings_menu != null and hud.settings_menu.visible:
		hud.close_settings()
	elif hud.is_pause_open():
		_resume_game()
	else:
		_pause_game()

# 测试台：F2 = 满 SP 并立即释放大招；F3 = 仅满 SP（不释放大招）
func _debug_fill_sp(cast_ultimate: bool) -> void:
	for player in players:
		if player.is_dead():
			continue
		if cast_ultimate:
			player.debug_fill_sp_and_cast()
		else:
			player.debug_fill_sp()
	print("[测试台] %s：%s" % ["满SP并释放大招" if cast_ultimate else "仅满SP", debug_status_line()])

# ------------------------------ 暂停 / 结算 ------------------------------
func _pause_game() -> void:
	get_tree().paused = true
	if hud != null:
		hud.open_pause()

func _resume_game() -> void:
	get_tree().paused = false
	if hud != null:
		hud.close_pause()

func _is_paused() -> bool:
	return get_tree().paused

func _exit_to_title() -> void:
	get_tree().paused = false
	SceneRouter.goto_main_menu()

# 通关触发：玩家到达通关点
func _on_goal_body_entered(body: Node2D) -> void:
	if body is PlayerController:
		_finish_level(true)

func _on_player_died(_player_index: int) -> void:
	# 单人死亡不结束游戏（可旁观队友）；两名玩家全部死亡才触发失败
	for player in players:
		if not player.is_dead():
			return
	if _game_over_timer < 0.0:
		_game_over_timer = 0.0

# 关卡结算：任务完成 / 游戏失败 → 回到标题主界面
func _finish_level(is_clear: bool) -> void:
	if _level_finished:
		return
	_level_finished = true
	GameSession.set_run_result(GameConfig.RunResult.CLEAR if is_clear else GameConfig.RunResult.FAILED)
	get_tree().paused = false
	for node in get_tree().get_nodes_in_group("player_controller"):
		(node as Node).set_process(false)
		(node as Node).set_physics_process(false) # 结算后冻结玩家，避免结算画面下角色继续移动
	if hud != null:
		hud.show_result(is_clear)

# ------------------------------ 调试信息 ------------------------------
func debug_status_line() -> String:
	var alive := 0
	for player in players:
		if not player.is_dead():
			alive += 1
	return "LEVEL map=%.0f goal=%.0f players=%d alive=%d enemies=%d chests=%d coins=%d items=%d result=%d camera=%.0f" % [
		map_width, GameConfig.MAP_GOAL_X, players.size(), alive,
		get_tree().get_nodes_in_group("enemy").size(),
		get_tree().get_nodes_in_group("chest").size(),
		GameSession.coins, GameSession.inventory.size(), GameSession.run_result,
		camera.global_position.x
	]
