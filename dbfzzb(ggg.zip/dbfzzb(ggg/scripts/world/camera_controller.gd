extends Camera2D
class_name CameraController

# =============================================================================
# 横版战斗相机（v2）
# 设计目标（对应需求）：
#   1. 平滑跟随玩家（插值系数 / 指数速度两种模式，全部可在检查器调节）；
#   2. 角色跑到地图边缘时相机不再"缓慢滑动滞后"——碰到边界立刻锁死镜头；
#   3. 所有可调参数用 @export 暴露；
#   4. 变量 / 函数名全英文；
#   5. 关键行中文注释；
#   6. 关闭边界平滑：一旦被地图边界钳制就立即吸附，并 reset_smoothing() 清掉残留拖影；
#   7. 判空保护：目标丢失 / 场景空 / 无效实例都不会报错。
# 跟随逻辑统一写在 _physics_process，与玩家移动（同样 _physics_process）保持同一时序。
# =============================================================================

@export_group("Follow Target") # ---------------- 跟随目标 ----------------
@export var focus_ratio_x: float = 0.37      # 目标在画面中的横向位置比例（0.37 = 画面左侧 37%）
@export var fixed_y: float = 400.0           # 相机纵向固定值（= 画面高度一半），只横向跟随
@export var keep_all_visible: bool = true    # 保证所有存活玩家都在画面内（双人不丢人）
@export var keep_margin: float = 60.0        # 保证玩家不出画面时保留的安全边距（像素）

@export_group("Smoothing") # ---------------- 平滑参数 ----------------
@export var enable_smoothing: bool = true    # 关闭后相机严格贴合目标（无缓动）
@export_range(0.01, 1.0, 0.001) var smooth_lerp_factor: float = 0.10 # lerp 插值系数（推荐 0.08~0.12）
@export var smooth_speed: float = 8.0        # 指数平滑速度（越大越紧跟；use_exponential_smoothing=true 时生效）
@export var use_exponential_smoothing: bool = false # true=用指数速度曲线，false=用 lerp 系数

@export_group("Map Bounds") # ---------------- 地图边界 ----------------
@export var bound_left: float = 0.0          # 地图左边界（世界坐标）
@export var bound_right: float = 1200.0      # 地图右边界（关卡在 _ready 里按背景宽度写入）
@export var bound_extra: float = 0.0         # 额外余量：调大可让相机略微越界，避免高速贴边时"卡死感"
@export var snap_epsilon: float = 0.5        # 贴边判定容差（像素）
@export var reset_smoothing_on_boundary: bool = true # 碰到边界立刻锁死镜头 + 重置平滑（消除残留拖影）

@export_group("Debug") # ---------------- 调试 ----------------
@export var debug_print: bool = false        # 打开后每次贴边锁死都会打印一行日志

const MIN_VIEW_MARGIN := 0.0                 # 相机边界内边距（0 = 严格贴住地图左右边界）

var map_width: float = 1200.0                # 地图宽度（由关卡背景图尺寸决定）
var targets: Array = []                      # 跟随目标（双人时取所有存活玩家）
var _current_x: float = 0.0                  # 当前相机中心 X（平滑值）
var _view_half_w: float = 600.0              # 画面半宽（= 1200 / 2）
var _is_boundary_locked: bool = false        # 当前是否处于"边界锁死"状态

func _ready() -> void:
	enabled = true
	position_smoothing_enabled = false # 关闭引擎自带平滑：本脚本自己算缓动，避免双重平滑/拖影
	ignore_rotation = true
	_view_half_w = GameConfig.SCREEN_SIZE.x * 0.5
	set_map_width(bound_right)
	global_position = Vector2(clampf(_view_half_w, bound_left + _view_half_w, maxf(bound_right - _view_half_w, bound_left + _view_half_w)), fixed_y)
	_current_x = global_position.x

# 设置地图宽度（关卡读取背景图后调用）
func set_map_width(width: float) -> void:
	map_width = maxf(width, GameConfig.SCREEN_SIZE.x)
	bound_right = map_width
	# 相机可移动范围：保证取景框永远在地图内部（bound_extra 允许少量越界余量）
	var lowest := bound_left + _view_half_w - MIN_VIEW_MARGIN - bound_extra
	var highest := bound_right - _view_half_w + MIN_VIEW_MARGIN + bound_extra
	if highest < lowest:
		highest = lowest # 地图比画面还窄：退化为固定位置，避免参数互相冲突
	_current_x = clampf(_current_x, lowest, highest)
	# 同步到引擎的相机限制（双保险：即使本脚本被禁用，引擎也不会把镜头推出地图）
	limit_left = int(floorf(bound_left))
	limit_top = 0
	limit_right = int(ceilf(bound_right))
	limit_bottom = int(GameConfig.SCREEN_SIZE.y)

# 设置跟随目标
func set_targets(new_targets: Array) -> void:
	targets = new_targets

# 当前可见的横向范围（大招秒杀判定使用）
func get_visible_x_range() -> Vector2:
	return Vector2(_current_x - _view_half_w, _current_x + _view_half_w)

# ------------------------------ 跟随逻辑（与玩家移动同一时序） ------------------------------
func _physics_process(delta: float) -> void:
	var desired_x := _compute_desired_camera_x()
	if is_nan(desired_x) or is_inf(desired_x):
		return # 目标异常：保持原位，绝不报错崩溃
	# 【边界硬锁】期望位置被地图边界钳制时说明已经贴边：
	#   立即吸附到边界，完全不做平滑 —— 这就是"关闭边界平滑、碰到边界立刻锁死镜头"。
	if _is_boundary_locked:
		_current_x = desired_x
		global_position = Vector2(_current_x, fixed_y)
		return
	var weight := _compute_follow_weight(delta)
	if weight >= 1.0:
		_current_x = desired_x
	else:
		_current_x = lerp(_current_x, desired_x, weight)
	global_position = Vector2(_current_x, fixed_y) # 纵向固定，绝不跟随玩家上下移动

# 平滑权重：lerp 系数模式（推荐 0.08~0.12）或指数速度模式，均做帧率无关处理
func _compute_follow_weight(delta: float) -> float:
	if not enable_smoothing:
		return 1.0
	if use_exponential_smoothing:
		return clampf(1.0 - exp(-maxf(smooth_speed, 0.0) * delta), 0.0, 1.0)
	# lerp 系数按 60FPS 标定：60 帧下就是 smooth_lerp_factor，其它帧率自动换算，避免手感随帧率漂移
	return clampf(1.0 - pow(1.0 - clampf(smooth_lerp_factor, 0.001, 1.0), delta * 60.0), 0.0, 1.0)

# 计算相机目标中心 X：
#   1. 常态：把目标放在画面 focus_ratio_x 位置（默认左侧 37%）；
#   2. 多人：保证所有存活玩家都在画面内（距离超过一屏时跟随领先的玩家）；
#   3. 严格限制在地图左右边界内，靠近地图端点时立即锁死。
func _compute_desired_camera_x() -> float:
	var lowest := bound_left + _view_half_w - bound_extra
	var highest := bound_right - _view_half_w + bound_extra
	if highest < lowest:
		highest = lowest

	var min_x := INF
	var max_x := -INF
	var total := 0.0
	var count := 0
	for target in targets:
		# 判空保护：目标可能已销毁 / 未进树 / 已死亡
		if target == null or not is_instance_valid(target):
			continue
		var node := target as Node2D
		if node == null or not node.is_inside_tree():
			continue
		if node is PlayerController and (node as PlayerController).is_dead():
			continue
		var x := node.global_position.x
		min_x = minf(min_x, x)
		max_x = maxf(max_x, x)
		total += x
		count += 1
	if count == 0:
		return _current_x # 没有有效目标：保持不变（不报错、不跳变）

	var average := total / float(count)
	var desired_x := average - GameConfig.SCREEN_SIZE.x * focus_ratio_x
	if keep_all_visible:
		# 让最左/最右玩家都不出画面
		var keep_lowest := max_x - _view_half_w + keep_margin
		var keep_highest := min_x + _view_half_w - keep_margin
		if keep_lowest <= keep_highest:
			desired_x = clampf(desired_x, keep_lowest, keep_highest)
		else:
			desired_x = maxf(desired_x, keep_lowest) # 两人距离超过一屏：跟随领先的玩家

	# 【边界处理】越界即吸附：返回钳制后的值，由 _physics_process 立刻锁死并重置平滑
	var clamped_x := clampf(desired_x, lowest, highest)
	if absf(clamped_x - desired_x) > snap_epsilon:
		if not _is_boundary_locked:
			_is_boundary_locked = true
			if reset_smoothing_on_boundary:
				reset_smoothing() # 清掉引擎内部残留的平滑状态，防止贴边后的拖影
			if debug_print:
				print("[相机] 触边锁死：期望 %.1f → 实际 %.1f（地图 [%.0f, %.0f]）"
					% [desired_x, clamped_x, bound_left, bound_right])
	else:
		_is_boundary_locked = false
	return clamped_x
