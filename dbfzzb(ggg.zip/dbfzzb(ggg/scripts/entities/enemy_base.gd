extends Node2D
class_name EnemyBase

# =============================================================================
# 怪物基类（普通怪 / 精英怪共用）
# 素材：res://textures/怪物待机/、res://textures/怪物移动/
# 规则：
#   1. 刷新位置全部由关卡场景手动摆放（本脚本记录出生点用于巡逻）；
#   2. 未看见玩家 → 原地随机慢走巡逻；玩家进入范围 → 缓慢爬行追踪；
#   3. 被攻击瞬间 → 变红 + 停顿；死亡 → 白色渐变透明消失并掉落宝箱；
#   4. 精英怪使用黄色高亮，并预留独立血量 / 独立 SP / 独立宝箱标签。
# =============================================================================

signal died(enemy: Node)   # 死亡（关卡据此掉落宝箱）

enum State { PATROL, CHASE, ATTACK, HIT, DEAD }

const ANIM_IDLE := "idle"  # 动画名：待机
const ANIM_WALK := "walk"  # 动画名：行走

# 精英怪标签系统预留：独立血量 / 独立 SP / 独立宝箱（在检查器或场景中直接改）
@export var is_elite: bool = false                       # 是否精英怪（黄色高亮）
@export var max_hp: int = 20                             # 独立血量（普通怪 20 / 精英怪 40）
@export var sp_reward_on_hit: int = 10                   # 独立 SP 奖励（普通 10 / 精英 20）
@export var drop_chest_type: String = "copper"            # 独立宝箱类型（copper 铜 / gold 金）
@export var elite_tint: Color = Color(1.0, 0.88, 0.35, 1.0) # 精英怪黄色高亮叠色
@export var patrol_radius: float = 120.0                 # 巡逻半径（相对出生点）
@export var attack_windup: float = 0.25                  # 攻击前摇（秒）
@export var attack_active_time: float = 0.2              # 攻击判定持续时间（秒）

@export_group("Scale") # ---------------- 画面占比（统一缩放） ----------------
@export var character_scale: float = 1.0                 # 怪物统一缩放系数（精灵与碰撞体同步；1.0 = 原始大小）
@export var scale_collision_shapes: bool = true          # 是否同步缩放碰撞体

@onready var _sprite: AnimatedSprite2D = $Sprite
@onready var _attack_hitbox: Area2D = $AttackHitbox
@onready var _hurtbox: Area2D = $Hurtbox
@onready var _hurt_shape: CollisionShape2D = $Hurtbox/CollisionShape2D
@onready var _attack_shape: CollisionShape2D = $AttackHitbox/CollisionShape2D

var hp: int = 20                       # 当前血量
var state: int = State.PATROL          # 当前状态
var velocity: Vector2 = Vector2.ZERO   # 当前速度（像素/秒）
var _spawn_position: Vector2 = Vector2.ZERO # 出生点（手动摆放位置）
var _state_timer: float = 0.0          # 状态计时
var _patrol_direction: int = 1         # 巡逻方向
var _patrol_timer: float = 0.0         # 巡逻换向计时
var _attack_cooldown: float = 0.0      # 攻击冷却计时
var _knockback: Vector2 = Vector2.ZERO # 受击位移
var _facing: int = -1                  # 朝向（-1 向左 / 1 向右）
var _sprite_frames: SpriteFrames = null # 动画帧
var _base_modulate: Color = Color.WHITE # 基础叠色（精英怪为黄色高亮）
var _current_animation: String = ""
var _hurt_shape_size: Vector2 = Vector2.ZERO    # 原始受击框尺寸（缩放基准）
var _attack_shape_size: Vector2 = Vector2.ZERO  # 原始攻击框尺寸（缩放基准）
var _hurt_shape_position: Vector2 = Vector2.ZERO # 原始受击框位置（缩放基准）
var _attack_base_offset_x: float = 0.0          # 原始攻击框横向偏移（缩放基准）

func _ready() -> void:
	add_to_group("enemy")
	if is_elite:
		add_to_group("enemy_elite")
	else:
		add_to_group("enemy_normal")
	_hurtbox.collision_layer = 1 << 7   # 层 8：enemy_hurtbox
	_hurtbox.collision_mask = 0
	_hurtbox.add_to_group("enemy_hurtbox")
	_attack_hitbox.collision_layer = 1 << 3 # 层 4：enemy_attack
	_attack_hitbox.collision_mask = 1 << 6  # 只检测层 7：player_hurtbox
	_attack_hitbox.monitoring = false       # 攻击碰撞箱只在攻击判定窗口开启
	_build_animations()
	hp = max_hp
	_spawn_position = global_position
	_base_modulate = elite_tint if is_elite else Color.WHITE
	_sprite.modulate = _base_modulate
	_cache_base_geometry()                  # 记录原始几何后统一缩放
	_apply_character_scale()
	_face_towards(_facing) # 同步朝向与攻击碰撞箱位置
	_pick_patrol_interval()
	_play_animation(ANIM_IDLE)

# ------------------------------ 画面占比：统一缩放 ------------------------------
func _cache_base_geometry() -> void:
	_hurt_shape_size = _shape_size(_hurt_shape)
	_attack_shape_size = _shape_size(_attack_shape)
	_hurt_shape_position = _hurt_shape.position
	_attack_base_offset_x = absf(_attack_hitbox.position.x)

func _shape_size(shape_node: CollisionShape2D) -> Vector2:
	if shape_node == null or shape_node.shape == null:
		return Vector2.ZERO
	if shape_node.shape is RectangleShape2D:
		return (shape_node.shape as RectangleShape2D).size
	if shape_node.shape is CircleShape2D:
		return Vector2.ONE * (shape_node.shape as CircleShape2D).radius * 2.0
	return Vector2.ZERO

func _set_shape_size(shape_node: CollisionShape2D, size: Vector2) -> void:
	if shape_node == null or shape_node.shape == null or size == Vector2.ZERO:
		return
	if shape_node.shape.resource_local_to_scene == false:
		shape_node.shape = shape_node.shape.duplicate() # 复制形状，避免多只怪共用同一份资源
	if shape_node.shape is RectangleShape2D:
		(shape_node.shape as RectangleShape2D).size = size
	elif shape_node.shape is CircleShape2D:
		(shape_node.shape as CircleShape2D).radius = size.x * 0.5

# 统一缩放：精灵与碰撞体一起放大/缩小
func _apply_character_scale() -> void:
	var factor := maxf(character_scale, 0.01)
	_sprite.scale = Vector2(factor * float(_facing), factor)
	if scale_collision_shapes:
		_set_shape_size(_hurt_shape, _hurt_shape_size * factor)
		_set_shape_size(_attack_shape, _attack_shape_size * factor)
		_hurt_shape.position = _hurt_shape_position * factor
	_update_attack_hitbox_transform()

# 攻击碰撞箱位置：随朝向镜像，并随统一缩放系数同步放大
func _update_attack_hitbox_transform() -> void:
	if _attack_hitbox == null:
		return
	_attack_hitbox.position.x = _attack_base_offset_x * maxf(character_scale, 0.01) * float(_facing)

func _build_animations() -> void:
	_sprite_frames = ArtLoader.build_sprite_frames([
		{"name": ANIM_IDLE, "dir": AssetPaths.ENEMY_IDLE_DIR, "fps": GameConfig.ANIM_FPS_ENEMY_IDLE, "loop": true},
		{"name": ANIM_WALK, "dir": AssetPaths.ENEMY_WALK_DIR, "fps": GameConfig.ANIM_FPS_ENEMY_WALK, "loop": true},
	])
	_sprite.sprite_frames = _sprite_frames
	_sprite.centered = false
	_sprite.offset = -GameConfig.ENEMY_ANIM_ANCHOR # 脚底锚点对齐

# ------------------------------ 主循环 ------------------------------
func _physics_process(delta: float) -> void:
	_update_timers(delta)
	match state:
		State.PATROL:
			_process_patrol(delta)
		State.CHASE:
			_process_chase(delta)
		State.ATTACK:
			_process_attack(delta)
		State.HIT:
			_process_hit(delta)
		State.DEAD:
			return
	_apply_motion(delta)

func _update_timers(delta: float) -> void:
	if _attack_cooldown > 0.0:
		_attack_cooldown = maxf(_attack_cooldown - delta, 0.0)

# 未看见玩家：原地随机慢走巡逻（在出生点附近来回慢走 + 随机停顿）
func _process_patrol(delta: float) -> void:
	_state_timer += delta
	_patrol_timer -= delta
	if _patrol_timer <= 0.0:
		_pick_patrol_interval()
		_patrol_direction = 0 if randf() < 0.35 else (1 if randf() < 0.5 else -1)
	if _patrol_direction != 0:
		_face_towards(_patrol_direction)
		velocity = Vector2(float(_patrol_direction) * GameConfig.ENEMY_PATROL_SPEED, 0.0)
		_play_animation(ANIM_WALK)
		# 走太远就掉头，始终围绕出生点巡逻
		if absf(global_position.x - _spawn_position.x) > patrol_radius:
			_patrol_direction = -_patrol_direction
			_face_towards(_patrol_direction)
	else:
		velocity = Vector2.ZERO
		_play_animation(ANIM_IDLE)
	if _find_target() != null:
		state = State.CHASE
		_state_timer = 0.0

# 玩家进入范围：缓慢爬行追踪玩家
func _process_chase(delta: float) -> void:
	_state_timer += delta
	var target := _find_target()
	if target == null:
		state = State.PATROL
		_pick_patrol_interval()
		return
	var offset: Vector2 = target.global_position - global_position
	_face_towards(1 if offset.x > 0.0 else -1)
	velocity = Vector2(signf(offset.x) * GameConfig.ENEMY_CHASE_SPEED, offset.y * 0.4)
	_play_animation(ANIM_WALK)
	# 进入攻击范围且冷却完毕 → 发起一次攻击
	if _attack_cooldown <= 0.0 and _is_target_in_attack_range(target):
		_start_attack()

# 攻击：前摇 → 开启攻击碰撞箱 → 收招（怪物无攻击素材，采用原地前冲表现，不做任何占位）
func _process_attack(delta: float) -> void:
	_state_timer += delta
	if _state_timer <= attack_windup:
		velocity = Vector2.ZERO
		return
	if _attack_hitbox.monitoring:
		_apply_attack_damage()
		velocity = Vector2(float(_facing) * GameConfig.ENEMY_CHASE_SPEED * 1.2, 0.0)
		if _state_timer >= attack_windup + attack_active_time:
			_attack_hitbox.set_deferred("monitoring", false)
			_attack_cooldown = GameConfig.ENEMY_ATTACK_COOLDOWN
			state = State.CHASE
			_state_timer = 0.0
	else:
		velocity = Vector2.ZERO
		if _state_timer >= attack_windup:
			_attack_hitbox.set_deferred("monitoring", true)

# 被攻击瞬间：变红 + 停顿
func _process_hit(delta: float) -> void:
	_state_timer += delta
	velocity = Vector2.ZERO
	if _state_timer >= GameConfig.ENEMY_HIT_STOP:
		_sprite.modulate = _base_modulate
		state = State.CHASE
		_state_timer = 0.0

# ------------------------------ 移动与朝向 ------------------------------
func _apply_motion(delta: float) -> void:
	var motion := velocity
	if _knockback.length_squared() > 1.0:
		motion += _knockback
		_knockback = _knockback.move_toward(Vector2.ZERO, 600.0 * delta)
	global_position += motion * delta
	# 限制在安全活动区间，避免怪物跑出画面或卡进墙体
	global_position.y = clampf(global_position.y, GameConfig.ENEMY_Y_MIN, GameConfig.ENEMY_Y_MAX)

func _face_towards(sign_value: int) -> void:
	if sign_value == 0:
		return
	_facing = sign_value
	# 保留统一缩放系数，只翻转 x 的正负
	_sprite.scale = Vector2(absf(_sprite.scale.x) * float(_facing), absf(_sprite.scale.y))
	_update_attack_hitbox_transform()

func _play_animation(animation_name: String) -> void:
	if _sprite_frames == null or not _sprite_frames.has_animation(animation_name):
		return
	if _current_animation == animation_name and _sprite.is_playing():
		return
	_current_animation = animation_name
	_sprite.play(animation_name)

# ------------------------------ 目标搜索 ------------------------------
# 找到最近的存活玩家（双人时追踪更近的那一个；视野范围之外不追）
func _find_target() -> Node2D:
	var best: Node2D = null
	var best_distance := INF
	for node in get_tree().get_nodes_in_group("player_controller"):
		var player := node as PlayerController
		if player == null or player.is_dead():
			continue
		var offset: Vector2 = player.global_position - global_position
		if absf(offset.x) > GameConfig.ENEMY_DETECT_RANGE:
			continue
		if absf(offset.y) > GameConfig.ENEMY_DETECT_HEIGHT:
			continue
		var distance := offset.length()
		if distance < best_distance:
			best_distance = distance
			best = player
	return best

func _is_target_in_attack_range(target: Node2D) -> bool:
	if target == null:
		return false
	var offset: Vector2 = target.global_position - global_position
	return absf(offset.x) <= GameConfig.ENEMY_ATTACK_RANGE and absf(offset.y) <= GameConfig.ENEMY_DETECT_HEIGHT

# 攻击判定窗口内对重叠的玩家受击框结算伤害（一次攻击对同一玩家只结算一次）
func _apply_attack_damage() -> void:
	for area in _attack_hitbox.get_overlapping_areas():
		if not area.is_in_group("player_hurtbox"):
			continue
		var player := area.get_parent() as PlayerController
		if player != null:
			player.take_damage(GameConfig.ENEMY_DAMAGE_TO_PLAYER, global_position)

func _start_attack() -> void:
	state = State.ATTACK
	_state_timer = 0.0
	velocity = Vector2.ZERO

# ------------------------------ 受击 / 死亡 ------------------------------
# 被玩家普攻 / 飞盘 / 大招命中
# flash 参数：受击瞬间的闪烁颜色（剑士近战默认闪红；旅者飞盘命中传白色 = 闪白）
func take_damage(amount: int, _source_position: Vector2 = Vector2.ZERO, _attacker: Node = null,
		flash: Color = GameConfig.ENEMY_HIT_FLASH_COLOR) -> void:
	if state == State.DEAD:
		return
	hp = maxi(hp - amount, 0)
	_attack_hitbox.set_deferred("monitoring", false)
	if hp <= 0:
		_die()
		return
	state = State.HIT
	_state_timer = 0.0
	velocity = Vector2.ZERO
	_knockback = Vector2(float(_facing) * -GameConfig.ENEMY_HURT_KNOCKBACK, 0.0)
	_sprite.modulate = flash # 被攻击瞬间闪烁（默认变红，飞盘命中为闪白）
	AudioService.play_sfx("enemy_hurt")

# 死亡：白色渐变透明消失，并通知关卡掉落宝箱
func _die() -> void:
	state = State.DEAD
	remove_from_group("enemy")
	remove_from_group("enemy_normal")
	remove_from_group("enemy_elite")
	_attack_hitbox.set_deferred("monitoring", false)
	_hurtbox.set_deferred("monitorable", false)
	died.emit(self)
	AudioService.play_sfx("enemy_death")
	var tween := create_tween()
	tween.tween_property(_sprite, "modulate", Color(1.0, 1.0, 1.0, 1.0), GameConfig.ENEMY_DEATH_FADE_TIME * 0.35)
	tween.tween_property(_sprite, "modulate", Color(1.0, 1.0, 1.0, 0.0), GameConfig.ENEMY_DEATH_FADE_TIME * 0.65)
	tween.tween_callback(queue_free)

# 大招秒杀：直接死亡，不做受击停顿
func kill_by_ultimate() -> void:
	if state == State.DEAD:
		return
	hp = 0
	_die()

# ------------------------------ 辅助 ------------------------------
func _pick_patrol_interval() -> void:
	_patrol_timer = randf_range(GameConfig.ENEMY_PATROL_INTERVAL_MIN, GameConfig.ENEMY_PATROL_INTERVAL_MAX)

func get_sp_reward() -> int:
	return sp_reward_on_hit if is_elite else GameConfig.PLAYER_SP_GAIN_NORMAL

func get_drop_chest_type() -> String:
	return drop_chest_type if is_elite else GameConfig.NORMAL_DROP_CHEST

func get_spawn_position() -> Vector2:
	return _spawn_position

func debug_status_line() -> String:
	return "ENEMY(%s) HP=%d/%d STATE=%d POS=(%d,%d)" % [
		"ELITE" if is_elite else "NORMAL", hp, max_hp, state,
		int(global_position.x), int(global_position.y)
	]
