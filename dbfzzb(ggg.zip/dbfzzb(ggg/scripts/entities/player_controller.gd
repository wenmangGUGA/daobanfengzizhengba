extends CharacterBody2D
class_name PlayerController

# =============================================================================
# 玩家角色控制器（第一期：剑士模板，1P / 2P 共用同一套逻辑与素材）
# 双人完全独立：HP / SP / 状态 / 硬直 / 无敌 / 冷却全部各自持有。
# 两人完全穿透无阻挡：玩家之间不做任何碰撞（碰撞层只与“世界边界”交互）。
# =============================================================================

signal hp_changed(player_index: int, hp: int, max_hp: int)     # 血量变化（HUD 刷新）
signal sp_changed(player_index: int, sp: int, max_sp: int)     # SP 变化（HUD 刷新）
signal dodge_cooldown_changed(player_index: int, remaining: float, total: float) # 闪避冷却（图标闪烁）
signal died(player_index: int)                                 # 玩家死亡
signal ultimate_started(player_index: int)                     # 大招开始（进入霸体）
signal ultimate_finished(player_index: int)                    # 大招结束（自动关闭霸体）

# 玩家状态机
enum State { IDLE, WALK, ATTACK, DODGE, ULTIMATE, HURT, DEAD, CHARGE }
# 旅者移动三段式阶段
enum { WALK_PHASE_IDLE, WALK_PHASE_START, WALK_PHASE_LOOP, WALK_PHASE_END }
# 旅者蓄力阶段
enum { CHARGE_PHASE_NONE, CHARGE_PHASE_LOOP, CHARGE_PHASE_READY, CHARGE_PHASE_THROW }

const PLAYER_SCENE_DISC := "res://scenes/entities/traveler_disc.tscn" # 旅者飞盘（独立渲染）

const CHARACTER_ID := "swordsman"     # 默认角色模板：剑士
const CHARACTER_TRAVELER := "traveler" # 旅者（战斗素材为精灵表）
const ANIM_IDLE := "idle"             # 动画名：待机
const ANIM_WALK := "walk"             # 动画名：行走
const ANIM_ATTACK := "attack"         # 动画名：普攻
const ANIM_DODGE_STAND := "dodge_stand" # 动画名：闪避（未点方向键）
const ANIM_DODGE_MOVE := "dodge_move"   # 动画名：闪避（点了方向键）
const ANIM_DEATH := "death"           # 动画名：死亡倒地
const ANIM_HEAVY_ATTACK := "heavy_attack" # 动画名：蓄力重攻击（剑士预留；旅者蓄力走 charge 系列）
const ANIM_ULTIMATE := "ultimate"     # 动画名：大招
# 旅者专用动画名（精灵表 json 标签）
const ANIM_WALK_START := "walk_start"      # 移动起手过渡（移动表 0-1 帧）
const ANIM_WALK_END := "walk_end"          # 移动收束后摇（移动表「结束后摇」）
const ANIM_CHARGE := "charge"              # 蓄力循环（「蓄力循环」）
const ANIM_CHARGE_READY := "charge_ready"  # 准备发射（「准备发射」）
const ANIM_CHARGE_THROW := "charge_throw"  # 抛出去（「抛出去」）

@export var player_index: int = 1                     # 玩家序号：1P / 2P
@export var character_id: String = CHARACTER_ID       # 角色模板 id（第一期固定剑士）

@export_group("Scale") # ---------------- 画面占比（统一缩放） ----------------
@export_range(0.1, 5.0, 0.01) var character_scale: float = 1.5 # 角色统一缩放系数：美术图像与碰撞判定范围同步放大
@export var scale_collision_shapes: bool = true       # 是否同步缩放碰撞体（关闭则只放大图像，判定范围不变）

@export_group("Move Speed") # ---------------- 移动速度（基础 × 倍率） ----------------
@export var base_move_speed: float = 260.0            # 基础移速（像素/秒），不建议频繁改
@export var move_speed_multiplier: float = 2.0        # 速度倍率：实际移速 = 基础移速 × 倍率（微调只改这里）
@export_range(0.1, 3.0, 0.05) var dodge_speed_ratio: float = 1.35 # 闪避冲刺速度 = 实际移速 × 该比例

@export_group("Attack Hitbox") # ---------------- 攻击判定箱（可手动拖拽调整） ----------------
@export var attack_hitbox_offset_x: float = 78.0      # 攻击碰撞箱相对角色的横向偏移（朝右时）
@export var attack_hitbox_offset_y: float = -90.0     # 攻击碰撞箱相对角色的纵向偏移

@onready var _sprite: AnimatedSprite2D = $Sprite
@onready var _attack_hitbox: Area2D = $AttackHitbox
@onready var _attack_shape: CollisionShape2D = $AttackHitbox/CollisionShape2D
@onready var _hurtbox: Area2D = $Hurtbox
@onready var _body_shape: CollisionShape2D = $CollisionShape2D
@onready var _hurt_shape: CollisionShape2D = $Hurtbox/CollisionShape2D

var hp: int = GameConfig.PLAYER_MAX_HP       # 当前血量（格）
var sp: int = 0                              # 当前 SP
var is_armored: bool = false                 # 霸体（大招期间）
var is_invincible: bool = false              # 无敌（闪避 / 受击后短无敌 / 霸体）
var facing: int = 1                          # 朝向：1 向右，-1 向左（只看左右移动方向）
var state: int = State.IDLE                  # 当前状态

# 缩放前的原始几何（在 _ready 里记录一次，之后每次缩放都从原始值重算，避免反复相乘累积误差）
var _body_shape_size: Vector2 = Vector2.ZERO
var _hurt_shape_size: Vector2 = Vector2.ZERO
var _attack_shape_size: Vector2 = Vector2.ZERO
var _body_shape_position: Vector2 = Vector2.ZERO
var _hurt_shape_position: Vector2 = Vector2.ZERO

var _state_timer: float = 0.0                # 当前状态计时
var _dodge_cooldown: float = 0.0             # 闪避剩余冷却
var _invincible_timer: float = 0.0           # 剩余无敌时间
var _blink_timer: float = 0.0                # 无敌闪烁计时
var _knockback: Vector2 = Vector2.ZERO       # 受击击退速度（随时间衰减）
var _dodge_direction: Vector2 = Vector2.ZERO # 闪避冲刺方向
var _attack_hit_targets: Array = []          # 本次普攻已命中的目标（同一次攻击不重复扣血）
var _ultimate_kill_done: bool = false        # 大招秒杀判定是否已执行
var _current_animation: String = ""          # 当前正在播放的动画名（避免重复重播同段动画）
var _walk_phase: int = WALK_PHASE_IDLE       # 旅者移动三段式阶段（起手/循环/后摇）
var _charge_phase: int = CHARGE_PHASE_NONE   # 旅者蓄力阶段（循环/准备/抛出）
var _charge_source_action: String = ""       # 触发蓄力的按键（松手判定只认这个键）
var _attack_hold_pending: bool = false       # 旅者普攻键是否处于"点按/长按"待判定
var _attack_hold_timer: float = 0.0          # 待判定计时
var _disc_scene: PackedScene = null          # 旅者飞盘场景（懒加载）
var _held_disc: TravelerDisc = null          # 长按蓄力时挂在手上的飞盘特效
var _disc_spawned_this_attack: bool = false   # 本次普攻是否已生成飞盘（避免重复生成）
var _sprite_frames: SpriteFrames = null      # 运行时构建的动画帧
var _anim_anchors: Dictionary = {}           # 动画名 → 该动画帧内的脚底锚点（不同素材/角色各一套）
var _ultimate_duration: float = 1.0          # 大招动画总时长（按素材帧数计算）
var _ultimate_kill_time: float = 0.5         # 大招秒杀判定发生的时刻

func _ready() -> void:
	add_to_group("player_controller")
	add_to_group("player_%d" % player_index)
	collision_layer = 1 << 0                  # 层 1：player_body
	collision_mask = 1 << 4                   # 只与层 5（world_bounds 世界边界）碰撞 → 玩家之间完全穿透
	_hurtbox.collision_layer = 1 << 6         # 层 7：player_hurtbox
	_hurtbox.collision_mask = 0
	_hurtbox.add_to_group("player_hurtbox")   # 供怪物攻击碰撞箱识别
	_attack_hitbox.collision_layer = 1 << 2   # 层 3：player_attack
	_attack_hitbox.collision_mask = 1 << 7    # 只检测层 8：enemy_hurtbox
	_attack_hitbox.monitoring = false         # 攻击判定默认关闭，只在判定帧内开启
	# 友伤彻底关闭：攻击碰撞箱永远不检测 player_hurtbox（层 7 不在 mask 内），双人互不伤害
	_attack_hitbox.area_entered.connect(_on_attack_area_entered)
	_build_animations()
	_cache_base_geometry()                    # 先记录原始几何，再按缩放系数统一放大
	_apply_character_scale()
	hp = GameConfig.PLAYER_MAX_HP
	sp = 0
	_update_facing_by_sign(1)
	_enter_state(State.IDLE)
	hp_changed.emit(player_index, hp, GameConfig.PLAYER_MAX_HP)
	sp_changed.emit(player_index, sp, GameConfig.PLAYER_MAX_SP)
	dodge_cooldown_changed.emit(player_index, 0.0, GameConfig.PLAYER_DODGE_COOLDOWN)

# ------------------------------ 动画构建 ------------------------------
# 本角色自己的动画优先；缺的动画用剑士模板兜底（保证攻击判定帧 / 各种时长不缺失）
# 素材两种形式都支持：① 目录序列帧（剑士）② 横向精灵表（旅者）
func _build_animations() -> void:
	_sprite_frames = SpriteFrames.new()
	_sprite_frames.remove_animation("default")
	_anim_anchors.clear()
	# 1) 本角色自己的动画
	if character_id == CHARACTER_TRAVELER:
		_build_traveler_animations()
	else:
		for spec in _swordsman_anim_specs():
			_add_dir_animation(spec)
	# 2) 仍缺失的动画 → 剑士模板兜底
	var fallback_names: Array[String] = []
	for spec in _swordsman_anim_specs():
		var anim_name := String(spec["name"])
		if _sprite_frames.has_animation(anim_name):
			continue
		if _add_dir_animation(spec):
			fallback_names.append(anim_name)
	# 蓄力重攻击（预留）：素材未导入，启动时不加载，避免每次启动都提示缺素材
	_sprite.sprite_frames = _sprite_frames
	if character_id != CHARACTER_ID:
		if fallback_names.is_empty():
			print("[角色] %s 使用自己的动画素材。" % character_id)
		else:
			print("[角色] %s 暂缺这些动画：%s —— 本次用剑士模板代替（补齐后加进 _build_animations 即可）。"
				% [character_id, ", ".join(fallback_names)])
	_sprite.animation_finished.connect(_on_animation_finished)
	_sprite.frame_changed.connect(_on_sprite_frame_changed)
	_sprite.centered = false                       # 使用左上角对齐 + 锚点偏移，保证脚底精确落地
	_ultimate_duration = _compute_ultimate_duration()
	_ultimate_kill_time = float(GameConfig.ULTIMATE_KILL_FRAME) / maxf(GameConfig.ANIM_FPS_ULTIMATE, 0.001)
	# 旅者飞盘场景（懒加载，剑士不需要）
	if character_id == CHARACTER_TRAVELER:
		_disc_scene = load(PLAYER_SCENE_DISC) as PackedScene

# 剑士模板动画表（目录序列帧）
func _swordsman_anim_specs() -> Array:
	return [
		{"name": ANIM_IDLE, "dir": AssetPaths.SWORDSMAN_IDLE_DIR, "fps": GameConfig.ANIM_FPS_IDLE, "loop": true},
		{"name": ANIM_WALK, "dir": AssetPaths.SWORDSMAN_WALK_DIR, "fps": GameConfig.ANIM_FPS_WALK, "loop": true},
		{"name": ANIM_ATTACK, "dir": AssetPaths.SWORDSMAN_ATTACK_DIR, "fps": GameConfig.ANIM_FPS_ATTACK, "loop": false},
		{"name": ANIM_DODGE_STAND, "dir": AssetPaths.SWORDSMAN_DODGE_IDLE_DIR, "fps": GameConfig.ANIM_FPS_DODGE, "loop": false},
		{"name": ANIM_DODGE_MOVE, "dir": AssetPaths.SWORDSMAN_DODGE_MOVE_DIR, "fps": GameConfig.ANIM_FPS_DODGE, "loop": false},
		{"name": ANIM_DEATH, "dir": AssetPaths.SWORDSMAN_DEATH_DIR, "fps": GameConfig.ANIM_FPS_DEATH, "loop": false},
		{"name": ANIM_ULTIMATE, "dir": AssetPaths.SWORDSMAN_ULTIMATE_DIR, "fps": GameConfig.ANIM_FPS_ULTIMATE, "loop": false},
	]

# 旅者的全部动画（精灵表 + Aseprite json 标签）
# 移动：起手过渡(0-1) → 移动中循环(2-5) → 结束后摇(6)
# 平A ：旅者平a.png（3 帧）
# 蓄力：蓄力循环(0-2) → 准备发射(3-4) → 抛出去(5-7)
func _build_traveler_animations() -> void:
	var fps := GameConfig.TRAVELER_ANIM_FPS
	# 待机（无 json，横向 4 帧）
	_add_plain_sheet_animation(ANIM_IDLE, AssetPaths.TRAVELER_IDLE_SHEET, GameConfig.TRAVELER_IDLE_FRAMES, 0,
		GameConfig.TRAVELER_IDLE_FRAMES - 1, fps, true, Vector2(25.5, 62.0))
	# 移动：起手 / 循环 / 后摇（带 json 标签）
	_add_plain_sheet_animation(ANIM_WALK_START, AssetPaths.TRAVELER_MOVE_SHEET, 7, 0, 1, fps, false, Vector2(25.5, 62.0))
	_add_aseprite_animation(ANIM_WALK, AssetPaths.TRAVELER_MOVE_SHEET, AssetPaths.TRAVELER_MOVE_JSON,
		GameConfig.TRAVELER_TAG_WALK_LOOP, fps, true)
	_add_aseprite_animation(ANIM_WALK_END, AssetPaths.TRAVELER_MOVE_SHEET, AssetPaths.TRAVELER_MOVE_JSON,
		GameConfig.TRAVELER_TAG_WALK_END, fps, false)
	# 平A：抬手（无 json，横向 3 帧）
	_add_plain_sheet_animation(ANIM_ATTACK, AssetPaths.TRAVELER_ATTACK_SHEET, GameConfig.TRAVELER_ATTACK_FRAMES,
		0, GameConfig.TRAVELER_ATTACK_FRAMES - 1, fps, false, Vector2(25.5, 62.0))
	# 蓄力本体：蓄力循环 / 准备发射 / 抛出去
	_add_aseprite_animation(ANIM_CHARGE, AssetPaths.TRAVELER_CHARGE_SHEET, AssetPaths.TRAVELER_CHARGE_JSON,
		GameConfig.TRAVELER_TAG_CHARGE_LOOP, fps, true)
	_add_aseprite_animation(ANIM_CHARGE_READY, AssetPaths.TRAVELER_CHARGE_SHEET, AssetPaths.TRAVELER_CHARGE_JSON,
		GameConfig.TRAVELER_TAG_CHARGE_READY, fps, false)
	_add_aseprite_animation(ANIM_CHARGE_THROW, AssetPaths.TRAVELER_CHARGE_SHEET, AssetPaths.TRAVELER_CHARGE_JSON,
		GameConfig.TRAVELER_TAG_CHARGE_THROW, fps, false)

# 无 json 的横向精灵表 → 动画（帧区间 + 固定锚点）
func _add_plain_sheet_animation(anim_name: String, sheet_path: String, total_frames: int,
		from_index: int, to_index: int, fps: float, loop: bool, anchor: Vector2) -> bool:
	var info := ArtLoader.add_sheet_range_animation(_sprite_frames, anim_name, sheet_path, total_frames,
		from_index, to_index, fps, loop)
	if not info.get("ok", false):
		return false
	_anim_anchors[anim_name] = anchor
	return true

# Aseprite 标签 → 动画（锚点优先用配置表，没配就用"各帧内容中心均值"）
func _add_aseprite_animation(anim_name: String, png_path: String, json_path: String,
		tag_name: String, fps: float, loop: bool) -> bool:
	var info := ArtLoader.add_aseprite_animation(_sprite_frames, anim_name, png_path, json_path, tag_name, fps, loop)
	if not info.get("ok", false):
		return false
	var fallback: Vector2 = info.get("anchor", Vector2.ZERO)
	_anim_anchors[anim_name] = _anchor_from_config(anim_name, GameConfig.TRAVELER_ANIM_ANCHORS, fallback)
	return true

# 目录序列帧 → 动画（锚点取剑士模板锚点表）
func _add_dir_animation(spec: Dictionary) -> bool:
	var anim_name := String(spec.get("name", ""))
	if not ArtLoader.add_dir_animation(_sprite_frames, anim_name, String(spec.get("dir", "")),
			float(spec.get("fps", 8.0)), bool(spec.get("loop", true))):
		return false
	_anim_anchors[anim_name] = _anchor_from_config(anim_name, GameConfig.PLAYER_ANIM_ANCHORS)
	return true

# 从锚点表取动画锚点（表里没有就用兜底值）
func _anchor_from_config(anim_name: String, table: Dictionary, fallback: Vector2 = Vector2(108.0, 234.0)) -> Vector2:
	var key := anim_name
	if key == ANIM_DODGE_STAND:
		key = "dodge_stand"
	elif key == ANIM_DODGE_MOVE:
		key = "dodge_move"
	return table.get(key, fallback)

# 大招动画总时长（素材缺失时返回兜底短时长，避免角色卡在大招状态）
func _compute_ultimate_duration() -> float:
	var frames := ArtLoader.list_frames(AssetPaths.SWORDSMAN_ULTIMATE_DIR)
	if frames.is_empty():
		return 0.8
	return float(frames.size()) / maxf(GameConfig.ANIM_FPS_ULTIMATE, 0.001)

# ------------------------------ 画面占比：统一缩放 ------------------------------
# 记录 .tscn 里的原始几何尺寸与位置（只记录一次，之后缩放都基于原始值重算）
func _cache_base_geometry() -> void:
	_body_shape_size = _get_shape_size(_body_shape)
	_hurt_shape_size = _get_shape_size(_hurt_shape)
	_attack_shape_size = _get_shape_size(_attack_shape)
	_body_shape_position = _body_shape.position
	_hurt_shape_position = _hurt_shape.position

func _get_shape_size(shape_node: CollisionShape2D) -> Vector2:
	if shape_node == null or shape_node.shape == null:
		return Vector2.ZERO
	if shape_node.shape is RectangleShape2D:
		return (shape_node.shape as RectangleShape2D).size
	if shape_node.shape is CircleShape2D:
		return Vector2.ONE * (shape_node.shape as CircleShape2D).radius * 2.0
	return Vector2.ZERO

func _set_shape_size(shape_node: CollisionShape2D, size: Vector2) -> void:
	if shape_node == null or shape_node.shape == null or size == Vector2.ZERO:
		return
	# 复制形状再改尺寸：避免同一场景的多个玩家实例共用同一份 SubResource 互相影响
	if shape_node.shape.resource_local_to_scene == false:
		shape_node.shape = shape_node.shape.duplicate()
	if shape_node.shape is RectangleShape2D:
		(shape_node.shape as RectangleShape2D).size = size
	elif shape_node.shape is CircleShape2D:
		(shape_node.shape as CircleShape2D).radius = size.x * 0.5

# 统一缩放：精灵与碰撞体一起按 character_scale 放大/缩小
func _apply_character_scale() -> void:
	var factor := maxf(character_scale, 0.01)
	# 1) 美术图像：整体缩放（朝向镜像交给 _update_facing_by_sign 处理 x 的正负）
	#    注意：不同角色素材分辨率差别很大（剑士单帧 256×256、旅者单帧 48×63），
	#    所以"图像缩放"允许按角色覆盖（PLAYER_SPRITE_SCALE_OVERRIDES），
	#    而下面的碰撞体仍然按 character_scale 缩放 → 判定范围与剑士保持一致。
	var sprite_factor := _sprite_scale()
	_sprite.scale = Vector2(sprite_factor * float(facing), sprite_factor)
	if not scale_collision_shapes:
		_update_attack_hitbox_transform()
		return
	# 2) 碰撞体同步放大（脚底碰撞盒 / 受击框 / 攻击判定框）
	_set_shape_size(_body_shape, _body_shape_size * factor)
	_set_shape_size(_hurt_shape, _hurt_shape_size * factor)
	_set_shape_size(_attack_shape, _attack_shape_size * factor)
	# 3) 碰撞体位置同步缩放（脚底碰撞盒、受击框相对角色原点的偏移按同一系数放大）
	_body_shape.position = _body_shape_position * factor
	_hurt_shape.position = _hurt_shape_position * factor
	_update_attack_hitbox_transform()

# 图像缩放系数：优先取该角色的覆盖值，没有就用场景里的 character_scale
func _sprite_scale() -> float:
	return maxf(float(GameConfig.PLAYER_SPRITE_SCALE_OVERRIDES.get(character_id, character_scale)), 0.01)

# 攻击判定箱位置：随朝向镜像，并随统一缩放系数同步放大
func _update_attack_hitbox_transform() -> void:
	if _attack_hitbox == null:
		return
	var factor := maxf(character_scale, 0.01)
	_attack_hitbox.position = Vector2(
		attack_hitbox_offset_x * factor * float(facing),
		attack_hitbox_offset_y * factor
	)

# ------------------------------ 移动速度：基础 × 倍率 ------------------------------
# 实际移动速度 = 基础移速 × 速度倍率（微调只改倍率，不动移动逻辑）
func get_move_speed() -> float:
	return maxf(base_move_speed * move_speed_multiplier, 0.0)

# 闪避冲刺速度 = 实际移速 × 闪避比例
func get_dodge_speed() -> float:
	return get_move_speed() * dodge_speed_ratio

# ------------------------------ 主循环 ------------------------------
func _physics_process(delta: float) -> void:
	_update_timers(delta)
	match state:
		State.IDLE, State.WALK:
			_process_locomotion(delta)
		State.ATTACK:
			_process_attack(delta)
		State.CHARGE:
			_process_charge(delta)
		State.DODGE:
			_process_dodge(delta)
		State.ULTIMATE:
			_process_ultimate(delta)
		State.HURT:
			_process_hurt(delta)
		State.DEAD:
			velocity = Vector2.ZERO
	# 受击击退速度叠加并衰减
	if _knockback.length_squared() > 1.0:
		velocity += _knockback
		_knockback = _knockback.move_toward(Vector2.ZERO, 900.0 * delta)
	move_and_slide()
	_clamp_to_safe_area()

# 计时器统一更新：闪避冷却 / 无敌 / 无敌闪烁
func _update_timers(delta: float) -> void:
	if _dodge_cooldown > 0.0:
		_dodge_cooldown = maxf(_dodge_cooldown - delta, 0.0)
		dodge_cooldown_changed.emit(player_index, _dodge_cooldown, GameConfig.PLAYER_DODGE_COOLDOWN)
	if _invincible_timer > 0.0:
		_invincible_timer = maxf(_invincible_timer - delta, 0.0)
		if _invincible_timer <= 0.0:
			is_invincible = is_armored # 霸体期间持续无敌
			_sprite.modulate.a = 1.0
	if is_invincible and not is_armored:
		# 受伤后短暂闪烁无敌：防连续扣血
		_blink_timer += delta
		if _blink_timer >= GameConfig.PLAYER_HURT_BLINK_INTERVAL:
			_blink_timer = 0.0
			_sprite.modulate.a = 0.35 if _sprite.modulate.a > 0.9 else 1.0

# 正常移动（可自由上下左右，安全 Y 区间由世界边界隐形墙限制）
# 旅者移动为三段式：起手过渡 → 移动中循环 → 停止后摇（由 _walk_phase 管理）
func _process_locomotion(delta: float) -> void:
	var input_vector := InputService.get_move_vector(player_index)
	var moving := input_vector.length() > 0.05
	if moving:
		velocity = input_vector * get_move_speed() # 实际移速 = 基础移速 × 速度倍率
		if absf(input_vector.x) > 0.05:
			_update_facing_by_sign(1 if input_vector.x > 0.0 else -1)
		_set_locomotion_state(State.WALK)
	else:
		velocity = Vector2.ZERO
		_set_locomotion_state(State.IDLE)
	_update_walk_phase(delta, moving)
	_update_attack_hold(delta)
	# 行为键：普攻 / 闪避 / 大招（按住不连打：只在“刚按下”时触发一次）
	# 旅者的普攻键是"点按=平A / 长按=蓄力"，所以按下先进入待判定（见 _update_attack_hold）
	if InputService.is_just_pressed(player_index, "attack"):
		if _has_animation(ANIM_CHARGE):
			_attack_hold_pending = true
			_attack_hold_timer = 0.0
		else:
			_start_attack()
	elif InputService.is_just_pressed(player_index, "dodge"):
		_attack_hold_pending = false
		_start_dodge(input_vector)
	elif InputService.is_just_pressed(player_index, "ultimate"):
		_attack_hold_pending = false
		_start_ultimate()
	elif InputService.is_just_pressed(player_index, "charge"):
		_attack_hold_pending = false
		_start_charge_attack("charge")

# 旅者普攻键的"点按 / 长按"判定：
#   按下后最短蓄力时间内松手 → 平A（5 格）
#   一直按住到最短蓄力时间     → 进入蓄力（播「蓄力循环」，松手才发射）
func _update_attack_hold(delta: float) -> void:
	if not _attack_hold_pending:
		return
	_attack_hold_timer += delta
	if InputService.is_just_released(player_index, "attack") or not InputService.is_pressed(player_index, "attack"):
		# 已松手（也包括"同一帧内按下又松开"的极快点按）→ 判定为平A
		_attack_hold_pending = false
		_start_attack()
	elif _attack_hold_timer >= GameConfig.TRAVELER_CHARGE_MIN_TIME:
		_attack_hold_pending = false
		_start_charge_attack("attack")

# 旅者移动三段式：起手（0-1 帧）→ 循环（「移动中循环」）→ 收束（「结束后摇」）
# 没有对应动画的角色（剑士）自动退化为原来的"待机 / 行走"两态
func _update_walk_phase(_delta: float, moving: bool) -> void:
	if not _has_animation(ANIM_WALK_START):
		return
	if moving:
		if _walk_phase == WALK_PHASE_IDLE or _walk_phase == WALK_PHASE_END:
			# 重新起步：播起手过渡，之后自动进入循环
			_walk_phase = WALK_PHASE_START
			_play_animation(ANIM_WALK_START)
		elif _walk_phase == WALK_PHASE_START and not _sprite.is_playing():
			_walk_phase = WALK_PHASE_LOOP
			_play_animation(ANIM_WALK)
		return
	# 停止移动
	if _walk_phase == WALK_PHASE_START or _walk_phase == WALK_PHASE_LOOP:
		_walk_phase = WALK_PHASE_END
		_play_animation(ANIM_WALK_END if _has_animation(ANIM_WALK_END) else ANIM_IDLE)
	elif _walk_phase == WALK_PHASE_END:
		if not _sprite.is_playing():
			_walk_phase = WALK_PHASE_IDLE
			_play_animation(ANIM_IDLE)
	elif _walk_phase == WALK_PHASE_IDLE and _current_animation != ANIM_IDLE:
		# 初始待机 / 从其它状态回到站立：确保待机动画在播（否则锚点不生效、角色会站到地面线以下）
		_play_animation(ANIM_IDLE)

# 普攻：单点单次完整动画；剑士用攻击碰撞箱，旅者在出手帧生成飞盘
func _process_attack(delta: float) -> void:
	velocity = velocity.move_toward(Vector2.ZERO, get_move_speed() * 4.0 * delta)
	_state_timer += delta

# 蓄力（旅者）：长按蓄力 → 松手发射
#   阶段 LOOP ：循环播「蓄力循环」；到最长蓄力时间 → 切「准备发射」（停在最后一帧）继续等松手
#   松手      ：蓄力时长 < 最短 → 取消（不发射）；否则进入 THROW 抛出飞盘
#   阶段 THROW：播「抛出去」，开始时生成飞盘；播完回待机
func _process_charge(delta: float) -> void:
	velocity = velocity.move_toward(Vector2.ZERO, get_move_speed() * 4.0 * delta)
	_state_timer += delta
	if _charge_phase == CHARGE_PHASE_LOOP and _state_timer >= GameConfig.TRAVELER_CHARGE_MAX_TIME:
		# 蓄满：停在"准备发射"姿势，继续等待松手（不再自动抛出）
		_charge_phase = CHARGE_PHASE_READY
		_play_animation(ANIM_CHARGE_READY)
		if _held_disc != null and is_instance_valid(_held_disc):
			_held_disc.play_charge_ready() # 手上特效同步切「准备发射」3-4 帧
	# 松手判定：只认当初按下的那个键
	if _charge_phase != CHARGE_PHASE_THROW and not _charge_source_action.is_empty() \
			and InputService.is_just_released(player_index, _charge_source_action):
		if _state_timer < GameConfig.TRAVELER_CHARGE_MIN_TIME:
			_cancel_charge() # 蓄力不足最短时间：取消，不发射
		else:
			_charge_phase = CHARGE_PHASE_THROW
			_state_timer = 0.0
			_play_animation(ANIM_CHARGE_THROW)
			_throw_disc(true) # 抛出瞬间：解除手持跟随 → 变成独立投射物
			return
	if _charge_phase == CHARGE_PHASE_THROW and _state_timer >= GameConfig.TRAVELER_CHARGE_THROW_TIME:
		_charge_phase = CHARGE_PHASE_NONE
		_charge_source_action = ""
		_enter_state(State.IDLE)
		_play_animation(ANIM_IDLE)

# 取消蓄力：销毁手持特效、回到待机，不产生飞盘
func _cancel_charge() -> void:
	_charge_phase = CHARGE_PHASE_NONE
	_charge_source_action = ""
	_destroy_held_disc()
	_enter_state(State.IDLE)
	_play_animation(ANIM_IDLE)

# ------------------------------ 蓄力手持特效（飞盘挂在手上跟随） ------------------------------
# 长按蓄力期间：把【旅者蓄力攻击特效.png】实例挂成角色的子节点，播「蓄力」循环；
# 因为手持动画与蓄力本体图集（旅者蓄力攻击.png）帧布局一致、锚点相同，所以会正好叠在手上。
func _spawn_held_disc() -> void:
	if _disc_scene == null:
		return
	_destroy_held_disc()
	var disc := _disc_scene.instantiate() as TravelerDisc
	if disc == null:
		return
	disc.held_mode = true
	disc.charge_mode = true
	disc.facing_sign = facing
	# 【必须在 add_child 之前设置】碰撞层与 body_entered 连接是在 _ready 里按这个开关决定的
	disc.destroy_on_wall = true
	disc.position = Vector2.ZERO # 与角色精灵同原点（锚点相同 → 特效落在手上）
	add_child(disc)
	_held_disc = disc

# 销毁手持特效（取消蓄力 / 被打断 / 角色死亡时调用）
func _destroy_held_disc() -> void:
	if _held_disc != null and is_instance_valid(_held_disc):
		_held_disc.queue_free()
	_held_disc = null

# 闪避：无敌 2 秒（动画结束后仍保留剩余无敌时间），冷却 2 秒
func _process_dodge(delta: float) -> void:
	_state_timer += delta
	velocity = _dodge_direction * get_dodge_speed()
	var duration := _animation_duration(ANIM_DODGE_MOVE if _dodge_direction.length() > 0.05 else ANIM_DODGE_STAND)
	if _state_timer >= duration:
		_enter_state(State.IDLE)

# 大招：霸体 + 秒杀，动画结束自动关闭霸体
func _process_ultimate(delta: float) -> void:
	_state_timer += delta
	velocity = Vector2.ZERO
	if not _ultimate_kill_done and _state_timer >= _ultimate_kill_time:
		_ultimate_kill_done = true
		_trigger_ultimate_kill()
	if _state_timer >= _ultimate_duration:
		_finish_ultimate()

# 硬直：0.4 秒禁止移动 / 攻击 / 闪避
func _process_hurt(delta: float) -> void:
	_state_timer += delta
	if _state_timer >= GameConfig.PLAYER_HURT_STUN:
		_enter_state(State.IDLE)

# 死亡：播放倒地序列并保持尸体
func _process_dead(_delta: float) -> void:
	velocity = Vector2.ZERO

# ------------------------------ 行为：普攻 ------------------------------
func _start_attack() -> void:
	if not _can_act():
		return
	if not _has_animation(ANIM_ATTACK):
		return
	_attack_hit_targets.clear()
	_enter_state(State.ATTACK)
	_play_animation(ANIM_ATTACK)
	AudioService.play_sfx("attack")

# 蓄力攻击：
#   旅者 → 长按蓄力：播「蓄力循环」→ 到最长蓄力时间停在「准备发射」→ **松手才**播「抛出去」并生成飞盘（伤害 10 格）
#   剑士 → 仍走预留分支（素材未导入时只提示一次，不生成占位物）
func _start_charge_attack(source_action: String = "charge") -> void:
	if not _can_act():
		return
	if character_id == CHARACTER_TRAVELER and _has_animation(ANIM_CHARGE):
		_charge_source_action = source_action
		_enter_state(State.CHARGE)
		_charge_phase = CHARGE_PHASE_LOOP
		_play_animation(ANIM_CHARGE) # 「蓄力循环」标签（循环播放）
		_spawn_held_disc()           # 长按期间：蓄力飞盘特效挂在手上跟随（播「蓄力」循环）
		AudioService.play_sfx("attack")
		return
	if not _has_animation(ANIM_HEAVY_ATTACK):
		ArtLoader.warn_missing(AssetPaths.HEAVY_ATTACK_DIR)
		return
	_enter_state(State.ATTACK)
	_play_animation(ANIM_HEAVY_ATTACK)

# ------------------------------ 旅者飞盘 ------------------------------
# 平A：在出手帧生成飞盘（伤害 5 格，命中闪白 + 击中特效）
func _spawn_normal_disc() -> void:
	if _disc_scene == null:
		return
	var disc := _disc_scene.instantiate() as TravelerDisc
	if disc == null:
		return
	disc.direction = facing
	disc.speed = GameConfig.TRAVELER_DISC_SPEED
	disc.max_distance = GameConfig.TRAVELER_DISC_MAX_DISTANCE
	disc.damage = GameConfig.PLAYER_ATTACK_DAMAGE
	disc.charge_mode = false
	disc.flash_white = true
	disc.hit_fx_path = AssetPaths.TRAVELER_HIT_FX
	disc.homing_radius = GameConfig.TRAVELER_DISC_HOMING_RADIUS
	disc.homing_delay = GameConfig.TRAVELER_DISC_HOMING_DELAY
	disc.homing_turn_speed = GameConfig.TRAVELER_DISC_HOMING_TURN_SPEED
	_attach_disc(disc, GameConfig.TRAVELER_DISC_SPAWN_OFFSET)
	AudioService.play_sfx("attack")

# 蓄力：抛出飞盘（伤害 10 格，飞行途中程序放大 + 命中碎裂特效）
# 手上已有跟随特效时 → 直接"解除跟随"变成同一颗飞盘（视觉上就是从手里飞出去）
func _throw_disc(charged: bool) -> void:
	var offset := GameConfig.TRAVELER_CHARGE_DISC_SPAWN_OFFSET if charged else GameConfig.TRAVELER_DISC_SPAWN_OFFSET
	var spawn := global_position + Vector2(offset.x * float(facing), offset.y)
	if charged and _held_disc != null and is_instance_valid(_held_disc):
		var host: Node = get_tree().current_scene
		if host == null:
			host = get_parent()
		_apply_charge_disc_params(_held_disc)
		_held_disc.release_as_projectile(host, spawn)
		_held_disc = null
		return
	if _disc_scene == null:
		return
	var disc := _disc_scene.instantiate() as TravelerDisc
	if disc == null:
		return
	disc.direction = facing
	disc.charge_mode = charged
	disc.flash_white = true
	if charged:
		_apply_charge_disc_params(disc)
	else:
		disc.speed = GameConfig.TRAVELER_DISC_SPEED
		disc.max_distance = GameConfig.TRAVELER_DISC_MAX_DISTANCE
		disc.damage = GameConfig.PLAYER_ATTACK_DAMAGE
		disc.homing_radius = GameConfig.TRAVELER_DISC_HOMING_RADIUS
		disc.homing_delay = GameConfig.TRAVELER_DISC_HOMING_DELAY
		disc.homing_turn_speed = GameConfig.TRAVELER_DISC_HOMING_TURN_SPEED
	_attach_disc(disc, offset)

# 蓄力飞盘的战斗参数（伤害 / 放大 / 自动瞄准 / 穿透 / 撞墙销毁）
func _apply_charge_disc_params(disc: TravelerDisc) -> void:
	disc.speed = GameConfig.TRAVELER_DISC_CHARGE_SPEED
	disc.max_distance = GameConfig.TRAVELER_DISC_CHARGE_MAX_DISTANCE
	disc.damage = GameConfig.PLAYER_CHARGE_ATTACK_DAMAGE
	disc.grow_scale = GameConfig.TRAVELER_DISC_CHARGE_GROW
	disc.grow_time = GameConfig.TRAVELER_DISC_CHARGE_GROW_TIME
	disc.homing_radius = GameConfig.TRAVELER_CDISC_HOMING_RADIUS
	disc.homing_delay = GameConfig.TRAVELER_CDISC_HOMING_DELAY
	disc.homing_turn_speed = GameConfig.TRAVELER_CDISC_HOMING_TURN_SPEED
	disc.pierce_limit = GameConfig.TRAVELER_CHARGE_DISC_PIERCE # 最大穿透 3 个敌人
	disc.destroy_on_wall = true                                # 碰到墙直接销毁
	disc.hit_fx_path = AssetPaths.TRAVELER_HIT_FX              # 中间穿透时的小闪白

# 把飞盘挂到关卡（独立于角色本体渲染：角色移动不会带着飞盘跑）
# 出手点用配置表里的偏移（相对角色原点=脚底），让飞盘视觉上正好从手里抛出
func _attach_disc(disc: TravelerDisc, offset: Vector2) -> void:
	var host: Node = get_tree().current_scene
	if host == null:
		host = get_parent()
	host.add_child(disc)
	disc.global_position = global_position + Vector2(offset.x * float(facing), offset.y)

# ------------------------------ 行为：闪避 ------------------------------
func _start_dodge(input_vector: Vector2) -> void:
	if not _can_act():
		return
	if _dodge_cooldown > 0.0:
		return # 冷却中不可再次释放闪避
	if sp < GameConfig.PLAYER_DODGE_SP_COST:
		return # SP 不足
	_set_sp(sp - GameConfig.PLAYER_DODGE_SP_COST)
	_dodge_cooldown = GameConfig.PLAYER_DODGE_COOLDOWN
	dodge_cooldown_changed.emit(player_index, _dodge_cooldown, GameConfig.PLAYER_DODGE_COOLDOWN)
	var use_move_animation := input_vector.length() > 0.05
	_dodge_direction = input_vector.normalized() if use_move_animation else Vector2.ZERO
	_set_invincible(GameConfig.PLAYER_DODGE_INVINCIBLE)
	_enter_state(State.DODGE)
	if use_move_animation:
		if absf(input_vector.x) > 0.05:
			_update_facing_by_sign(1 if input_vector.x > 0.0 else -1)
		_play_animation(ANIM_DODGE_MOVE)
	else:
		_play_animation(ANIM_DODGE_STAND)
	AudioService.play_sfx("dodge")

# ------------------------------ 行为：大招 ------------------------------
func _start_ultimate() -> void:
	if not _can_act():
		return
	if sp < GameConfig.PLAYER_ULTIMATE_SP_COST:
		return # 大招必须 SP 满 100 才能释放
	_set_sp(0) # 释放清空全部 SP
	is_armored = true
	is_invincible = true
	_sprite.modulate.a = 1.0
	_ultimate_kill_done = false
	_enter_state(State.ULTIMATE)
	_play_animation(ANIM_ULTIMATE)
	# 全屏大招动画由关卡负责播放（素材驱动、全屏展示）
	get_tree().call_group("level_controller", "play_ultimate_cutscene", self, _ultimate_duration)
	ultimate_started.emit(player_index)
	AudioService.play_sfx("ultimate")

func _trigger_ultimate_kill() -> void:
	get_tree().call_group("level_controller", "execute_ultimate_kill", self)

func _finish_ultimate() -> void:
	is_armored = false
	if _invincible_timer <= 0.0:
		is_invincible = false
	_enter_state(State.IDLE)
	ultimate_finished.emit(player_index)

# ------------------------------ 受伤 / 死亡 ------------------------------
# 被怪物击中：0.4 秒硬直 + 小幅击退；霸体 / 无敌期间免疫
func take_damage(amount: int, source_position: Vector2 = Vector2.ZERO) -> void:
	if state == State.DEAD or is_armored or is_invincible:
		return
	_set_hp(hp - amount)
	var knockback_direction := signf(global_position.x - source_position.x)
	if is_zero_approx(knockback_direction):
		knockback_direction = -float(facing)
	_knockback = Vector2(knockback_direction, -0.25).normalized() * GameConfig.PLAYER_HURT_KNOCKBACK
	if hp <= 0:
		_die()
		return
	_set_invincible(GameConfig.PLAYER_HURT_INVINCIBLE)
	_enter_state(State.HURT)
	_play_animation(ANIM_IDLE) # 硬直期间保持站立帧，不做任何占位表现
	AudioService.play_sfx("player_hurt")

func _die() -> void:
	_enter_state(State.DEAD)
	is_invincible = true
	_sprite.modulate.a = 1.0
	_play_animation(ANIM_DEATH)
	velocity = Vector2.ZERO
	died.emit(player_index)
	AudioService.play_sfx("player_death")

# 复活 / 关卡重置时使用（第一期关卡内不复活，仅预留接口）
func reset_player(spawn_position: Vector2) -> void:
	global_position = spawn_position
	hp = GameConfig.PLAYER_MAX_HP
	sp = 0
	is_armored = false
	is_invincible = false
	_knockback = Vector2.ZERO
	_dodge_cooldown = 0.0
	_invincible_timer = 0.0
	_sprite.modulate.a = 1.0
	_enter_state(State.IDLE)
	hp_changed.emit(player_index, hp, GameConfig.PLAYER_MAX_HP)
	sp_changed.emit(player_index, sp, GameConfig.PLAYER_MAX_SP)

# ------------------------------ 攻击判定 ------------------------------
# 攻击碰撞箱开启瞬间记录命中目标；同一次普攻对同一目标只结算一次
func _on_attack_area_entered(area: Area2D) -> void:
	if not area.is_in_group("enemy_hurtbox"):
		return
	if not _is_attack_frame_active():
		return
	var enemy := _find_enemy_from_area(area)
	if enemy == null or _attack_hit_targets.has(enemy):
		return
	_attack_hit_targets.append(enemy)
	if enemy.has_method("take_damage"):
		enemy.call("take_damage", GameConfig.PLAYER_ATTACK_DAMAGE, global_position, self)
	# 命中回 SP：普通怪 +10，精英怪 +20（数值由怪物自身标签提供，精英怪体系可独立扩展）
	var gain := GameConfig.PLAYER_SP_GAIN_NORMAL
	if enemy.has_method("get_sp_reward"):
		gain = int(enemy.call("get_sp_reward"))
	_set_sp(sp + gain)
	AudioService.play_sfx("hit_enemy")

# 从受击框向上查找所属怪物节点（怪物根节点在 enemy 组内）
func _find_enemy_from_area(area: Area2D) -> Node:
	var node: Node = area
	while node != null:
		if node.is_in_group("enemy"):
			return node
		node = node.get_parent()
	return null

# 当前精灵帧是否处于攻击判定帧（严格对齐动画关键帧）
func _is_attack_frame_active() -> bool:
	if state != State.ATTACK:
		return false
	return GameConfig.ATTACK_ACTIVE_FRAMES.has(_sprite.frame)

# 动画帧变化：
#   剑士 → 按判定帧开关近战攻击碰撞箱
#   旅者 → 在出手帧生成飞盘（飞盘自己负责飞行与命中）
func _on_sprite_frame_changed() -> void:
	if state == State.ATTACK:
		if character_id == CHARACTER_TRAVELER:
			if _sprite.frame == GameConfig.TRAVELER_DISC_THROW_FRAME and not _disc_spawned_this_attack:
				_disc_spawned_this_attack = true
				_spawn_normal_disc()
			return
		var active := _is_attack_frame_active()
		if _attack_hitbox.monitoring != active:
			_attack_hitbox.set_deferred("monitoring", active)
	elif _attack_hitbox.monitoring:
		_attack_hitbox.set_deferred("monitoring", false)

# 普攻动画播完 → 回到待机（无冷却，可立刻再次普攻）
func _on_animation_finished() -> void:
	if state == State.ATTACK:
		_attack_hitbox.set_deferred("monitoring", false)
		_disc_spawned_this_attack = false
		_enter_state(State.IDLE)
		_play_animation(ANIM_IDLE)
		_walk_phase = WALK_PHASE_IDLE
	elif state == State.DODGE:
		_enter_state(State.IDLE)
		_play_animation(ANIM_IDLE)
		_walk_phase = WALK_PHASE_IDLE

# ------------------------------ 数值 / 状态辅助 ------------------------------
func _can_act() -> bool:
	return state == State.IDLE or state == State.WALK

func _set_hp(value: int) -> void:
	var clamped := clampi(value, 0, GameConfig.PLAYER_MAX_HP)
	if clamped == hp:
		return
	hp = clamped
	hp_changed.emit(player_index, hp, GameConfig.PLAYER_MAX_HP)

func _set_sp(value: int) -> void:
	var clamped := clampi(value, 0, GameConfig.PLAYER_MAX_SP)
	if clamped == sp:
		return
	sp = clamped
	sp_changed.emit(player_index, sp, GameConfig.PLAYER_MAX_SP)

func _set_invincible(duration: float) -> void:
	_invincible_timer = maxf(_invincible_timer, duration)
	is_invincible = true
	_blink_timer = 0.0

func _enter_state(new_state: int) -> void:
	state = new_state
	_state_timer = 0.0
	# 离开移动状态时复位三段式阶段，下次起步重新播"起手过渡"
	if new_state != State.IDLE and new_state != State.WALK:
		_walk_phase = WALK_PHASE_IDLE
		_attack_hold_pending = false # 进入别的状态时取消"点按/长按"待判定
	# 打断蓄力（受击 / 闪避 / 死亡 / 大招等）：销毁手上的飞盘特效
	if state != State.CHARGE and _held_disc != null:
		_destroy_held_disc()

func _enter_state_if_needed(new_state: int) -> void:
	if state != new_state:
		_enter_state(new_state)
		_play_animation(ANIM_WALK if new_state == State.WALK else ANIM_IDLE)

# 常规移动状态刷新：状态或动画需要变化时才重新播放，避免待机/行走动画被打断重播
# 三段式移动的角色（旅者）只切状态，动画交给 _update_walk_phase 统一管理
func _set_locomotion_state(target_state: int) -> void:
	if _has_animation(ANIM_WALK_START):
		if state != target_state:
			state = target_state
			_state_timer = 0.0
		return
	var animation_name := ANIM_WALK if target_state == State.WALK else ANIM_IDLE
	if state != target_state or _current_animation != animation_name:
		state = target_state
		_state_timer = 0.0
		_play_animation(animation_name)

# 朝向：只看左右移动方向；所有素材只保留向右，向左自动 scale.x = -1 镜像
func _update_facing_by_sign(sign_value: int) -> void:
	if sign_value == 0:
		return
	facing = sign_value
	# 保留统一缩放系数，只翻转 x 的正负（absf 取出当前缩放系数，再乘朝向）
	_sprite.scale = Vector2(absf(_sprite.scale.x) * float(facing), absf(_sprite.scale.y))
	# 攻击碰撞箱随朝向翻转（左右对称镜像），并保持统一缩放系数
	_update_attack_hitbox_transform()

func _play_animation(animation_name: String) -> void:
	if not _has_animation(animation_name):
		return
	_current_animation = animation_name
	_sprite.offset = -_animation_anchor(animation_name) # 脚底锚点对齐，保证各动画站在同一地面线
	_sprite.play(animation_name)

func _has_animation(animation_name: String) -> bool:
	return _sprite_frames != null and _sprite_frames.has_animation(animation_name)

func _animation_anchor(animation_name: String) -> Vector2:
	if _anim_anchors.has(animation_name):
		return _anim_anchors[animation_name]
	return _anchor_from_config(animation_name, GameConfig.PLAYER_ANIM_ANCHORS)

# 动画时长（秒）：帧数 / 帧率
func _animation_duration(animation_name: String) -> float:
	if not _has_animation(animation_name):
		return 0.25
	var frame_count := _sprite_frames.get_frame_count(animation_name)
	var fps := maxf(_sprite_frames.get_animation_speed(animation_name), 0.001)
	return float(frame_count) / fps

# 兜底防掉图：即使边界碰撞被意外绕过，也把角色拉回安全区间
func _clamp_to_safe_area() -> void:
	var y_min := GameConfig.PLAYER_SAFE_Y_MIN - 40.0
	var y_max := GameConfig.PLAYER_SAFE_Y_MAX + 40.0
	if global_position.y < y_min or global_position.y > y_max:
		global_position.y = clampf(global_position.y, y_min, y_max)

# ------------------------------ 对外查询（HUD / 调试） ------------------------------
func get_dodge_cooldown_remaining() -> float:
	return _dodge_cooldown

func get_dodge_cooldown_ratio() -> float:
	if GameConfig.PLAYER_DODGE_COOLDOWN <= 0.0:
		return 0.0
	return clampf(_dodge_cooldown / GameConfig.PLAYER_DODGE_COOLDOWN, 0.0, 1.0)

func is_dead() -> bool:
	return state == State.DEAD

# 测试台：仅满 SP
func debug_fill_sp() -> void:
	_set_sp(GameConfig.PLAYER_MAX_SP)

# 测试台：满 SP 并立即释放大招（无视当前硬直 / 攻击状态，便于调试大招表现）
func debug_fill_sp_and_cast() -> void:
	_set_sp(GameConfig.PLAYER_MAX_SP)
	if state == State.DEAD:
		return
	_enter_state(State.IDLE)
	_start_ultimate()

func debug_status_line() -> String:
	return "P%d HP=%d SP=%d ARMOR=%d INV=%d STATE=%d FRAME=%d POS=(%d,%d)" % [
		player_index, hp, sp, 1 if is_armored else 0, 1 if is_invincible else 0,
		state, _sprite.frame, int(global_position.x), int(global_position.y)
	]
