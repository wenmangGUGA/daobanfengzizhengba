extends Area2D
class_name TravelerDisc

# =============================================================================
# 旅者飞盘（投射物 / 手持特效）—— 独立于角色本体，单独渲染
#
# 三种用法：
#   ① 平A 飞盘  ：播【旅者平a特效.png】标签「飞出去循环」边旋转边向前飞；命中播「击中」+ 叠加
#                 【击中特效.png】闪白；伤害 5 格
#   ② 蓄力·手持 ：长按蓄力时挂在角色手上跟随（held_mode=true）：
#                 蓄力中播【旅者蓄力攻击特效.png】标签「蓄力」循环 → 满蓄力播「准备发射」
#                 此时不移动、不做命中判定（纯跟随特效）
#   ③ 蓄力·飞行 ：松手后 release_as_projectile() 解除跟随 → 播「飞盘飞出去的过程」，
#                 飞行途中程序控制尺寸快速变大；命中播「击中敌人」；伤害 10 格
#
# 自动瞄准：平A / 蓄力各一套（索敌半径、瞄准生效时间、转向角速度），全部可在 game_config.gd 调。
#   找不到敌人 → 直线飞；目标死亡 → 丢失锁敌（保持当前方向直线飞，不重新索敌、不急转弯）。
# =============================================================================

signal hit_enemy(disc: TravelerDisc, enemy: Node) # 命中敌人（供角色/关卡做后续处理）

const ANIM_FLY_NORMAL := "disc_fly"     # 平A：飞出去循环
const ANIM_HIT_NORMAL := "disc_hit"     # 平A：击中
const ANIM_HOLD_CHARGE := "cdisc_charge" # 蓄力手持：蓄力（循环）
const ANIM_HOLD_READY := "cdisc_ready"   # 蓄力手持：准备发射
const ANIM_FLY_CHARGE := "cdisc_fly"     # 蓄力：飞盘飞出去的过程
const ANIM_HIT_CHARGE := "cdisc_hit"     # 蓄力：击中敌人

@export var direction: int = 1                  # 初始飞行方向：1 向右，-1 向左
@export var speed: float = 900.0                # 飞行速度（像素/秒）
@export var max_distance: float = 780.0         # 最大飞行距离（超过即消失）
@export var damage: int = 5                     # 命中伤害（格）
@export var flash_white: bool = true            # 命中时敌人是否闪白
@export var charge_mode: bool = false           # true = 蓄力飞盘（更大、飞行途中放大）
@export var held_mode: bool = false             # true = 手持跟随模式（长按蓄力期间）
@export var grow_scale: float = 2.6             # 蓄力飞盘放大到的倍数
@export var grow_time: float = 0.45             # 放大到目标倍数所用时间（秒）
@export var hit_fx_path: String = ""            # 命中时叠加的一次性特效（平A 用击中特效.png）
# 穿透 / 撞墙
@export var pierce_limit: int = 1               # 最多能打中几个敌人（1 = 不穿透；蓄力默认 3）
@export var destroy_on_wall: bool = false       # 碰到墙（关卡 WorldBounds，层 5）是否直接销毁
# 自动瞄准（平A / 蓄力各一套，由角色生成时写入）
@export var homing_radius: float = 260.0        # 索敌半径（像素，以飞盘自身为中心）
@export var homing_delay: float = 0.08          # 瞄准生效时间（发射后多久开始索敌，秒）
@export var homing_turn_speed: float = 4.0      # 转向角速度（弧度/秒，越小越不能急转弯）
@export var facing_sign: int = 1                # 手持模式下的朝向（跟随角色）

@onready var _sprite: AnimatedSprite2D = $Sprite
@onready var _shape: CollisionShape2D = $CollisionShape2D

var _sprite_frames: SpriteFrames = null
var _anchors: Dictionary = {}       # 动画名 → 锚点（手持动画与身体图集对齐；飞行动画用内容中心）
var _direction_vec: Vector2 = Vector2.RIGHT
var _traveled: float = 0.0
var _elapsed: float = 0.0
var _hit_done: bool = false
var _hit_ids: Array[int] = []       # 已命中敌人的 instance id（防重复打同一个怪）
var _homing_target: Node2D = null
var _homing_locked: bool = false    # 是否已经"锁过一次"（锁过就不再重新索敌）

func _ready() -> void:
	collision_layer = 0
	# 只检测敌人的受击框（层 8）；需要撞墙销毁时再额外监测世界边界（层 5）
	collision_mask = 1 << 7
	if destroy_on_wall:
		collision_mask |= 1 << 4
	monitorable = false
	# 【重要】信号必须无条件连接：手持模式的飞盘在 _ready 里会提前返回，
	# 若把 connect 放在后面，松手变成投射物后就永远检测不到命中。
	area_entered.connect(_on_area_entered)
	_build_frames()
	_sprite.sprite_frames = _sprite_frames
	_sprite.centered = false
	_direction_vec = Vector2(float(direction), 0.0).normalized()
	if held_mode:
		# 手持跟随：不做位移/判定，只作为挂在手上的特效
		monitoring = false
		_sprite.scale = Vector2(_disc_scale() * float(facing_sign), _disc_scale())
		_play(ANIM_HOLD_CHARGE)
		return
	monitoring = true
	_sprite.scale = Vector2(_disc_scale() * float(direction), _disc_scale())
	_play(ANIM_FLY_CHARGE if charge_mode else ANIM_FLY_NORMAL)

# 撞墙 / 出界销毁：
#   ① 与"墙类实体"（关卡 WorldBounds，层 5）重叠 → 销毁（在安全走廊 Y 内飞行时生效）
#   ② 兜底：飞出发射方向的地图 X 范围 → 销毁（飞盘常在角色手部高度、可能高于走廊上沿）
func _check_wall_hit() -> void:
	if not destroy_on_wall or not monitoring:
		return
	if not get_overlapping_bodies().is_empty():
		queue_free()
		return
	var level: Node = get_tree().get_first_node_in_group("level_controller")
	if level == null:
		return
	var map_width: Variant = level.get("map_width")
	if map_width == null:
		return
	var limit := float(map_width) + 40.0
	if global_position.x < -40.0 or global_position.x > limit:
		queue_free()

# 飞盘显示缩放：与旅者本体同一像素比例（GameConfig.TRAVELER_DISC_SCALE）
func _disc_scale() -> float:
	return maxf(GameConfig.TRAVELER_DISC_SCALE, 0.01)

# 帧资源静态缓存：同一套动画（平A / 蓄力手持 / 蓄力飞行）只构建一次，反复投射直接复用
# → 避免每次生成飞盘都重建 SpriteFrames + AtlasTexture（首帧卡顿、特效起播不齐的常见原因）
static var _frames_cache: Dictionary = {}

# ------------------------------ 动画构建 ------------------------------
func _build_frames() -> void:
	var cache_key := "%s_%s" % ["charge" if charge_mode else "normal", "held" if held_mode else "fly"]
	if _frames_cache.has(cache_key):
		var cached: Dictionary = _frames_cache[cache_key]
		_sprite_frames = cached["frames"]
		_anchors = cached["anchors"]
		return
	_sprite_frames = SpriteFrames.new()
	_sprite_frames.remove_animation("default")
	_anchors.clear()
	if charge_mode:
		# 手持阶段：用"身体图集锚点"对齐（两套 json 的帧布局一致，锚点取蓄力本体实测值 29.5/89）
		var body_anchor: Vector2 = GameConfig.TRAVELER_ANIM_ANCHORS.get("charge_ready", Vector2(29.5, 89.0))
		_add_charge_tag(ANIM_HOLD_CHARGE, GameConfig.TRAVELER_TAG_CDISC_CHARGE, true, body_anchor)
		_add_charge_tag(ANIM_HOLD_READY, GameConfig.TRAVELER_TAG_CDISC_READY, false, body_anchor)
		# 飞行阶段：用"各帧内容中心均值"作锚点（程序控制位移，帧内位移忽略）
		var fly := ArtLoader.add_aseprite_animation(_sprite_frames, ANIM_FLY_CHARGE,
			AssetPaths.TRAVELER_CHARGE_DISC_SHEET, AssetPaths.TRAVELER_CHARGE_DISC_JSON,
			GameConfig.TRAVELER_TAG_CDISC_FLY, GameConfig.TRAVELER_ANIM_FPS, true)
		var hit := ArtLoader.add_aseprite_animation(_sprite_frames, ANIM_HIT_CHARGE,
			AssetPaths.TRAVELER_CHARGE_DISC_SHEET, AssetPaths.TRAVELER_CHARGE_DISC_JSON,
			GameConfig.TRAVELER_TAG_CDISC_HIT, GameConfig.TRAVELER_ANIM_FPS, false)
		_anchors[ANIM_FLY_CHARGE] = fly.get("anchor", Vector2.ZERO)
		_anchors[ANIM_HIT_CHARGE] = hit.get("anchor", Vector2.ZERO)
	else:
		var fly2 := ArtLoader.add_aseprite_animation(_sprite_frames, ANIM_FLY_NORMAL,
			AssetPaths.TRAVELER_DISC_SHEET, AssetPaths.TRAVELER_DISC_JSON,
			GameConfig.TRAVELER_TAG_DISC_FLY, GameConfig.TRAVELER_ANIM_FPS, true)
		var hit2 := ArtLoader.add_aseprite_animation(_sprite_frames, ANIM_HIT_NORMAL,
			AssetPaths.TRAVELER_DISC_SHEET, AssetPaths.TRAVELER_DISC_JSON,
			GameConfig.TRAVELER_TAG_DISC_HIT, GameConfig.TRAVELER_ANIM_FPS, false)
		_anchors[ANIM_FLY_NORMAL] = fly2.get("anchor", Vector2.ZERO)
		_anchors[ANIM_HIT_NORMAL] = hit2.get("anchor", Vector2.ZERO)
	_frames_cache[cache_key] = {"frames": _sprite_frames, "anchors": _anchors}

# 蓄力特效的某个标签 → 动画（锚点由外部指定：手持阶段与身体图集对齐）
func _add_charge_tag(anim_name: String, tag_name: String, loop: bool, anchor: Vector2) -> void:
	ArtLoader.add_aseprite_animation(_sprite_frames, anim_name,
		AssetPaths.TRAVELER_CHARGE_DISC_SHEET, AssetPaths.TRAVELER_CHARGE_DISC_JSON,
		tag_name, GameConfig.TRAVELER_ANIM_FPS, loop)
	_anchors[anim_name] = anchor

func _play(anim_name: String) -> void:
	if _sprite_frames == null or not _sprite_frames.has_animation(anim_name):
		return
	_sprite.offset = -Vector2(_anchors.get(anim_name, Vector2.ZERO))
	_sprite.play(anim_name)
	_fit_hitbox()

# 判定框大小 ≈ 飞盘内容大小（不小于配置下限，避免"贴着敌人飞过去"；蓄力放大时同步变大）
func _fit_hitbox() -> void:
	if _shape == null or _shape.shape == null:
		return
	var radius := maxf(GameConfig.TRAVELER_DISC_HITBOX_RADIUS, 18.0)
	if _sprite_frames != null and _sprite.animation != StringName("") \
			and _sprite_frames.get_frame_count(_sprite.animation) > 0:
		var texture := _sprite_frames.get_frame_texture(_sprite.animation, 0)
		if texture != null:
			radius = maxf(radius, maxf(texture.get_size().x, texture.get_size().y) * 0.22)
	if _shape.shape is CircleShape2D:
		(_shape.shape as CircleShape2D).radius = radius

# ------------------------------ 手持 → 投射物 ------------------------------
# 蓄力满：手持特效播「准备发射」
func play_charge_ready() -> void:
	if held_mode:
		_play(ANIM_HOLD_READY)

# 松手发射：解除跟随，变成独立投射物（保持世界坐标由调用方给定出手点）
func release_as_projectile(new_parent: Node, spawn_position: Vector2) -> void:
	if not held_mode:
		return
	held_mode = false
	monitoring = true
	if new_parent != null and get_parent() != new_parent:
		reparent(new_parent, true) # true = 保持世界变换
	global_position = spawn_position
	_elapsed = 0.0
	_traveled = 0.0
	_direction_vec = Vector2(float(facing_sign), 0.0).normalized()
	_sprite.scale = Vector2(_disc_scale() * float(facing_sign), _disc_scale())
	_play(ANIM_FLY_CHARGE)

# ------------------------------ 每帧 ------------------------------
func _physics_process(delta: float) -> void:
	if held_mode:
		return # 手持跟随：位置由父节点（角色）带着走
	_elapsed += delta
	if _hit_done:
		# 命中后：留在原地播完击中特效，然后消失
		if _sprite_frames != null and not _sprite.is_playing():
			queue_free()
		return
	_update_homing(delta)
	position += _direction_vec * speed * delta
	_traveled += speed * delta
	_check_wall_hit() # 碰到墙直接销毁
	# 蓄力飞盘：飞行途中程序控制尺寸快速变大
	if charge_mode and grow_time > 0.0:
		var t := clampf(_elapsed / grow_time, 0.0, 1.0)
		var factor := lerpf(1.0, maxf(grow_scale, 1.0), t)
		var base := _disc_scale() * factor
		_sprite.scale = Vector2(base * signf(_direction_vec.x if absf(_direction_vec.x) > 0.01 else 1.0), base)
		if _shape != null and _shape.shape is CircleShape2D:
			(_shape.shape as CircleShape2D).radius = maxf(GameConfig.TRAVELER_DISC_HITBOX_RADIUS,
				GameConfig.TRAVELER_DISC_HITBOX_RADIUS * factor)
	# 贴图朝向跟随飞行方向（左右镜像）
	if absf(_direction_vec.x) > 0.01:
		_sprite.scale.x = absf(_sprite.scale.x) * (1.0 if _direction_vec.x > 0.0 else -1.0)
	if _traveled >= max_distance:
		queue_free()

# ------------------------------ 自动瞄准 ------------------------------
# 到"瞄准生效时间"时在索敌半径内找一个敌人锁定；找不到就直线飞。
# 锁定后不再重新索敌；目标死亡 → 丢失锁敌，保持当前方向直线飞（不急转弯、不换目标）。
func _update_homing(delta: float) -> void:
	if not _homing_locked and _elapsed >= homing_delay:
		_homing_locked = true
		_homing_target = _find_nearest_enemy(homing_radius)
	if _homing_target != null and not is_instance_valid(_homing_target):
		_homing_target = null # 目标已死亡/被移除：丢失锁敌（保持当前方向直线飞，不重新索敌）
	if _homing_target == null:
		return
	var to_target := _aim_point(_homing_target) - global_position
	if to_target.length() < 1.0:
		return
	var desired := to_target.normalized()
	var max_turn := maxf(homing_turn_speed, 0.0) * delta
	var angle := _direction_vec.angle_to(desired)
	var turn := clampf(angle, -max_turn, max_turn) # 限制转向角速度：不会急转弯
	_direction_vec = _direction_vec.rotated(turn)

# 瞄准点：优先取敌人的受击框中心（身体中心），没有受击框就用"原点 + 配置高度"
# 【重要】不能直接瞄敌人 origin（脚底），否则飞盘会扎到腿下方擦不到身体
func _aim_point(enemy: Node2D) -> Vector2:
	var hurt := enemy.get_node_or_null("Hurtbox") as Node2D
	if hurt != null:
		return hurt.global_position
	return enemy.global_position + Vector2(0.0, GameConfig.TRAVELER_DISC_AIM_HEIGHT)

func _find_nearest_enemy(radius: float) -> Node2D:
	if radius <= 0.0:
		return null
	var best: Node2D = null
	var best_distance := radius
	for node in get_tree().get_nodes_in_group("enemy"):
		var enemy := node as Node2D
		if enemy == null or not is_instance_valid(enemy):
			continue
		var distance := global_position.distance_to(enemy.global_position)
		if distance <= best_distance:
			best_distance = distance
			best = enemy
	return best

# ------------------------------ 命中 ------------------------------
# 穿透规则：最多打中 pierce_limit 个敌人（用 instance id 记录，绝不重复打同一个怪）；
#   未打满 → 扣血 + 在敌人处生成命中特效，飞盘继续飞（不打断飞行动画）；
#   打满   → 扣血 + 命中特效 + 切「击中/击中敌人」动画并停在原地，播完消失。
func _on_area_entered(area: Area2D) -> void:
	if held_mode:
		return
	if _hit_done and _hit_ids.size() >= maxi(pierce_limit, 1):
		return
	var enemy := _find_enemy(area)
	if enemy == null:
		return
	var enemy_id := enemy.get_instance_id()
	if _hit_ids.has(enemy_id):
		return # 同一个怪只结算一次
	_hit_ids.append(enemy_id)
	if enemy.has_method("take_damage"):
		var color := Color(1, 1, 1, 1) if flash_white else GameConfig.ENEMY_HIT_FLASH_COLOR
		enemy.call("take_damage", damage, global_position, null, color)
	hit_enemy.emit(self, enemy)
	# 在敌人位置生成一次性命中特效（独立节点，不跟着飞盘跑）
	_spawn_hit_fx(global_position)
	AudioService.play_sfx("hit_enemy")
	if _hit_ids.size() >= maxi(pierce_limit, 1):
		# 打满穿透数：停下来播击中动画，播完消失
		_hit_done = true
		_play(ANIM_HIT_CHARGE if charge_mode else ANIM_HIT_NORMAL)

# 命中叠加特效：生成在指定世界坐标（独立于飞盘，穿透时飞盘继续飞、特效留在原地）
# 平A 用【击中特效.png】做闪白；蓄力命中的大碎裂已含在「击中敌人」标签里，中间穿透用同款小闪白
func _spawn_hit_fx(world_position: Vector2) -> void:
	if hit_fx_path.is_empty():
		return
	var texture := ArtLoader.load_texture(hit_fx_path)
	if texture == null:
		return
	var host: Node = get_tree().current_scene
	if host == null:
		host = get_parent()
	if host == null:
		return
	var fx := Sprite2D.new()
	fx.texture = texture
	fx.centered = true
	fx.scale = Vector2.ONE * _disc_scale()
	host.add_child(fx)
	fx.global_position = world_position
	var tween := fx.create_tween()
	tween.tween_property(fx, "modulate", Color(1, 1, 1, 0), 0.18)
	tween.tween_callback(fx.queue_free)

func _find_enemy(area: Area2D) -> Node:
	var node: Node = area
	while node != null:
		if node.is_in_group("enemy"):
			return node
		node = node.get_parent()
	return null
