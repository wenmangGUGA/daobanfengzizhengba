extends Area2D
class_name DropCoin

# =============================================================================
# 金币掉落物
#   素材：res://textures/金币动画（7 帧循环动画）
#   行为：磁吸飞向玩家 → 拾取成功 → 飘字“+数字” → 金币总数实时累加
# =============================================================================

@export var value: int = 1                    # 金币数量
@export var magnet_radius: float = 140.0      # 磁吸半径（后期自行调参）
@export_range(0.1, 6.0, 0.05) var icon_scale: float = 2.0 # 金币图标缩放（金币素材很小，默认放大 2 倍）

@onready var _sprite: AnimatedSprite2D = $Sprite

var target_player: Node2D = null              # 磁吸目标玩家
var _picked: bool = false                     # 是否已被拾取

func _ready() -> void:
	add_to_group("drop")
	monitoring = false
	monitorable = false
	var frames := ArtLoader.build_sprite_frames([
		{"name": "spin", "dir": AssetPaths.COIN_DIR, "fps": GameConfig.ANIM_FPS_COIN, "loop": true},
	])
	_sprite.sprite_frames = frames
	_sprite.centered = false
	_sprite.offset = -GameConfig.COIN_ANIM_ANCHOR # 金币内容中心对齐节点位置
	_sprite.scale = Vector2(icon_scale, icon_scale) # 掉落物图标放大（独立导出参数）
	if frames.has_animation("spin"):
		_sprite.play("spin")
	else:
		_sprite.sprite_frames = null # 缺素材：不渲染任何占位物体

func _physics_process(delta: float) -> void:
	if _picked:
		return
	if not _is_target_valid():
		target_player = _find_nearest_player()
	if target_player == null:
		return
	var offset := target_player.global_position - global_position
	var distance := offset.length()
	if distance <= magnet_radius and distance > 0.001:
		global_position += offset / distance * GameConfig.MAGNET_SPEED * delta
	if distance <= GameConfig.DROP_PICKUP_DISTANCE:
		_pick_up()

func _is_target_valid() -> bool:
	if target_player == null or not is_instance_valid(target_player):
		return false
	var player := target_player as PlayerController
	return player != null and not player.is_dead()

func _find_nearest_player() -> Node2D:
	var nearest: Node2D = null
	var nearest_distance := INF
	for node in get_tree().get_nodes_in_group("player_controller"):
		var player := node as PlayerController
		if player == null or player.is_dead():
			continue
		var distance: float = player.global_position.distance_to(global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest = player
	return nearest

# 拾取：金币总数实时累加 + 漂浮“+数字”动画
func _pick_up() -> void:
	if _picked:
		return
	_picked = true
	GameSession.add_coins(value)
	get_tree().call_group("level_controller", "spawn_floating_text", global_position, "+%d" % value, Color(1.0, 0.85, 0.25, 1.0))
	AudioService.play_sfx("coin_pickup")
	queue_free()
