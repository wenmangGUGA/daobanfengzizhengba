extends Area2D
class_name ChestPickup

# =============================================================================
# 宝箱（掉落物）：所有怪物只掉宝箱，不掉直接金币
#   普通怪 → 铜宝箱（copper）；精英怪 → 金宝箱（gold）
#   触碰玩家自动开启 → 自动拾取 → 自动渐隐消失
#   随机产出：金币 / 道具（概率与数量见 GameConfig）
# =============================================================================

signal opened(chest: Node, player: Node) # 已被开启（关卡据此生成产出）

const TYPE_COPPER := "copper"            # 铜宝箱
const TYPE_GOLD := "gold"                # 金宝箱

@export var chest_type: String = TYPE_COPPER # 宝箱类型
@export var touch_radius: float = 90.0       # 触碰开启半径（可在检查器里单独调整）
@export_range(0.1, 6.0, 0.05) var icon_scale: float = 1.6 # 宝箱图标缩放（掉落物图标放大，独立于其他掉落物）

@onready var _sprite: Sprite2D = $Sprite

var _opened: bool = false                # 是否已开启
var _texture: Texture2D = null           # 宝箱贴图
var _player_inside: Node = null          # 当前触碰到的玩家

func _ready() -> void:
	add_to_group("chest")
	# 用 set_deferred：宝箱可能在敌人的死亡信号链里被创建（那时物理查询正在 flush），
	# 直接改 monitoring/monitorable 会触发 "Function blocked during in/out signal" 报错。
	set_deferred("monitoring", false) # 拾取判定使用距离数学，不需要物理检测（避免与角色碰撞层耦合）
	set_deferred("monitorable", false)
	_texture = ArtLoader.load_texture(AssetPaths.UI_CHEST_GOLD if chest_type == TYPE_GOLD else AssetPaths.UI_CHEST_COPPER)
	if _texture != null:
		_sprite.texture = _texture
		_sprite.centered = false
		_sprite.offset = -ArtLoader.content_center(_texture) # 自动对齐素材内容中心
	else:
		_sprite.texture = null # 缺素材：不渲染任何占位物体
	# 出现时的小弹跳（纯表现，不使用任何占位几何体）；缩放值来自 icon_scale 导出参数
	var final_scale := Vector2(icon_scale, icon_scale)
	_sprite.scale = final_scale * 0.7
	var tween := create_tween()
	tween.tween_property(_sprite, "scale", final_scale, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func _physics_process(_delta: float) -> void:
	if _opened:
		return
	_player_inside = _find_touching_player()
	if _player_inside != null:
		_open(_player_inside)

# 查找触碰范围内的存活玩家
func _find_touching_player() -> Node:
	var nearest: Node = null
	var nearest_distance := INF
	for node in get_tree().get_nodes_in_group("player_controller"):
		var player := node as PlayerController
		if player == null or player.is_dead():
			continue
		var distance: float = player.global_position.distance_to(global_position)
		if distance <= touch_radius and distance < nearest_distance:
			nearest_distance = distance
			nearest = player
	return nearest

# 开启宝箱：通知关卡产出奖励 → 自动渐隐消失
func _open(player: Node) -> void:
	if _opened:
		return
	_opened = true
	opened.emit(self, player)
	AudioService.play_sfx("chest_open")
	var tween := create_tween()
	tween.tween_property(_sprite, "modulate:a", 0.0, GameConfig.CHEST_OPEN_FADE_TIME)
	tween.tween_callback(queue_free)

func is_gold() -> bool:
	return chest_type == TYPE_GOLD

func debug_status_line() -> String:
	return "CHEST(%s) opened=%d POS=(%d,%d)" % [chest_type, 1 if _opened else 0, int(global_position.x), int(global_position.y)]
