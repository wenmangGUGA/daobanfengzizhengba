extends Area2D
class_name DropItem

# =============================================================================
# 道具掉落物
#   素材：图标目录预留 res://textures/items/（后期导入，缺素材只打印控制台警告）
#   行为：磁吸飞向玩家 → 拾取成功 → 图标弹出动画 → 存入背包（效果系统后期实现）
# =============================================================================

@export var item_id: String = "item_unknown"   # 道具 id
@export var item_name: String = "ITEM"         # 道具显示名（界面仅用英文字母与数字）
@export var icon_path: String = ""             # 道具图标路径（预留目录）
@export var magnet_radius: float = 140.0       # 磁吸半径（后期自行调参）
@export_range(0.1, 6.0, 0.05) var icon_scale: float = 2.0 # 道具图标缩放（掉落物图标放大，独立于其他掉落物）

@onready var _sprite: Sprite2D = $Sprite

var target_player: Node2D = null               # 磁吸目标玩家
var _picked: bool = false                      # 是否已被拾取
var _icon_texture: Texture2D = null            # 图标贴图

func _ready() -> void:
	add_to_group("drop")
	monitoring = false
	monitorable = false
	if icon_path.is_empty():
		# 预留目录：默认按 items/<id>.png 查找，缺素材时只提示，不生成任何占位
		icon_path = AssetPaths.ITEM_ICON_DIR + item_id + ".png"
	_icon_texture = ArtLoader.load_texture(icon_path)
	if _icon_texture != null:
		_sprite.texture = _icon_texture
		_sprite.centered = false
		_sprite.offset = -ArtLoader.content_center(_icon_texture)
		_sprite.scale = Vector2(icon_scale, icon_scale) # 掉落物图标放大（独立导出参数）
	else:
		_sprite.texture = null

func _physics_process(delta: float) -> void:
	if _picked:
		return
	if not _is_target_valid():
		target_player = _find_nearest_player()
	if target_player == null:
		return
	var offset := target_player.global_position - global_position
	var distance := offset.length()
	if distance <= magnet_radius and distance > 0.001:
		global_position += offset / distance * GameConfig.MAGNET_SPEED * delta
	if distance <= GameConfig.DROP_PICKUP_DISTANCE:
		_pick_up()

func _is_target_valid() -> bool:
	if target_player == null or not is_instance_valid(target_player):
		return false
	var player := target_player as PlayerController
	return player != null and not player.is_dead()

func _find_nearest_player() -> Node2D:
	var nearest: Node2D = null
	var nearest_distance := INF
	for node in get_tree().get_nodes_in_group("player_controller"):
		var player := node as PlayerController
		if player == null or player.is_dead():
			continue
		var distance: float = player.global_position.distance_to(global_position)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest = player
	return nearest

# 拾取：图标弹出动画 + 存入背包
func _pick_up() -> void:
	if _picked:
		return
	_picked = true
	GameSession.add_item(item_id, item_name, icon_path)
	get_tree().call_group("level_controller", "spawn_item_popup", global_position, icon_path, item_name, icon_scale)
	AudioService.play_sfx("item_pickup")
	queue_free()

func debug_status_line() -> String:
	return "ITEM(%s) POS=(%d,%d)" % [item_id, int(global_position.x), int(global_position.y)]
